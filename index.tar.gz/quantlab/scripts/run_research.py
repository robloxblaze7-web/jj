#!/usr/bin/env python3
"""Entry point for a full research study.

    python scripts/run_research.py
    python scripts/run_research.py --config configs/experiments/stress_costs.json

Equivalent to `python -m quantlab.cli run`; kept as a script so the study can be
launched without installing the package.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from quantlab.cli import main  # noqa: E402

if __name__ == "__main__":
    argv = sys.argv[1:]
    if not argv or argv[0].startswith("-"):
        argv = ["run", *argv]
    raise SystemExit(main(argv))
