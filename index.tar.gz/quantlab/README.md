# QuantLab

A research-only laboratory for testing systematic trading strategies on historical
price data.

**It has no broker connectivity, no credential handling and no order-routing code, and
none should be added.** It backtests, it paper-trades, it produces evidence about how a
rule *would have* behaved. It does not trade.

---

## The claim this project refuses to make

A backtest cannot establish that a strategy is profitable. It can establish that a rule,
applied to one historical sample under one set of cost and execution assumptions, would
have produced a particular sequence of numbers. Those are different statements, and the
gap between them is where most retail systematic trading money is lost.

So this framework is built around a specific asymmetry: **a backtest's default failure
mode is to look better than reality.** Every ambiguous modelling choice is therefore
resolved against the strategy, and every performance figure is reported alongside the
diagnostics needed to discount it.

Concretely:

| Where reality is ambiguous | What this engine assumes |
|---|---|
| When can a signal be filled? | Next bar's open. Same-bar execution is impossible to configure. |
| A bar touched both the stop and the target | The **stop** filled. Count reported per run. |
| A bar gapped past the stop | Filled at the open, worse than the stop. Loss exceeds 1R. |
| Fill quality | Spread and slippage always adverse; no fill ever improves. |
| Position size hits a cap | Rounded **down** to a tradeable increment, never up. |
| Equity below maintenance margin | Liquidated. The account does not get to recover. |
| Reported Sharpe from an N-variant search | Deflated by the Sharpe that N zero-edge trials would produce. |

---

## Quick start

```bash
pip install -r requirements.txt          # numpy, pandas, matplotlib (+ pytest for tests)
export PYTHONPATH=src

python -m quantlab.cli strategies        # what is available and how big each search is
python -m quantlab.cli data              # generate data and print its quality report
python -m quantlab.cli backtest --symbols EURUSD --strategy breakout
python -m quantlab.cli run               # the full study -> reports/runs/baseline/
```

The full run produces, in `reports/runs/<name>/`:

```
research_report.md        the report, with results, diagnostics and limitations
charts/                   equity, drawdown, monthly returns, trade distribution,
                          rolling Sharpe, walk-forward folds, Monte Carlo
summary.csv               one row per run: every metric plus the six criteria
out_of_sample_trades.csv  the full out-of-sample trade blotter
config.json               the exact configuration, for reproduction
criteria.json             pass/fail per run against the falsification criteria
```

### Tests

```bash
pytest -q                     # if pytest is installed
python tests/run_tests.py     # otherwise — same tests, zero dependencies
```

115 tests. The important ones are in `tests/test_engine.py`.

---

## Project structure

```
src/quantlab/
├── config.py            every knob, as dataclasses that serialise to one JSON blob
├── indicators.py        causal-only indicators + a runtime causality checker
├── data/
│   ├── schema.py        the OHLCV contract; strict validation, no silent repairs
│   ├── universe.py      contract specs + point-in-time listing (survivorship control)
│   ├── synthetic.py     deterministic regime-switching generator (see the warning below)
│   ├── loaders.py       CSV / synthetic loading, caching, quality reporting
│   └── splits.py        train / validation / test and walk-forward, both embargoed
├── strategies/          MA crossover, breakout, RSI reversion, momentum + registry
├── backtest/
│   ├── costs.py         spread, slippage, commission, financing
│   ├── engine.py        the bar loop and every execution rule
│   └── types.py         positions, trades, results
├── risk/
│   ├── sizing.py        fixed-risk / fixed-fraction / vol-target + the cap chain
│   └── limits.py        daily loss limit, drawdown kill switch
├── analytics/
│   ├── metrics.py       all performance metrics, each with its uncertainty
│   ├── walkforward.py   rolling/anchored selection, evaluated out-of-sample
│   ├── monte_carlo.py   trade-sequence resampling -> drawdown and streak distributions
│   └── overfitting.py   deflated Sharpe, expected best-of-N, PBO, rank correlation
└── reporting/
    ├── charts.py        the six standard charts
    └── report.py        markdown report assembly
```

---

## How look-ahead bias is prevented

Not by discipline — by construction, and then verified:

1. **The API makes it impossible.** A strategy receives a price frame and returns one
   signal per bar. It cannot see bar *t+1*; the engine applies the execution lag itself,
   and `BacktestConfig` rejects a lag below one bar.
2. **Indicators are verified causal at runtime.** `indicators.check_causal` recomputes an
   indicator on a truncated prefix and compares. The test suite runs it against every
   public indicator, and against a deliberately cheating one to prove the check can fail.
3. **Channels exclude the current bar.** "Broke above the 55-day high" does not silently
   become "is the highest bar so far".
4. **Wilder smoothing is seeded exactly**, so a bar's RSI does not depend on how much
   history happened to be loaded.
5. **The future-data perturbation test.** Every bar after a cut point is randomly
   perturbed and the whole pipeline is re-run; every trade closed before the cut must be
   byte-identical. If anything anywhere peeks, that test fails.

## How survivorship bias is handled

Instruments carry listing and delisting dates; `Universe.audit_survivorship` flags a
backtest window that starts before an instrument existed, and `active_at` gives the
point-in-time tradeable set. For a fixed four-instrument macro universe this is a light
constraint. The mechanism matters because the moment this is pointed at equities,
"today's index members" is a survivorship-biased universe — and the audit is what stops
you using it by accident. The S&P 500 series carries an explicit note that index-level
results say nothing about single-stock strategies, for the same reason.

## How data snooping is handled

Every walk-forward run records how many parameter combinations were searched, and that
count is used, not just displayed:

* **Expected best-of-N Sharpe under the null.** Search 24 variants over three years of
  daily data and the best one shows a Sharpe of about 1.15 *with no edge at all*. A
  result below that line is consistent with search luck.
* **Deflated Sharpe ratio** — the probability the true Sharpe exceeds zero, adjusted for
  trials, sample length, skew and kurtosis.
* **Probability of backtest overfitting** — across folds, how often the in-sample winner
  lands in the bottom half out-of-sample. Around 0.5 means the selection procedure has no
  predictive content, whatever the equity curve looks like.
* **Multiple-testing adjusted p-values** (Šidák and Bonferroni).

---

## The six criteria

The report scores every run against these, and the executive summary is generated from
the arithmetic rather than written by hand. **Any single failure discards the result.**

1. Positive out-of-sample expectancy in R.
2. A majority of walk-forward folds positive — not just the aggregate.
3. Out-of-sample Sharpe above the expected best-of-N Sharpe under the null.
4. Deflated Sharpe ratio ≥ 0.95.
5. Probability of backtest overfitting < 0.5.
6. Survives 2× spread, slippage and commission.

Clearing all six does **not** mean a strategy is profitable. It means the result is not
*explained by* the search. That is a much weaker claim, and it is the strongest one a
backtest is capable of supporting. The next step after clearing them is forward paper
trading on data that did not exist when the rule was written — not capital.

---

## About the bundled data

The default data source is a **synthetic generator**, and this matters more than any
other line in this README.

`data/synthetic.py` produces regime-switching stochastic-volatility price paths with
jumps and Brownian-bridge intrabar ranges. They look like markets. They are not markets.
The generator was written to contain trends and mean-reverting regimes, so a trend
strategy "working" on it is a statement about the generator's parameters.

Its purpose is that the entire pipeline — engine, metrics, walk-forward, Monte Carlo,
charts, report — runs anywhere, deterministically, with no vendor account and no network,
so the machinery can be tested. **Every performance number produced on it is a test of
the software, not evidence about any market.**

To use real data, drop vendor CSVs at `data/raw/<SYMBOL>.csv` with columns
`timestamp,open,high,low,close,volume` (common vendor spellings are normalised) and run
with `--source csv`. The loader validates strictly and raises rather than repairing:
fix the file, do not let the engine trade through bad bars.

Then replace the cost assumptions in `data/universe.py` with your own venue's spreads,
commissions and financing. For high-turnover strategies the cost assumption, not the
signal, usually decides the result.

---

## What this system will never do

Connect to a broker, hold credentials, or place an order. Extending it that way would
mean rewriting the execution layer against a real venue, at which point every assumption
in the table at the top of this file stops being a modelling choice and becomes a live
risk.

## Licence

MIT. Provided for research and education. Nothing here is financial advice.
