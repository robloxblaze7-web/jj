"""Shared builders for the test suite.

No pytest fixtures: the tests must run under both pytest and the bundled
zero-dependency runner, so shared setup is plain functions.
"""

from __future__ import annotations

from typing import List, Sequence

import pandas as pd

from quantlab.config import BacktestConfig, CostConfig, RiskConfig
from quantlab.data.universe import InstrumentSpec

# A frictionless instrument with round numbers, so expected values in the engine
# tests can be computed by hand rather than by running the engine.
TEST_SPEC = InstrumentSpec(
    symbol="TEST", name="Test instrument", asset_class="test",
    tick_size=0.01, price_decimals=2, point_value=1.0,
    typical_spread=0.0, commission_rate=0.0, margin_rate=0.01,
    financing_rate_annual_long=0.0, financing_rate_annual_short=0.0,
    min_units=1.0, unit_step=1.0,
)


def zero_cost_config(**overrides) -> BacktestConfig:
    """A config with all costs switched off, for exact arithmetic in tests."""
    cfg = BacktestConfig(
        initial_balance=100_000.0,
        warmup_bars=0,
        atr_period=2,
        costs=CostConfig(
            spread_multiplier=0.0, slippage_bps=0.0,
            slippage_atr_fraction=0.0, commission_multiplier=0.0,
        ),
        risk=RiskConfig(
            sizing_method="fixed_risk", risk_per_trade=0.01,
            stop_atr_multiple=2.0, take_profit_atr_multiple=3.0,
            max_account_leverage=100.0, max_position_fraction=100.0,
            max_drawdown_stop=0.0, min_units=1.0,
        ),
    )
    for key, value in overrides.items():
        setattr(cfg, key, value)
    cfg.validate()
    return cfg


def make_bars(rows: Sequence[Sequence[float]], start: str = "2024-01-01") -> pd.DataFrame:
    """Build an OHLCV frame from [open, high, low, close] rows."""
    idx = pd.date_range(start, periods=len(rows), freq="B", name="timestamp")
    df = pd.DataFrame(list(rows), columns=["open", "high", "low", "close"], index=idx)
    df["volume"] = 1.0
    return df.astype("float64")


def flat_bars(n: int = 6) -> List[List[float]]:
    """Bars with a constant true range of 2, so ATR(2) == 2 exactly."""
    return [[100.0, 101.0, 99.0, 100.0]] * n


def signal_series(index: pd.Index, values: Sequence[float]) -> pd.Series:
    return pd.Series(list(values), index=index, dtype="float64")
