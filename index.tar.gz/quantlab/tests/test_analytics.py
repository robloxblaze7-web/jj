"""Walk-forward, Monte Carlo and overfitting diagnostics."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List

import numpy as np
import pandas as pd

from quantlab.analytics import (
    expected_losing_streak,
    run_monte_carlo,
    run_walk_forward,
    streak_probability,
)
from quantlab.analytics.overfitting import (
    bonferroni_p,
    build_overfitting_report,
    deflated_sharpe_ratio,
    expected_max_sharpe_null,
    haircut_sharpe,
    norm_cdf,
    norm_ppf,
    probability_of_backtest_overfitting,
    sidak_p,
    spearman_correlation,
)
from quantlab.config import BacktestConfig, MonteCarloConfig, WalkForwardConfig
from quantlab.data import generate_ohlcv

_DF = generate_ohlcv("EURUSD", "2010-01-01", "2020-12-31", seed=47)


# --------------------------------------------------------------------------- #
# walk-forward
# --------------------------------------------------------------------------- #
def test_walk_forward_evaluates_only_out_of_sample_data():
    result = run_walk_forward(
        _DF, "ma_crossover", symbol="EURUSD",
        wf_config=WalkForwardConfig(train_bars=600, test_bars=200),
        param_grid=[{"fast": 10, "slow": 50}, {"fast": 20, "slow": 100}],
    )
    assert result.n_folds >= 5
    for fold in result.folds:
        assert fold.test_start > fold.train_end          # embargo enforced
        if fold.result is not None and not fold.result.trades.empty:
            assert fold.result.trades["entry_time"].min() >= fold.test_start


def test_walk_forward_equity_is_continuous_across_folds():
    """Balances must compound between folds, not restart at the initial balance."""
    result = run_walk_forward(
        _DF, "breakout", symbol="EURUSD",
        wf_config=WalkForwardConfig(train_bars=600, test_bars=200),
        param_grid=[{"entry_lookback": 20, "exit_lookback": 10},
                    {"entry_lookback": 55, "exit_lookback": 20}],
    )
    equity = result.equity_curve["equity"]
    assert equity.index.is_monotonic_increasing
    assert not equity.index.has_duplicates
    jumps = equity.pct_change().abs().dropna()
    assert float(jumps.max()) < 0.5, "an implausible jump suggests a restarted balance"


def test_walk_forward_records_every_candidate_for_the_overfitting_analysis():
    grid = [{"fast": 10, "slow": 50}, {"fast": 20, "slow": 100}, {"fast": 50, "slow": 200}]
    result = run_walk_forward(
        _DF, "ma_crossover", symbol="EURUSD",
        wf_config=WalkForwardConfig(train_bars=600, test_bars=200), param_grid=grid,
    )
    assert result.n_candidates == 3
    for fold in result.folds:
        assert len(fold.candidates) == 3
        # The selected parameters must be the in-sample winner among eligible ones.
        eligible = [c for c in fold.candidates if c.eligible]
        if eligible and fold.selected_params is not None:
            best = max(eligible, key=lambda c: c.train_score)
            assert fold.selected_params == best.params


def test_walk_forward_efficiency_is_nan_when_the_denominator_is_not_positive():
    """A ratio through zero produces impressive nonsense; it must not be reported."""

    @dataclass
    class FakeFold:
        train_score: float
        test_score: float
        selected_params: dict
        candidates: List = None

    from quantlab.analytics.walkforward import WalkForwardResult
    from quantlab.analytics.metrics import compute_metrics

    result = WalkForwardResult(
        symbol="X", strategy="y",
        folds=[FakeFold(-1.0, -0.5, {"a": 1}), FakeFold(1.0, 0.2, {"a": 1})],
        equity_curve=pd.DataFrame(), trades=pd.DataFrame(),
        metrics=compute_metrics(pd.DataFrame(), pd.DataFrame(), initial_balance=1.0),
        initial_balance=1.0, selection_metric="sharpe_ratio", n_candidates=2,
    )
    assert math.isnan(result.walk_forward_efficiency())
    summary = result.score_summary()
    assert abs(summary["mean_in_sample_score"] - 0.0) < 1e-12
    assert summary["mean_out_of_sample_score"] < 0


def test_parameter_churn_measures_instability():
    result = run_walk_forward(
        _DF, "rsi_reversion", symbol="EURUSD",
        wf_config=WalkForwardConfig(train_bars=600, test_bars=200),
        param_grid=[{"rsi_period": 7, "trend_filter": 0},
                    {"rsi_period": 14, "trend_filter": 0}],
    )
    churn = result.parameter_churn()
    assert math.isnan(churn) or 0.0 <= churn <= 1.0


# --------------------------------------------------------------------------- #
# Monte Carlo
# --------------------------------------------------------------------------- #
def _fake_trades(returns, equity=100_000.0):
    return pd.DataFrame(
        {
            "net_pnl": [r * equity for r in returns],
            "equity_at_entry": [equity] * len(returns),
        }
    )


def test_monte_carlo_is_reproducible_for_a_fixed_seed():
    trades = _fake_trades(list(np.random.default_rng(1).normal(0.001, 0.02, 200)))
    a = run_monte_carlo(trades, MonteCarloConfig(n_simulations=300, seed=99))
    b = run_monte_carlo(trades, MonteCarloConfig(n_simulations=300, seed=99))
    assert np.allclose(a.max_drawdowns, b.max_drawdowns)
    c = run_monte_carlo(trades, MonteCarloConfig(n_simulations=300, seed=100))
    assert not np.allclose(a.max_drawdowns, c.max_drawdowns)


def test_drawdown_percentiles_are_positive_depths_ordered_correctly():
    """p95 must be a DEEPER drawdown than p50, not a shallower one.

    Quantiles of a signed (negative) drawdown read backwards; getting this wrong
    would invert the single most important risk number in the report.
    """
    trades = _fake_trades(list(np.random.default_rng(2).normal(0.0, 0.02, 300)))
    result = run_monte_carlo(trades, MonteCarloConfig(n_simulations=500, seed=7))
    dd = result.percentiles["max_drawdown"]
    assert dd["p50"] > 0 and dd["p95"] > dd["p50"] and dd["p99"] >= dd["p95"]
    assert result.observed_max_drawdown <= 0


def test_shuffle_preserves_the_multiset_of_outcomes():
    returns = [0.05, -0.02, 0.03, -0.04, 0.01] * 8
    result = run_monte_carlo(
        _fake_trades(returns), MonteCarloConfig(method="shuffle", n_simulations=200, seed=5)
    )
    expected_total = float(np.prod([1 + r for r in returns]) - 1)
    assert np.allclose(result.total_returns, expected_total, atol=1e-9)


def test_bootstrap_and_block_bootstrap_produce_wider_outcomes_than_shuffling():
    returns = list(np.random.default_rng(4).normal(0.002, 0.03, 150))
    shuffled = run_monte_carlo(
        _fake_trades(returns), MonteCarloConfig(method="shuffle", n_simulations=400, seed=11)
    )
    booted = run_monte_carlo(
        _fake_trades(returns), MonteCarloConfig(method="bootstrap", n_simulations=400, seed=11)
    )
    blocked = run_monte_carlo(
        _fake_trades(returns),
        MonteCarloConfig(method="block_bootstrap", block_size=10, n_simulations=400, seed=11),
    )
    assert booted.total_returns.std() > shuffled.total_returns.std()
    assert blocked.n_trades == booted.n_trades == len(returns)


def test_a_losing_system_almost_never_finishes_ahead():
    returns = [-0.01] * 50 + [0.005] * 50
    result = run_monte_carlo(
        _fake_trades(returns), MonteCarloConfig(n_simulations=400, seed=13)
    )
    assert result.prob_loss > 0.95


def test_monte_carlo_handles_an_empty_blotter():
    result = run_monte_carlo(pd.DataFrame())
    assert result.n_trades == 0
    assert any("undefined" in w for w in result.warnings)


def test_expected_losing_streak_grows_as_the_win_rate_falls():
    assert expected_losing_streak(0.6, 200) < expected_losing_streak(0.35, 200)
    # With a 40% win rate over 200 trades a run of ~8 losses is unremarkable.
    assert 6 < expected_losing_streak(0.40, 200) < 12
    assert 0.0 < streak_probability(0.40, 200, 8) < 1.0
    assert streak_probability(0.40, 200, 30) < 0.01


# --------------------------------------------------------------------------- #
# overfitting diagnostics
# --------------------------------------------------------------------------- #
def test_normal_helpers_match_standard_values():
    for p, z in [(0.975, 1.959964), (0.95, 1.644854), (0.5, 0.0), (0.01, -2.326348)]:
        assert abs(norm_ppf(p) - z) < 1e-5
    assert abs(norm_cdf(1.959964) - 0.975) < 1e-6


def test_expected_max_null_sharpe_grows_with_the_number_of_trials():
    one = expected_max_sharpe_null(1, 750)
    few = expected_max_sharpe_null(10, 750)
    many = expected_max_sharpe_null(1000, 750)
    assert one == 0.0 < few < many
    # Searching two dozen variants over three years buys a respectable Sharpe free.
    assert 0.8 < expected_max_sharpe_null(24, 750) < 1.6


def test_expected_max_null_sharpe_falls_as_the_sample_grows():
    assert expected_max_sharpe_null(50, 250) > expected_max_sharpe_null(50, 2500)


def test_deflated_sharpe_penalises_search_and_fat_tails():
    modest = deflated_sharpe_ratio(1.0, 750, 24, skew=0.0, excess_kurtosis=0.0)
    strong = deflated_sharpe_ratio(2.5, 750, 24, skew=0.0, excess_kurtosis=0.0)
    assert 0.0 <= modest < strong <= 1.0

    clean = deflated_sharpe_ratio(1.8, 750, 24, skew=0.0, excess_kurtosis=0.0)
    ugly = deflated_sharpe_ratio(1.8, 750, 24, skew=-1.5, excess_kurtosis=8.0)
    assert ugly < clean, "negative skew and fat tails must reduce confidence"

    unsearched = deflated_sharpe_ratio(1.8, 750, 1)
    searched = deflated_sharpe_ratio(1.8, 750, 200)
    assert searched < unsearched


def test_haircut_can_be_negative_when_the_result_is_worse_than_search_luck():
    assert haircut_sharpe(0.4, 100, 750) < 0
    assert haircut_sharpe(3.0, 5, 750) > 0


def test_multiple_testing_adjustments_are_conservative_and_bounded():
    assert abs(bonferroni_p(0.01, 10) - 0.10) < 1e-12
    assert bonferroni_p(0.5, 10) == 1.0
    assert sidak_p(0.01, 10) < bonferroni_p(0.01, 10)
    assert 0.0 <= sidak_p(0.03, 24) <= 1.0


def test_spearman_correlation_matches_known_cases():
    assert abs(spearman_correlation([1, 2, 3, 4], [10, 20, 30, 40]) - 1.0) < 1e-12
    assert abs(spearman_correlation([1, 2, 3, 4], [40, 30, 20, 10]) + 1.0) < 1e-12
    assert abs(spearman_correlation([1, 2, 3, 4, 5], [2, 1, 4, 3, 5])) < 1.0


@dataclass
class _Cand:
    train_score: float
    test_score: float


@dataclass
class _Fold:
    candidates: list


def test_pbo_is_high_when_in_sample_ranking_is_reversed_out_of_sample():
    folds = [
        _Fold([_Cand(train_score=s, test_score=-s) for s in (1.0, 2.0, 3.0, 4.0, 5.0)])
        for _ in range(10)
    ]
    result = probability_of_backtest_overfitting(folds)
    assert result.pbo == 1.0
    assert result.rank_correlation < -0.9


def test_pbo_is_low_when_in_sample_ranking_carries_over():
    folds = [
        _Fold([_Cand(train_score=s, test_score=s * 0.8) for s in (1.0, 2.0, 3.0, 4.0, 5.0)])
        for _ in range(10)
    ]
    result = probability_of_backtest_overfitting(folds)
    assert result.pbo == 0.0
    assert result.rank_correlation > 0.9


def test_pbo_is_about_half_when_selection_is_random():
    rng = np.random.default_rng(21)
    folds = [
        _Fold([_Cand(float(rng.normal()), float(rng.normal())) for _ in range(12)])
        for _ in range(120)
    ]
    result = probability_of_backtest_overfitting(folds)
    assert 0.35 < result.pbo < 0.65
    assert abs(result.rank_correlation) < 0.15


def test_pbo_reports_when_it_cannot_be_estimated():
    assert math.isnan(probability_of_backtest_overfitting([]).pbo)
    assert probability_of_backtest_overfitting([_Fold([_Cand(1.0, 1.0)])]).n_folds_used == 0


def test_overfitting_report_flags_a_result_that_is_pure_search_luck():
    report = build_overfitting_report(
        label="TEST/strategy", observed_sharpe=0.6, raw_p_value=0.30,
        n_obs=750, n_trials=24, skew=-1.0, excess_kurtosis=6.0,
        folds=[
            _Fold([_Cand(train_score=s, test_score=-s) for s in (1.0, 2.0, 3.0, 4.0)])
            for _ in range(8)
        ],
        parameter_churn=0.9, in_sample_sharpe=1.8, out_of_sample_sharpe=0.6,
    )
    assert report.flags, "a weak, heavily searched result must raise flags"
    joined = " ".join(report.flags)
    assert "search luck" in joined or "Deflated" in joined
    assert report.deflated_sharpe < 0.95
    assert report.haircut_sharpe < 0


def test_overfitting_report_states_plainly_when_there_is_nothing_to_explain():
    report = build_overfitting_report(
        label="TEST/strategy", observed_sharpe=-0.8, raw_p_value=0.4,
        n_obs=500, n_trials=16,
    )
    assert any("no positive result" in f.lower() for f in report.flags)
