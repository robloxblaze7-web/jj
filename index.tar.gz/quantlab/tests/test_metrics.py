"""Performance metrics: verified against values computed by hand."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd

from quantlab.analytics.metrics import (
    compute_metrics,
    drawdown_stats,
    excess_kurtosis,
    max_consecutive,
    monthly_returns,
    r_multiple_stats,
    rolling_sharpe,
    skewness,
    streak_summary,
    two_sided_p_value,
)
from quantlab.backtest import run_backtest
from quantlab.data import generate_ohlcv
from quantlab.strategies import build_strategy


def _equity(values, start="2020-01-01", freq="B"):
    return pd.Series(
        [float(v) for v in values],
        index=pd.date_range(start, periods=len(values), freq=freq, name="timestamp"),
    )


def _blotter(pnls, risk=100.0, equity_at_entry=10_000.0):
    n = len(pnls)
    return pd.DataFrame(
        {
            "net_pnl": [float(p) for p in pnls],
            "risk_amount": [risk] * n,
            "r_multiple": [float(p) / risk for p in pnls],
            "bars_held": [3] * n,
            "total_costs": [1.0] * n,
            "equity_at_entry": [equity_at_entry] * n,
        }
    )


def test_max_drawdown_and_recovery_are_correct():
    eq = _equity([100, 110, 121, 108.9, 119.79, 130])
    stats = drawdown_stats(eq)
    assert abs(stats.max_drawdown + 0.10) < 1e-12          # 121 -> 108.9
    assert abs(stats.max_drawdown_cash + 12.1) < 1e-9
    assert stats.trough_date == eq.index[3]
    assert stats.recovery_date == eq.index[5]              # first bar back above 121
    assert stats.max_drawdown_bars == 1


def test_time_underwater_is_measured_not_guessed():
    eq = _equity([100, 90, 95, 99, 101])
    stats = drawdown_stats(eq)
    assert stats.longest_underwater_bars == 3
    assert abs(stats.time_underwater_fraction - 0.6) < 1e-12


def test_streaks_count_the_longest_run():
    assert max_consecutive([True, True, False, True, True, True]) == 3
    summary = streak_summary([1, 2, -1, -1, -1, 3, 4, -1])
    assert summary["max_consecutive_wins"] == 2
    assert summary["max_consecutive_losses"] == 3


def test_trade_statistics_match_hand_computation():
    pnls = [200, -100, 300, -100, -100, 400]
    metrics = compute_metrics(
        pd.DataFrame(
            {"equity": [10_000, 10_200, 10_100, 10_400, 10_300, 10_200, 10_600],
             "position_units": [0] * 7},
            index=pd.date_range("2020-01-01", periods=7, freq="B", name="timestamp"),
        ),
        _blotter(pnls),
        initial_balance=10_000.0,
    )
    assert metrics.n_trades == 6
    assert abs(metrics.win_rate - 0.5) < 1e-12                    # 3 of 6
    assert abs(metrics.average_win - 300.0) < 1e-9                # (200+300+400)/3
    assert abs(metrics.average_loss + 100.0) < 1e-9
    assert abs(metrics.win_loss_ratio - 3.0) < 1e-9
    assert abs(metrics.profit_factor - 3.0) < 1e-9                # 900 / 300
    assert abs(metrics.expectancy_cash - 100.0) < 1e-9            # 600 / 6
    assert abs(metrics.expectancy_r - 1.0) < 1e-9                 # risk = 100 per trade
    assert metrics.max_consecutive_losses == 2
    assert metrics.max_consecutive_wins == 1
    assert abs(metrics.best_trade - 400.0) < 1e-9
    assert abs(metrics.worst_trade + 100.0) < 1e-9
    assert abs(metrics.total_return - 0.06) < 1e-12


def test_cagr_uses_calendar_time():
    eq = _equity([100_000, 121_000], freq="730D")     # two bars, 730 days apart
    metrics = compute_metrics(
        pd.DataFrame({"equity": eq.to_numpy(), "position_units": [0, 0]}, index=eq.index),
        _blotter([21_000]),
        initial_balance=100_000.0,
    )
    assert abs(metrics.total_return - 0.21) < 1e-12
    assert abs(metrics.cagr - 0.10) < 0.002                       # ~10% per year


def test_sharpe_matches_the_definition_and_carries_a_standard_error():
    rng = np.random.default_rng(3)
    rets = rng.normal(0.0005, 0.01, 1000)
    equity = 100_000 * np.cumprod(1 + rets)
    frame = pd.DataFrame(
        {"equity": equity, "position_units": [1] * 1000},
        index=pd.date_range("2015-01-01", periods=1000, freq="B", name="timestamp"),
    )
    metrics = compute_metrics(frame, _blotter([1.0] * 40), initial_balance=100_000.0)

    realised = frame["equity"].pct_change().dropna()
    expected = realised.mean() / realised.std(ddof=1) * math.sqrt(252)
    assert abs(metrics.sharpe_ratio - expected) < 1e-9
    assert metrics.sharpe_standard_error > 0
    assert abs(metrics.sharpe_t_stat - metrics.sharpe_ratio / metrics.sharpe_standard_error) < 1e-9


def test_sortino_penalises_only_downside_deviation():
    """Adding upside volatility must not worsen Sortino, though it worsens Sharpe."""
    base = np.array([0.01, -0.01, 0.01, -0.01] * 60)
    upside = base.copy()
    upside[::4] = 0.08                                   # bigger wins only

    def _metrics(rets):
        equity = 100_000 * np.cumprod(1 + rets)
        frame = pd.DataFrame(
            {"equity": equity, "position_units": [1] * len(rets)},
            index=pd.date_range("2015-01-01", periods=len(rets), freq="B", name="timestamp"),
        )
        return compute_metrics(frame, _blotter([1.0] * 30), initial_balance=100_000.0)

    a, b = _metrics(base), _metrics(upside)
    assert b.sortino_ratio > a.sortino_ratio
    assert b.sortino_ratio > b.sharpe_ratio


def test_r_multiple_distribution_reports_the_sub_stop_tail():
    stats = r_multiple_stats([-1.0, -1.0, 2.0, 3.0, -1.0, -1.5, 4.0])
    assert stats.count == 7
    assert abs(stats.mean - float(np.mean([-1, -1, 2, 3, -1, -1.5, 4]))) < 1e-12
    assert abs(stats.fraction_beyond_full_stop - 1 / 7) < 1e-12
    assert stats.percentiles["p50"] == -1.0
    assert stats.min == -1.5 and stats.max == 4.0


def test_empty_inputs_produce_defined_metrics_not_a_crash():
    metrics = compute_metrics(pd.DataFrame(), pd.DataFrame(), initial_balance=10_000.0)
    assert metrics.n_trades == 0
    assert metrics.final_equity == 10_000.0
    assert any("Empty equity curve" in w for w in metrics.warnings)

    stats = r_multiple_stats([])
    assert stats.count == 0


def test_warnings_fire_on_small_samples_and_insignificant_sharpe():
    eq = _equity(list(np.linspace(100_000, 101_000, 60)))
    metrics = compute_metrics(
        pd.DataFrame({"equity": eq.to_numpy(), "position_units": [1] * 60}, index=eq.index),
        _blotter([10.0] * 5),
        initial_balance=100_000.0,
    )
    assert any("too few" in w for w in metrics.warnings)
    assert any("days" in w for w in metrics.warnings)          # sub-year annualisation


def test_skew_and_kurtosis_match_known_values():
    symmetric = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
    assert abs(skewness(symmetric)) < 1e-12
    right_tailed = np.array([1.0, 1.0, 1.0, 1.0, 10.0])
    assert skewness(right_tailed) > 1.0
    assert excess_kurtosis(np.array([1.0, 1.0, 1.0, 1.0, 10.0])) > 0


def test_p_value_helper_matches_standard_z_values():
    assert abs(two_sided_p_value(1.959964) - 0.05) < 1e-6
    assert abs(two_sided_p_value(0.0) - 1.0) < 1e-12


def test_monthly_returns_table_has_the_expected_shape():
    eq = _equity(list(np.linspace(100_000, 130_000, 500)))
    table = monthly_returns(eq)
    assert not table.empty
    assert table.columns.min() >= 1 and table.columns.max() <= 12
    assert table.notna().to_numpy().sum() > 12


def test_rolling_sharpe_is_defined_only_after_enough_history():
    rng = np.random.default_rng(5)
    rets = pd.Series(
        rng.normal(0.0004, 0.01, 800),
        index=pd.date_range("2018-01-01", periods=800, freq="B"),
    )
    rolling = rolling_sharpe(rets, window=252)
    assert rolling.iloc[:100].isna().all()
    assert rolling.iloc[-1] == rolling.iloc[-1]        # not NaN


def test_metrics_agree_with_the_engines_own_accounting():
    df = generate_ohlcv("SPX500", "2012-01-01", "2020-12-31", seed=43)
    result = run_backtest(df, build_strategy("momentum"), symbol="SPX500")
    from quantlab.analytics import metrics_from_result

    metrics = metrics_from_result(result)
    assert metrics.n_trades == result.n_trades
    assert abs(metrics.final_equity - result.final_equity) < 1e-9
    assert abs(metrics.total_return - (result.final_equity / result.initial_balance - 1)) < 1e-12
    assert abs(metrics.expectancy_cash - float(result.trades["net_pnl"].mean())) < 1e-9
