#!/usr/bin/env python3
"""Zero-dependency test runner.

The test files are written in plain pytest style (module-level ``test_*``
functions using bare ``assert``), so ``pytest -q`` runs them unchanged.  This
runner exists so the suite is also executable in an environment where pytest is
not installed — which is exactly the environment where you most want to know
whether the engine still balances its books.

Usage:
    python tests/run_tests.py            # run everything
    python tests/run_tests.py engine     # only files matching a substring
"""

from __future__ import annotations

import importlib.util
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))


def _load(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    # Register before executing: dataclasses declared inside a test module
    # resolve their annotations through ``sys.modules[cls.__module__]``, which
    # is None for a module that was never registered.
    sys.modules[path.stem] = module
    spec.loader.exec_module(module)
    return module


def main(argv: list[str]) -> int:
    pattern = argv[1] if len(argv) > 1 else ""
    files = sorted(p for p in (ROOT / "tests").glob("test_*.py") if pattern in p.name)
    if not files:
        print(f"no test files matched {pattern!r}")
        return 1

    passed = failed = 0
    failures: list[tuple[str, str]] = []
    started = time.time()

    for path in files:
        module = _load(path)
        names = sorted(n for n in dir(module) if n.startswith("test_") and callable(getattr(module, n)))
        print(f"\n{path.name}  ({len(names)} tests)")
        for name in names:
            try:
                getattr(module, name)()
            except Exception:
                failed += 1
                failures.append((f"{path.name}::{name}", traceback.format_exc()))
                print(f"  FAIL  {name}")
            else:
                passed += 1
                print(f"  ok    {name}")

    elapsed = time.time() - started
    print("\n" + "=" * 72)
    for label, tb in failures:
        print(f"\nFAILED {label}\n{tb}")
    print(f"{passed} passed, {failed} failed in {elapsed:.1f}s")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
