"""Data layer: schema enforcement, determinism, and split integrity."""

from __future__ import annotations

import numpy as np
import pandas as pd

from quantlab.config import SplitConfig, WalkForwardConfig
from quantlab.data import (
    DEFAULT_UNIVERSE,
    DataValidationError,
    assert_no_overlap,
    coerce_ohlcv,
    generate_ohlcv,
    three_way_split,
    validate_ohlcv,
    walk_forward_windows,
)

from helpers import make_bars


def test_coerce_accepts_vendor_column_spellings():
    raw = pd.DataFrame(
        {
            "Date": ["2024-01-01", "2024-01-02"],
            "Open": [1.0, 1.1], "High": [1.2, 1.2], "Low": [0.9, 1.0],
            "Adj Close": [1.1, 1.15], "Vol": [10, 20],
        }
    )
    df = coerce_ohlcv(raw)
    assert list(df.columns) == ["open", "high", "low", "close", "volume"]
    assert df.index.name == "timestamp"
    assert df.index.is_monotonic_increasing


def test_validate_rejects_bar_where_high_below_close():
    bad = make_bars([[100, 100.5, 99, 101]])   # close above high
    try:
        validate_ohlcv(bad, "BAD")
    except DataValidationError as exc:
        assert "bracket" in str(exc)
    else:
        raise AssertionError("a high below the close must be rejected")


def test_validate_rejects_non_positive_and_duplicate_and_unsorted():
    for frame, reason in [
        (make_bars([[100, 101, -1, 100]]), "non-positive"),
        (make_bars([[100, 101, 99, 100]] * 2).set_index(
            pd.DatetimeIndex(["2024-01-01", "2024-01-01"], name="timestamp")
        ), "duplicate"),
    ]:
        try:
            validate_ohlcv(frame, "BAD")
        except DataValidationError:
            pass
        else:
            raise AssertionError(f"{reason} data must be rejected")


def test_validate_rejects_nan_in_ohlc():
    bad = make_bars([[100, 101, 99, 100], [100, 101, 99, 100]])
    bad.iloc[1, bad.columns.get_loc("close")] = np.nan
    try:
        validate_ohlcv(bad, "BAD")
    except DataValidationError:
        pass
    else:
        raise AssertionError("NaN in OHLC must be rejected")


def test_synthetic_generator_is_deterministic():
    a = generate_ohlcv("EURUSD", "2015-01-01", "2018-12-31", seed=7)
    b = generate_ohlcv("EURUSD", "2015-01-01", "2018-12-31", seed=7)
    assert a.equals(b)
    c = generate_ohlcv("EURUSD", "2015-01-01", "2018-12-31", seed=8)
    assert not np.allclose(a["close"].to_numpy(), c["close"].to_numpy())


def test_synthetic_series_satisfy_the_ohlcv_contract():
    for symbol in ("EURUSD", "GBPUSD", "XAUUSD", "SPX500"):
        df = generate_ohlcv(symbol, "2015-01-01", "2018-12-31", seed=3)
        validate_ohlcv(df, symbol)          # raises on any violation
        assert df.attrs["synthetic"] is True
        assert (df["high"] >= df["low"]).all()


def test_synthetic_volatility_is_in_a_plausible_range():
    # A generator that produced 200% annualised vol would make every downstream
    # number meaningless while still passing the structural checks.
    for symbol, lo, hi in [("EURUSD", 0.03, 0.20), ("SPX500", 0.06, 0.40)]:
        df = generate_ohlcv(symbol, "2010-01-01", "2025-12-31", seed=11)
        rets = np.log(df["close"]).diff().dropna()
        ann = float(rets.std(ddof=1) * np.sqrt(252))
        assert lo < ann < hi, f"{symbol} annualised vol {ann:.2%} outside [{lo:.0%}, {hi:.0%}]"


def test_three_way_split_is_chronological_and_embargoed():
    idx = pd.date_range("2010-01-01", periods=1000, freq="B")
    splits = three_way_split(idx, SplitConfig(embargo_bars=20))
    train, val, test = splits["train"], splits["validation"], splits["test"]

    assert train.end_idx <= val.start_idx and val.end_idx <= test.start_idx
    assert val.start_idx - train.end_idx == 20
    assert test.start_idx - val.end_idx == 20
    assert train.n_bars + val.n_bars + test.n_bars == 1000 - 40


def test_walk_forward_windows_never_overlap_their_training_data():
    idx = pd.date_range("2010-01-01", periods=3000, freq="B")
    windows = walk_forward_windows(idx, WalkForwardConfig(train_bars=500, test_bars=200))
    assert len(windows) > 5
    assert_no_overlap(windows)                     # raises if it is not out-of-sample
    for w in windows:
        assert w.test_start_idx >= w.train_end_idx + 5      # embargo respected
        assert w.n_train == 500


def test_anchored_walk_forward_grows_the_training_window():
    idx = pd.date_range("2010-01-01", periods=3000, freq="B")
    windows = walk_forward_windows(
        idx, WalkForwardConfig(train_bars=500, test_bars=200, anchored=True)
    )
    assert all(w.train_start_idx == 0 for w in windows)
    assert windows[-1].n_train > windows[0].n_train


def test_survivorship_audit_flags_a_window_before_listing():
    warnings = DEFAULT_UNIVERSE.audit_survivorship(["EURUSD"], "1995-01-01", "2020-01-01")
    assert warnings and "not listed" in warnings[0]
    assert not DEFAULT_UNIVERSE.audit_survivorship(["EURUSD"], "2005-01-01", "2020-01-01")


def test_universe_active_at_respects_listing_dates():
    assert "EURUSD" not in DEFAULT_UNIVERSE.active_at("1995-01-01")
    assert "EURUSD" in DEFAULT_UNIVERSE.active_at("2015-01-01")


def test_position_size_rounds_down_never_up():
    spec = DEFAULT_UNIVERSE.get("EURUSD")           # unit step 1000
    assert spec.round_units(1999.0) == 1000.0
    assert spec.round_units(999.0) == 0.0
