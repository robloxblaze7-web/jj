"""Charts and report generation, including the no-profitability-claim guarantee."""

from __future__ import annotations

import re
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from quantlab.analytics import (
    metrics_from_result,
    monthly_returns,
    rolling_sharpe,
    run_monte_carlo,
    run_walk_forward,
)
from quantlab.analytics.overfitting import build_overfitting_report
from quantlab.backtest import run_backtest
from quantlab.config import MonteCarloConfig, WalkForwardConfig
from quantlab.data import DEFAULT_UNIVERSE, generate_ohlcv, quality_report
from quantlab.reporting import RunRecord, build_report, charts
from quantlab.strategies import build_strategy

_DF = generate_ohlcv("EURUSD", "2012-01-01", "2020-12-31", seed=53)


def _result():
    return run_backtest(_DF, build_strategy("breakout"), symbol="EURUSD")


def test_every_chart_renders_to_a_non_trivial_file():
    result = _result()
    equity = result.equity_curve["equity"]
    mc = run_monte_carlo(result.trades, MonteCarloConfig(n_simulations=200, seed=3))

    with tempfile.TemporaryDirectory() as tmp:
        paths = charts.chart_set(
            equity=equity, trades=result.trades, monthly=monthly_returns(equity),
            rolling=rolling_sharpe(result.returns), outdir=tmp, prefix="test",
            caption="SYNTHETIC DATA — test render",
            mc_drawdowns=mc.max_drawdowns, mc_observed=mc.observed_max_drawdown,
        )
        assert set(paths) >= {"equity", "drawdown", "monthly", "trades", "rolling_sharpe"}
        for name, path in paths.items():
            size = Path(path).stat().st_size
            assert size > 5_000, f"{name} rendered a suspiciously small file ({size} bytes)"


def test_charts_survive_degenerate_inputs():
    """No trades, no months, no rolling window — must render, not crash."""
    empty_equity = pd.Series(
        [100_000.0, 100_000.0],
        index=pd.date_range("2024-01-01", periods=2, freq="B", name="timestamp"),
    )
    with tempfile.TemporaryDirectory() as tmp:
        charts.plot_equity_curve(empty_equity, Path(tmp) / "e.png")
        charts.plot_drawdown(empty_equity, Path(tmp) / "d.png")
        charts.plot_monthly_returns(pd.DataFrame(), Path(tmp) / "m.png")
        charts.plot_trade_distribution([], Path(tmp) / "t.png")
        charts.plot_rolling_sharpe(pd.Series(dtype="float64"), Path(tmp) / "r.png")
        charts.plot_walk_forward_folds(pd.DataFrame(), Path(tmp) / "f.png")
        assert len(list(Path(tmp).glob("*.png"))) == 6


def test_dark_theme_renders_with_a_different_background():
    equity = _result().equity_curve["equity"]
    with tempfile.TemporaryDirectory() as tmp:
        light = charts.plot_equity_curve(equity, Path(tmp) / "l.png", theme=charts.LIGHT)
        dark = charts.plot_equity_curve(equity, Path(tmp) / "dk.png", theme=charts.DARK)
        assert Path(light).read_bytes() != Path(dark).read_bytes()


def _record() -> RunRecord:
    wf = run_walk_forward(
        _DF, "ma_crossover", symbol="EURUSD",
        wf_config=WalkForwardConfig(train_bars=600, test_bars=200),
        param_grid=[{"fast": 10, "slow": 50}, {"fast": 20, "slow": 100}],
    )
    mc = run_monte_carlo(wf.trades, MonteCarloConfig(n_simulations=200, seed=5))
    of = build_overfitting_report(
        label="EURUSD/ma_crossover", observed_sharpe=wf.metrics.sharpe_ratio,
        raw_p_value=wf.metrics.sharpe_p_value, n_obs=max(len(wf.equity_curve), 2),
        n_trials=wf.n_candidates, skew=wf.metrics.return_skew,
        excess_kurtosis=wf.metrics.return_excess_kurtosis, folds=wf.folds,
        parameter_churn=wf.parameter_churn(),
    )
    return RunRecord(
        symbol="EURUSD", strategy="ma_crossover", walk_forward=wf,
        oos_metrics=wf.metrics, monte_carlo=mc, overfitting=of,
        cost_sensitivity={"1x costs": -0.1, "2x costs": -0.2},
    )


def _build() -> str:
    record = _record()
    return build_report(
        title="Test report",
        records=[record],
        config={"backtest": {"risk": {}, "costs": {}}, "version": "test"},
        instruments=[
            {
                "symbol": s, "asset_class": DEFAULT_UNIVERSE.get(s).asset_class,
                "typical_spread": DEFAULT_UNIVERSE.get(s).typical_spread,
                "commission_rate": DEFAULT_UNIVERSE.get(s).commission_rate,
                "margin_rate": DEFAULT_UNIVERSE.get(s).margin_rate,
                "financing_rate_annual_long": DEFAULT_UNIVERSE.get(s).financing_rate_annual_long,
                "financing_rate_annual_short": DEFAULT_UNIVERSE.get(s).financing_rate_annual_short,
            }
            for s in ("EURUSD",)
        ],
        quality=quality_report({"EURUSD": _DF}),
        provenance=[_DF.attrs["provenance"]],
        survivorship_notes=DEFAULT_UNIVERSE.survivorship_notes(),
        survivorship_warnings=[],
        synthetic=True,
    )


def _flat(text: str) -> str:
    """Collapse markdown line wrapping so phrase checks are not defeated by it."""
    return re.sub(r"\s+", " ", text.replace("\n>", " "))


def test_report_contains_the_mandatory_disclosures():
    text = _flat(_build())
    required = [
        "research and paper-trading system",
        "no broker connectivity",
        "SYNTHETIC DATA",
        "A backtest cannot establish that a strategy is profitable",
        "Historical performance is not evidence of future performance",
        "Limitations",
        "Probability of backtest overfitting",
        "Monte Carlo",
        "R-multiple distribution",
    ]
    for phrase in required:
        assert phrase in text, f"report is missing the required disclosure: {phrase!r}"


def test_report_never_claims_a_strategy_is_profitable():
    """The guarantee is structural: no template in the module can produce a claim.

    Two checks. First, phrases that are always illegitimate. Second — the subtler
    one — every sentence that mentions profitability at all must be a negation or
    a caveat, never an assertion.
    """
    text = _flat(_build()).lower()

    always_forbidden = [
        r"\bwill be profitable\b", r"\bproven strategy\b", r"\bguaranteed\b",
        r"\bready to trade live\b", r"\brecommend trading\b", r"\bsafe bet\b",
        r"\bcan.t lose\b", r"\brisk[- ]free\b", r"\bshould be traded\b",
        r"\bthis strategy works\b", r"\bedge is real\b",
    ]
    for pattern in always_forbidden:
        assert not re.search(pattern, text), f"report makes a claim it must not: {pattern}"

    negations = ("cannot", "not ", "never", "no ", "without", "discount", "unless")
    for sentence in re.split(r"(?<=[.!?]) ", text):
        if "profitab" in sentence:
            assert any(n in sentence for n in negations), (
                f"profitability is mentioned without a negation or caveat: {sentence!r}"
            )


def test_report_pairs_every_performance_figure_with_its_search_count():
    text = _build()
    assert "Configurations searched per fold" in text
    assert "Expected best-of-N Sharpe under the null" in text
    assert "Deflated Sharpe ratio" in text


def test_report_states_the_falsification_criteria():
    text = _build()
    assert "What would falsify a positive result here" in text
    assert "Any single failure is sufficient to discard it" in text
