"""Strategies: output contract, causality, and parameter validation."""

from __future__ import annotations

import numpy as np
import pandas as pd

from quantlab.data import generate_ohlcv
from quantlab.strategies import (
    STRATEGY_REGISTRY,
    StrategyError,
    all_strategy_names,
    build_strategy,
    strategy_grid,
)

_DF = generate_ohlcv("EURUSD", "2012-01-01", "2020-12-31", seed=41)


def test_all_four_baseline_strategies_are_registered():
    assert set(all_strategy_names()) == {
        "ma_crossover", "breakout", "rsi_reversion", "momentum"
    }


def test_signals_obey_the_contract():
    for name in all_strategy_names():
        strategy = build_strategy(name)
        signals = strategy.generate_signals(_DF)
        assert signals.index.equals(_DF.index), f"{name}: index changed"
        assert signals.isin([-1.0, 0.0, 1.0]).all(), f"{name}: values outside -1/0/+1"
        assert not signals.isna().any(), f"{name}: NaN leaked into signals"
        assert (signals.iloc[: strategy.lookback] == 0).all(), f"{name}: traded during warm-up"


def test_signals_are_causal():
    """A prefix of the data must produce a prefix of the signals."""
    for name in all_strategy_names():
        strategy = build_strategy(name)
        full = strategy.generate_signals(_DF)
        prefix = strategy.generate_signals(_DF.iloc[:1200])
        assert np.allclose(full.iloc[:1200].to_numpy(), prefix.to_numpy()), f"{name} peeks"


def test_long_only_mode_removes_every_short():
    for name in all_strategy_names():
        signals = build_strategy(name, long_only=True).generate_signals(_DF)
        assert (signals >= 0).all(), f"{name}: short signal survived long_only"


def test_every_grid_combination_constructs_and_runs():
    for name in all_strategy_names():
        grid = strategy_grid(name)
        assert len(grid) >= 4, f"{name}: grid is suspiciously small"
        for params in grid:
            strategy = build_strategy(name, params)
            signals = strategy.generate_signals(_DF.iloc[:900])
            assert signals.isin([-1.0, 0.0, 1.0]).all()


def test_invalid_parameters_are_rejected():
    cases = [
        ("ma_crossover", {"fast": 100, "slow": 20}),      # fast must be shorter
        ("ma_crossover", {"ma_type": "hull"}),            # unsupported average
        ("breakout", {"entry_lookback": 1}),
        ("rsi_reversion", {"oversold": 80.0, "overbought": 20.0}),
        ("rsi_reversion", {"exit_level": 95.0}),          # outside the band
        ("momentum", {"lookback": 1}),
    ]
    for name, params in cases:
        try:
            build_strategy(name, params)
        except StrategyError:
            pass
        else:
            raise AssertionError(f"{name} accepted invalid parameters {params}")


def test_unknown_parameter_names_are_rejected_rather_than_ignored():
    """A silently ignored typo is a config bug that changes results invisibly."""
    try:
        build_strategy("ma_crossover", {"fastt": 10})
    except StrategyError as exc:
        assert "unknown parameter" in str(exc)
    else:
        raise AssertionError("a misspelled parameter must raise")


def test_breakout_enters_only_after_the_prior_channel_is_exceeded():
    """A rising staircase must not trigger an entry on every new high."""
    n = 80
    close = np.linspace(100.0, 100.5, n)          # drifts up by less than the channel
    df = pd.DataFrame(
        {"open": close, "high": close + 0.01, "low": close - 0.01, "close": close,
         "volume": 1.0},
        index=pd.date_range("2024-01-01", periods=n, freq="B", name="timestamp"),
    )
    signals = build_strategy("breakout", {"entry_lookback": 20, "exit_lookback": 10}).generate_signals(df)
    entries = int(((signals != 0) & (signals.shift(1).fillna(0) == 0)).sum())
    assert entries <= 1, "a smooth drift should not look like repeated breakouts"


def test_rsi_reversion_buys_weakness_and_sells_strength():
    strategy = build_strategy("rsi_reversion", {"trend_filter": 0, "rsi_period": 7})
    signals = strategy.generate_signals(_DF)
    from quantlab.indicators import rsi

    values = rsi(_DF["close"], 7)
    entries = (signals != 0) & (signals.shift(1).fillna(0) == 0)
    longs = values[entries & (signals > 0)]
    shorts = values[entries & (signals < 0)]
    assert (longs <= 30.0 + 1e-9).all(), "long entries must be oversold"
    assert (shorts >= 70.0 - 1e-9).all(), "short entries must be overbought"


def test_momentum_skip_bars_excludes_the_most_recent_bars():
    with_skip = build_strategy("momentum", {"skip_bars": 5}).generate_signals(_DF)
    without_skip = build_strategy("momentum", {"skip_bars": 0}).generate_signals(_DF)
    assert not np.allclose(with_skip.to_numpy(), without_skip.to_numpy())


def test_strategy_classes_expose_a_lookback_that_covers_their_indicators():
    for name, cls in STRATEGY_REGISTRY.items():
        strategy = cls()
        assert strategy.lookback >= 2, f"{name}: implausible lookback"
        for params in cls.param_grid():
            assert cls(**params).lookback >= 2
