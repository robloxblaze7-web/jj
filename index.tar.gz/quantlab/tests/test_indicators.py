"""Indicators: causality (no look-ahead) and correctness against hand values."""

from __future__ import annotations

import numpy as np
import pandas as pd

import quantlab.indicators as ind
from quantlab.data import generate_ohlcv

_DF = generate_ohlcv("EURUSD", "2015-01-01", "2020-12-31", seed=5)
_CLOSE = _DF["close"]


def test_every_public_indicator_is_causal():
    """Recomputing on a prefix must not change any overlapping value.

    This is the check that catches a centred window, a negative shift, or a
    full-sample statistic sneaking into an indicator.
    """
    series_cases = {
        "sma": {"window": 20}, "ema": {"window": 20}, "rolling_std": {"window": 20},
        "rolling_zscore": {"window": 20}, "rolling_max": {"window": 20},
        "rolling_min": {"window": 20}, "rsi": {"window": 14}, "roc": {"window": 10},
        "log_momentum": {"window": 10}, "slope": {"window": 20},
        "realised_vol": {"window": 20}, "wilder_rma": {"window": 14},
    }
    frame_cases = {"true_range": {}, "atr": {"window": 14}, "donchian": {"window": 20}}

    for name, kwargs in series_cases.items():
        assert ind.check_causal(getattr(ind, name), _CLOSE, **kwargs), f"{name} uses future data"
    for name, kwargs in frame_cases.items():
        assert ind.check_causal(getattr(ind, name), _DF, **kwargs), f"{name} uses future data"


def test_a_deliberately_peeking_indicator_fails_the_causality_check():
    """The check must be able to fail, or it is not evidence of anything."""

    def cheating(series: pd.Series, window: int = 5) -> pd.Series:
        return series.shift(-window)            # looks into the future by construction

    assert not ind.check_causal(cheating, _CLOSE, window=5)


def test_rsi_matches_a_hand_calculation():
    # Wilder's worked example. First 14 changes: gains sum 3.34 (avg 0.238571),
    # losses sum 1.40 (avg 0.10) -> RS 2.385714 -> RSI 70.4640.
    prices = pd.Series(
        [44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08,
         45.89, 46.03, 45.61, 46.28, 46.28, 46.00]
    )
    rsi = ind.rsi(prices, 14).dropna()
    assert abs(float(rsi.iloc[0]) - 70.4640) < 0.001
    assert abs(float(rsi.iloc[1]) - 66.2496) < 0.001


def test_rsi_is_bounded_and_neutral_on_a_flat_series():
    values = ind.rsi(_CLOSE, 14).dropna()
    assert values.between(0, 100).all()
    flat = pd.Series([100.0] * 40)
    assert abs(float(ind.rsi(flat, 14).iloc[-1]) - 50.0) < 1e-9


def test_true_range_and_atr_match_hand_values():
    df = pd.DataFrame(
        {"open": [10, 11, 12], "high": [11, 13, 12.5], "low": [9, 10.5, 11],
         "close": [10.5, 12, 11.5]},
        index=pd.date_range("2024-01-01", periods=3, freq="B"),
    )
    tr = ind.true_range(df)
    assert abs(float(tr.iloc[0]) - 2.0) < 1e-12          # first bar: high - low
    assert abs(float(tr.iloc[1]) - 2.5) < 1e-12          # high 13 - prev close 10.5
    assert abs(float(tr.iloc[2]) - 1.5) < 1e-12          # high 12.5 - low 11
    atr2 = ind.atr(df, 2)
    assert abs(float(atr2.iloc[1]) - 2.25) < 1e-12       # seed = mean(2.0, 2.5)
    assert abs(float(atr2.iloc[2]) - (2.25 + (1.5 - 2.25) / 2)) < 1e-12


def test_channel_indicators_exclude_the_current_bar_by_default():
    """The bug this prevents: 'broke out' silently becoming 'is the highest bar'."""
    prices = pd.Series([1.0, 2.0, 3.0, 10.0, 4.0])
    excl = ind.rolling_max(prices, 2)                    # default exclude_current=True
    incl = ind.rolling_max(prices, 2, exclude_current=False)
    assert float(excl.iloc[3]) == 3.0                    # prior two bars only
    assert float(incl.iloc[3]) == 10.0                   # includes today's own high
    assert bool(prices.iloc[3] > excl.iloc[3]) and not bool(prices.iloc[3] > incl.iloc[3])


def test_wilder_rma_is_independent_of_how_much_history_was_loaded():
    long_run = ind.wilder_rma(_CLOSE, 14)
    short_run = ind.wilder_rma(_CLOSE.iloc[:400], 14)
    assert np.allclose(
        long_run.iloc[:400].to_numpy(), short_run.to_numpy(), equal_nan=True, atol=1e-12
    )


def test_indicators_reject_invalid_windows():
    for bad in (0, -3, 2.5):
        try:
            ind.sma(_CLOSE, bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"window={bad!r} should be rejected")
