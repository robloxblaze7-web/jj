"""Cost model and position sizing: hand-checked arithmetic."""

from __future__ import annotations

import numpy as np
import pandas as pd

from quantlab.backtest.costs import CostModel
from quantlab.config import CostConfig, RiskConfig
from quantlab.data.universe import DEFAULT_UNIVERSE
from quantlab.risk import RiskLimits, size_position, stop_and_target

from helpers import TEST_SPEC

_SPEC = TEST_SPEC.with_overrides(typical_spread=0.10, commission_rate=1e-4, margin_rate=0.02)
_MODEL = CostModel(_SPEC, CostConfig(slippage_bps=10.0, slippage_atr_fraction=0.5))


def test_buying_fills_above_and_selling_below_the_reference():
    buy, spread, slip = _MODEL.fill_price(1, 100.0, atr_value=1.0, is_entry=True)
    sell, _, _ = _MODEL.fill_price(-1, 100.0, atr_value=1.0, is_entry=True)
    # half spread 0.05 + slippage (10bp of 100 = 0.10, plus 0.5 * ATR 1.0 = 0.50)
    assert abs(spread - 0.05) < 1e-12
    assert abs(slip - 0.60) < 1e-12
    assert abs(buy - 100.65) < 1e-12
    assert abs(sell - 99.35) < 1e-12


def test_slippage_grows_with_volatility():
    calm = _MODEL.slippage_per_unit(100.0, atr_value=0.5)
    wild = _MODEL.slippage_per_unit(100.0, atr_value=5.0)
    assert wild > calm > 0


def test_slippage_is_never_favourable():
    for atr in (0.0, np.nan, -1.0, 3.0):
        assert _MODEL.slippage_per_unit(100.0, atr) >= 0.0


def test_commission_scales_with_notional():
    assert abs(_MODEL.commission(1000.0, 100.0) - 1000 * 100 * 1e-4) < 1e-12
    assert _MODEL.commission(2000.0, 100.0) == 2 * _MODEL.commission(1000.0, 100.0)


def test_financing_is_charged_in_both_directions_and_scales_with_time():
    spec = _SPEC.with_overrides(
        financing_rate_annual_long=0.05, financing_rate_annual_short=0.02
    )
    model = CostModel(spec, CostConfig(), bars_per_year=252.0)
    long_cost = model.financing_cost(1000.0, 100.0, direction=1, bars=1)
    short_cost = model.financing_cost(1000.0, 100.0, direction=-1, bars=1)
    assert abs(long_cost - 100_000 * 0.05 / 252) < 1e-9
    assert abs(short_cost - 100_000 * 0.02 / 252) < 1e-9
    assert long_cost > 0 and short_cost > 0                       # both are costs
    assert abs(model.financing_cost(1000.0, 100.0, 1, bars=10) - 10 * long_cost) < 1e-9


def test_fixed_risk_sizing_risks_exactly_the_configured_fraction():
    cfg = RiskConfig(sizing_method="fixed_risk", risk_per_trade=0.01,
                     max_account_leverage=1000.0, max_position_fraction=1000.0)
    decision = size_position(
        equity=100_000.0, price=50.0, stop_distance=2.0, atr_value=1.0,
        spec=TEST_SPEC, cfg=cfg,
    )
    assert abs(decision.units - 500.0) < 1e-9          # 1,000 risked / 2.0 per unit
    assert abs(decision.risk_amount - 1000.0) < 1e-9


def test_sizing_shrinks_as_equity_falls():
    cfg = RiskConfig(risk_per_trade=0.01, max_account_leverage=1000.0,
                     max_position_fraction=1000.0)
    big = size_position(equity=100_000.0, price=50.0, stop_distance=2.0,
                        atr_value=1.0, spec=TEST_SPEC, cfg=cfg)
    small = size_position(equity=50_000.0, price=50.0, stop_distance=2.0,
                          atr_value=1.0, spec=TEST_SPEC, cfg=cfg)
    assert small.units < big.units


def test_each_cap_binds_and_is_reported():
    base = dict(equity=100_000.0, price=50.0, stop_distance=0.01, atr_value=1.0,
                spec=TEST_SPEC)
    position_capped = size_position(
        **base, cfg=RiskConfig(risk_per_trade=0.5, max_position_fraction=1.0,
                               max_account_leverage=1000.0)
    )
    assert position_capped.capped_by == "max_position_fraction"
    assert position_capped.notional <= 100_000.0 + 1e-6

    leverage_capped = size_position(
        **base, cfg=RiskConfig(risk_per_trade=0.5, max_position_fraction=1000.0,
                               max_account_leverage=2.0)
    )
    assert leverage_capped.capped_by == "max_account_leverage"
    assert leverage_capped.notional <= 200_000.0 + 1e-6


def test_existing_exposure_consumes_the_leverage_budget():
    cfg = RiskConfig(risk_per_trade=0.5, max_position_fraction=1000.0,
                     max_account_leverage=2.0)
    fresh = size_position(equity=100_000.0, price=50.0, stop_distance=0.01,
                          atr_value=1.0, spec=TEST_SPEC, cfg=cfg)
    loaded = size_position(equity=100_000.0, price=50.0, stop_distance=0.01,
                           atr_value=1.0, spec=TEST_SPEC, cfg=cfg,
                           existing_notional=150_000.0)
    assert loaded.notional < fresh.notional


def test_sizes_are_rounded_down_to_the_tradeable_increment():
    spec = DEFAULT_UNIVERSE.get("EURUSD")           # 1,000-unit steps
    cfg = RiskConfig(risk_per_trade=0.01, max_account_leverage=1000.0,
                     max_position_fraction=1000.0)
    decision = size_position(equity=100_000.0, price=1.1, stop_distance=0.0057,
                             atr_value=0.003, spec=spec, cfg=cfg)
    assert decision.units % 1000 == 0
    assert decision.risk_amount <= 1000.0 + 1e-6    # never above the configured risk


def test_a_size_below_the_minimum_is_rejected_not_rounded_up():
    spec = DEFAULT_UNIVERSE.get("EURUSD")
    cfg = RiskConfig(risk_per_trade=0.0001, max_account_leverage=1000.0,
                     max_position_fraction=1000.0)
    decision = size_position(equity=1_000.0, price=1.1, stop_distance=0.02,
                             atr_value=0.01, spec=spec, cfg=cfg)
    assert not decision.is_tradeable
    assert decision.rejected_reason == "below_min_size"


def test_vol_target_sizing_equalises_risk_across_volatility():
    cfg = RiskConfig(sizing_method="vol_target", target_annual_vol=0.10,
                     max_account_leverage=1000.0, max_position_fraction=1000.0)
    calm = size_position(equity=100_000.0, price=100.0, stop_distance=1.0,
                         atr_value=0.5, spec=TEST_SPEC, cfg=cfg)
    wild = size_position(equity=100_000.0, price=100.0, stop_distance=1.0,
                         atr_value=2.0, spec=TEST_SPEC, cfg=cfg)
    assert wild.units < calm.units
    # Equal volatility contribution: units x ATR should match, up to the
    # rounding-down that the tradeable increment imposes.
    calm_vol = calm.units * 0.5
    wild_vol = wild.units * 2.0
    assert abs(wild_vol - calm_vol) / calm_vol < 0.01


def test_stops_and_targets_sit_on_the_correct_side_of_the_entry():
    cfg = RiskConfig(stop_atr_multiple=2.0, take_profit_atr_multiple=3.0)
    long_stop, long_target = stop_and_target(
        direction=1, entry_price=100.0, atr_value=1.5, cfg=cfg, spec=TEST_SPEC
    )
    short_stop, short_target = stop_and_target(
        direction=-1, entry_price=100.0, atr_value=1.5, cfg=cfg, spec=TEST_SPEC
    )
    assert abs(long_stop - 97.0) < 1e-9 and abs(long_target - 104.5) < 1e-9
    assert abs(short_stop - 103.0) < 1e-9 and abs(short_target - 95.5) < 1e-9


def test_a_stop_requires_a_positive_atr():
    for bad_atr in (0.0, -1.0, float("nan")):
        try:
            stop_and_target(direction=1, entry_price=100.0, atr_value=bad_atr,
                            cfg=RiskConfig(), spec=TEST_SPEC)
        except ValueError:
            pass
        else:
            raise AssertionError("a position must never be opened without a stop")


def test_take_profit_can_be_disabled():
    cfg = RiskConfig(stop_atr_multiple=2.0, take_profit_atr_multiple=0.0)
    _, target = stop_and_target(direction=1, entry_price=100.0, atr_value=1.0,
                                cfg=cfg, spec=TEST_SPEC)
    assert target is None


def test_drawdown_kill_switch_blocks_entries_permanently():
    limits = RiskLimits(RiskConfig(max_drawdown_stop=0.20), initial_equity=100_000.0)
    ts = pd.Timestamp("2024-01-01")
    limits.update(ts, 100_000.0)
    assert limits.can_open(ts)[0]
    limits.update(ts + pd.Timedelta(days=1), 79_000.0)         # -21%
    assert limits.kill_switch_active
    assert not limits.can_open(ts + pd.Timedelta(days=2))[0]
    limits.update(ts + pd.Timedelta(days=3), 150_000.0)        # recovery does not reset it
    assert not limits.can_open(ts + pd.Timedelta(days=4))[0]


def test_daily_loss_limit_blocks_entries_on_the_following_session():
    limits = RiskLimits(
        RiskConfig(daily_loss_limit=0.05, max_drawdown_stop=0.0), initial_equity=100_000.0
    )
    day1 = pd.Timestamp("2024-01-01")
    day2 = pd.Timestamp("2024-01-02")
    limits.update(day1, 100_000.0)
    limits.update(day2, 93_000.0)          # -7% measured at the session boundary
    assert not limits.can_open(day2)[0]
    assert limits.can_open(pd.Timestamp("2024-01-03"))[0]
