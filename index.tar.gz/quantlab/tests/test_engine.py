"""Backtest engine: execution rules, accounting identity, and look-ahead safety.

These are the tests that matter most.  A metrics bug produces a wrong number; an
engine bug produces a *plausible* wrong number, which is far more dangerous.
Each execution rule is verified against a hand-built set of bars whose expected
outcome was computed on paper.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from quantlab.backtest import BacktestEngine, ExitReason, run_backtest
from quantlab.config import BacktestConfig, CostConfig, RiskConfig
from quantlab.data import generate_ohlcv
from quantlab.data.universe import DEFAULT_UNIVERSE
from quantlab.strategies import all_strategy_names, build_strategy

from helpers import flat_bars, make_bars, signal_series, zero_cost_config, TEST_SPEC

# ATR(2) over the flat prelude is exactly 2.0, so with a 2x ATR stop and a 3x ATR
# target an entry at 100 gives stop 96 and target 106, and 1% of 100,000 risked
# over a 4-point stop is exactly 250 units.
_ENTRY, _STOP, _TARGET, _UNITS = 100.0, 96.0, 106.0, 250.0


def _run(rows, signals, cfg=None, spec=None):
    df = make_bars(rows)
    engine = BacktestEngine(cfg or zero_cost_config(), spec or TEST_SPEC)
    return engine.run(df, signal_series(df.index, signals), strategy_name="unit")


def _long_signals():
    # Signal appears on bar 5; with a one-bar lag the fill is the open of bar 6.
    return [0.0] * 5 + [1.0] * 5


def test_entry_is_filled_at_the_next_bars_open_not_the_signal_bars_close():
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [100, 100.5, 95.0, 96.0],
                           [96, 97, 95, 96], [96, 97, 95, 96]]
    result = _run(rows, _long_signals())
    trade = result.trades.iloc[0]
    assert trade["entry_time"] == make_bars(rows).index[6]
    assert abs(trade["entry_price"] - _ENTRY) < 1e-9


def test_stop_and_target_are_placed_at_the_configured_atr_multiples():
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [100, 100.5, 95.0, 96.0],
                           [96, 97, 95, 96], [96, 97, 95, 96]]
    trade = _run(rows, _long_signals()).trades.iloc[0]
    assert abs(trade["stop_price"] - _STOP) < 1e-9
    assert abs(trade["take_profit_price"] - _TARGET) < 1e-9


def test_fixed_risk_sizing_puts_exactly_the_configured_fraction_at_risk():
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [100, 100.5, 95.0, 96.0],
                           [96, 97, 95, 96], [96, 97, 95, 96]]
    trade = _run(rows, _long_signals()).trades.iloc[0]
    assert abs(trade["units"] - _UNITS) < 1e-9              # 1% of 100k over a 4-point stop
    assert abs(trade["risk_amount"] - 1000.0) < 1e-9
    assert abs(trade["net_pnl"] + 1000.0) < 1e-6           # stopped out for exactly -1R
    assert abs(trade["r_multiple"] + 1.0) < 1e-9


def test_a_gap_through_the_stop_fills_at_the_open_and_loses_more_than_1r():
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [94, 95, 93, 94],
                           [94, 95, 93, 94], [94, 95, 93, 94]]
    trade = _run(rows, _long_signals()).trades.iloc[0]
    assert abs(trade["exit_price"] - 94.0) < 1e-9          # the open, worse than the 96 stop
    assert abs(trade["r_multiple"] + 1.5) < 1e-9
    assert trade["exit_reason"] == ExitReason.STOP_LOSS


def test_take_profit_fills_at_the_target():
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [100, 107, 99.5, 106],
                           [106, 107, 105, 106], [106, 107, 105, 106]]
    trade = _run(rows, _long_signals()).trades.iloc[0]
    assert trade["exit_reason"] == ExitReason.TAKE_PROFIT
    assert abs(trade["exit_price"] - _TARGET) < 1e-9
    assert abs(trade["r_multiple"] - 1.5) < 1e-9


def test_a_bar_touching_both_stop_and_target_is_resolved_as_the_stop():
    """The pessimistic tie-break. Reversing it is how backtests manufacture edge."""
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [100, 107, 95, 101],
                           [101, 102, 100, 101], [101, 102, 100, 101]]
    result = _run(rows, _long_signals())
    trade = result.trades.iloc[0]
    assert trade["exit_reason"] == ExitReason.STOP_LOSS
    assert abs(trade["exit_price"] - _STOP) < 1e-9
    assert any("both the stop and the take-profit" in w for w in result.warnings)
    assert result.config_snapshot["execution"]["ambiguous_stop_target_bars"] >= 1


def test_short_trades_mirror_long_trades_exactly():
    rows = flat_bars(6) + [[100, 100.5, 99.5, 100], [100, 105, 99.5, 104],
                           [104, 105, 103, 104], [104, 105, 103, 104]]
    trade = _run(rows, [0.0] * 5 + [-1.0] * 5).trades.iloc[0]
    assert trade["direction"] == -1
    assert abs(trade["stop_price"] - 104.0) < 1e-9
    assert abs(trade["take_profit_price"] - 94.0) < 1e-9
    assert trade["exit_reason"] == ExitReason.STOP_LOSS
    assert abs(trade["r_multiple"] + 1.0) < 1e-9


def test_signal_reversal_closes_and_reopens_at_the_open():
    rows = flat_bars(6) + [[100, 101, 99, 100]] * 6
    signals = [0.0] * 5 + [1.0] * 3 + [-1.0] * 4
    result = _run(rows, signals)
    assert result.trades.iloc[0]["exit_reason"] == ExitReason.REVERSAL
    assert result.trades.iloc[0]["direction"] == 1
    assert (result.trades["direction"] == -1).any()


def test_costs_move_every_fill_adversely():
    rows = flat_bars(6) + [[100, 101, 99, 100]] * 6
    costly = zero_cost_config()
    costly.costs = CostConfig(
        spread_multiplier=1.0, slippage_bps=10.0, slippage_atr_fraction=0.0,
        commission_multiplier=1.0,
    )
    spec = TEST_SPEC.with_overrides(typical_spread=0.20, commission_rate=1e-4)
    long_trade = _run(rows, [0.0] * 5 + [1.0] * 3 + [0.0] * 4, costly, spec).trades.iloc[0]
    short_trade = _run(rows, [0.0] * 5 + [-1.0] * 3 + [0.0] * 4, costly, spec).trades.iloc[0]

    # Buying fills above the reference open, selling fills below it — both ways.
    assert long_trade["entry_price"] > 100.0
    assert long_trade["exit_price"] < 100.0
    assert short_trade["entry_price"] < 100.0
    assert short_trade["exit_price"] > 100.0
    assert long_trade["commission"] > 0 and long_trade["spread_cost"] > 0
    assert long_trade["slippage_cost"] > 0
    assert long_trade["net_pnl"] < long_trade["gross_pnl"]


def test_leverage_cap_limits_position_size():
    rows = flat_bars(6) + [[100, 101, 99, 100]] * 4
    cfg = zero_cost_config()
    cfg.risk = RiskConfig(
        sizing_method="fixed_fraction", fixed_fraction=50.0,   # would want 50x equity
        stop_atr_multiple=2.0, take_profit_atr_multiple=0.0,
        max_account_leverage=3.0, max_position_fraction=100.0,
        max_drawdown_stop=0.0, min_units=1.0, risk_per_trade=0.01,
    )
    trade = _run(rows, _long_signals(), cfg).trades.iloc[0]
    assert trade["notional"] <= 100_000.0 * 3.0 + 1e-6
    assert trade["notional"] > 100_000.0 * 2.9        # the cap binds, and binds tightly


def test_the_accounting_identity_holds_for_every_strategy():
    """sum(trade net P&L) must equal the change in account equity, to the cent."""
    df = generate_ohlcv("EURUSD", "2012-01-01", "2020-12-31", seed=17)
    for name in all_strategy_names():
        result = run_backtest(df, build_strategy(name), symbol="EURUSD")
        booked = float(result.trades["net_pnl"].sum())
        realised = result.final_equity - result.initial_balance
        assert abs(booked - realised) < 1e-6, f"{name}: books do not balance"


def test_cost_components_decompose_exactly():
    df = generate_ohlcv("GBPUSD", "2012-01-01", "2018-12-31", seed=19)
    trades = run_backtest(df, build_strategy("breakout"), symbol="GBPUSD").trades
    residual = (trades["gross_pnl"] - trades["total_costs"] - trades["net_pnl"]).abs().max()
    assert float(residual) < 1e-9


def test_no_look_ahead_bias_under_future_data_perturbation():
    """Perturb every bar after a cut point; nothing before it may change.

    This is the strongest single guarantee in the project. If any component —
    indicator, strategy or engine — reads a future bar, the trades closed before
    the cut will differ and this test fails.
    """
    df = generate_ohlcv("EURUSD", "2010-01-01", "2022-12-31", seed=23)
    cut = 1500
    cut_ts = df.index[cut]

    rng = np.random.default_rng(0)
    perturbed = df.copy()
    factor = 1.0 + rng.normal(0.0, 0.05, len(df) - cut)
    for col in ("open", "high", "low", "close"):
        perturbed.iloc[cut:, perturbed.columns.get_loc(col)] = (
            df[col].iloc[cut:].to_numpy() * factor
        )
    perturbed["high"] = perturbed[["high", "open", "close"]].max(axis=1)
    perturbed["low"] = perturbed[["low", "open", "close"]].min(axis=1)

    for name in all_strategy_names():
        base = run_backtest(df, build_strategy(name), symbol="EURUSD")
        alt = run_backtest(perturbed, build_strategy(name), symbol="EURUSD")

        before = base.trades[base.trades["exit_time"] < cut_ts].reset_index(drop=True)
        after = alt.trades[alt.trades["exit_time"] < cut_ts].reset_index(drop=True)
        assert len(before) > 10, f"{name}: not enough pre-cut trades to be a real test"
        assert before.equals(after), f"{name}: past trades changed when the future changed"

        eq_a = base.equity_curve.loc[:cut_ts, "equity"].iloc[:-2]
        eq_b = alt.equity_curve.loc[:cut_ts, "equity"].iloc[:-2]
        assert np.allclose(eq_a.to_numpy(), eq_b.to_numpy()), f"{name}: past equity changed"


def test_execution_lag_below_one_bar_is_rejected_by_config():
    cfg = BacktestConfig(execution_lag_bars=0)
    try:
        cfg.validate()
    except ValueError as exc:
        assert "look-ahead" in str(exc)
    else:
        raise AssertionError("same-bar execution must be impossible to configure")


def test_trade_from_restricts_fills_to_the_evaluation_window():
    df = generate_ohlcv("EURUSD", "2012-01-01", "2018-12-31", seed=29)
    cutoff = df.index[900]
    result = run_backtest(df, build_strategy("breakout"), symbol="EURUSD", trade_from=cutoff)
    assert not result.trades.empty
    assert result.trades["entry_time"].min() >= cutoff
    assert result.equity_curve.index[0] >= cutoff


def test_drawdown_kill_switch_halts_trading():
    cfg = zero_cost_config()
    cfg.risk = RiskConfig(
        sizing_method="fixed_risk", risk_per_trade=0.02, stop_atr_multiple=2.0,
        take_profit_atr_multiple=3.0, max_account_leverage=100.0,
        max_position_fraction=100.0, max_drawdown_stop=0.05, min_units=1.0,
    )
    # A long, uninterrupted decline: repeated stop-outs must trip the switch.
    rows = flat_bars(6)
    price = 100.0
    for _ in range(160):
        rows.append([price, price + 0.4, price - 2.4, price - 2.0])
        price -= 2.0
        price = max(price, 5.0)
    result = _run(rows, [0.0] * 5 + [1.0] * (len(rows) - 5), cfg)
    assert result.kill_switch_triggered
    assert any("kill-switch" in w for w in result.warnings)


def test_open_position_is_closed_at_the_end_of_the_data():
    rows = flat_bars(6) + [[100, 101, 99, 100]] * 6
    result = _run(rows, [0.0] * 5 + [1.0] * 7)
    assert result.trades.iloc[-1]["exit_reason"] == ExitReason.END_OF_DATA
    assert float(result.equity_curve["position_units"].iloc[-1]) == 0.0


def test_engine_rejects_signals_that_are_not_aligned_to_the_price_index():
    df = make_bars(flat_bars(10))
    engine = BacktestEngine(zero_cost_config(), TEST_SPEC)
    misaligned = pd.Series([0.0] * 10, index=pd.RangeIndex(10))
    try:
        engine.run(df, misaligned)
    except ValueError:
        pass
    else:
        raise AssertionError("misaligned signals must be rejected")


def test_higher_costs_never_improve_the_result():
    df = generate_ohlcv("XAUUSD", "2012-01-01", "2020-12-31", seed=31)
    spec = DEFAULT_UNIVERSE.get("XAUUSD")
    equities = []
    for multiplier in (1.0, 2.0, 4.0):
        cfg = BacktestConfig(
            costs=CostConfig(
                spread_multiplier=multiplier, slippage_bps=0.5 * multiplier,
                slippage_atr_fraction=0.02 * multiplier, commission_multiplier=multiplier,
            )
        )
        cfg.risk.max_drawdown_stop = 0.0
        equities.append(
            run_backtest(df, build_strategy("ma_crossover"), config=cfg, spec=spec).final_equity
        )
    assert equities[0] >= equities[1] >= equities[2] - 1e-6
