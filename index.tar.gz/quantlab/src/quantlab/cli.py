"""Command-line interface.

    quantlab run              # full study: walk-forward, Monte Carlo, report
    quantlab backtest         # one strategy on one instrument, in-sample
    quantlab data             # generate/inspect the data and its quality report
    quantlab strategies       # list strategies and their search grids

Every subcommand prints the same reminder about what a backtest can and cannot
establish, because the CLI is where results get glanced at.
"""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from . import __version__

DISCLAIMER = (
    "QuantLab is a research and paper-trading system. It has no broker connectivity and "
    "places no orders. A backtest cannot establish that a strategy is profitable; read the "
    "overfitting diagnostics before the performance numbers."
)


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--symbols", nargs="+", default=["EURUSD", "GBPUSD", "XAUUSD", "SPX500"])
    parser.add_argument("--start", default="2010-01-01")
    parser.add_argument("--end", default="2025-12-31")
    parser.add_argument("--source", choices=["synthetic", "csv"], default="synthetic")
    parser.add_argument("--seed", type=int, default=20260907)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="quantlab", description=DISCLAIMER)
    parser.add_argument("--version", action="version", version=f"quantlab {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="full research study with report")
    _add_common(run)
    run.add_argument("--strategies", nargs="+",
                     default=["ma_crossover", "breakout", "rsi_reversion", "momentum"])
    run.add_argument("--name", default="baseline")
    run.add_argument("--output", default="reports/runs")
    run.add_argument("--config", default=None, help="JSON experiment config (overrides flags)")
    run.add_argument("--train-bars", type=int, default=750)
    run.add_argument("--test-bars", type=int, default=250)
    run.add_argument("--simulations", type=int, default=5000)
    run.add_argument("--risk-per-trade", type=float, default=None)

    bt = sub.add_parser("backtest", help="single in-sample backtest (a diagnostic, not a result)")
    _add_common(bt)
    bt.add_argument("--strategy", default="ma_crossover")
    bt.add_argument("--param", action="append", default=[], metavar="KEY=VALUE")

    data = sub.add_parser("data", help="load data and print the quality report")
    _add_common(data)

    sub.add_parser("strategies", help="list strategies and the size of their search grids")
    return parser


def _parse_params(pairs: List[str]) -> dict:
    out = {}
    for pair in pairs:
        if "=" not in pair:
            raise SystemExit(f"--param expects KEY=VALUE, got {pair!r}")
        key, value = pair.split("=", 1)
        try:
            parsed = int(value)
        except ValueError:
            try:
                parsed = float(value)
            except ValueError:
                parsed = value
        out[key] = parsed
    return out


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    print(DISCLAIMER + "\n", file=sys.stderr)

    if args.command == "strategies":
        from .strategies.registry import all_strategy_names, build_strategy, strategy_grid

        for name in all_strategy_names():
            grid = strategy_grid(name)
            strategy = build_strategy(name)
            print(f"{name:16s} lookback={strategy.lookback:4d}  grid={len(grid):3d} combinations")
            print(f"                 defaults: {strategy.param_str()}")
        print(
            "\nGrid size is not free: every extra combination raises the Sharpe that pure "
            "search luck produces, and the report deflates results accordingly."
        )
        return 0

    if args.command == "data":
        from .data import load_dataset, quality_report

        dataset = load_dataset(
            args.symbols, source=args.source, start=args.start, end=args.end, seed=args.seed
        )
        print(quality_report(dataset).to_string())
        for symbol, df in dataset.items():
            print(f"\n{symbol}: {df.attrs.get('provenance', 'unknown provenance')}")
        return 0

    if args.command == "backtest":
        from .analytics import metrics_from_result
        from .backtest import run_backtest
        from .data import load_symbol
        from .strategies import build_strategy

        symbol = args.symbols[0]
        df = load_symbol(symbol, source=args.source, start=args.start, end=args.end, seed=args.seed)
        strategy = build_strategy(args.strategy, _parse_params(args.param))
        result = run_backtest(df, strategy, symbol=symbol)
        metrics = metrics_from_result(result)
        print(f"{symbol} / {strategy.describe()}")
        print(metrics.headline())
        print("\nThis is an IN-SAMPLE result on the full history with fixed parameters. It is a")
        print("diagnostic. Use `quantlab run` for the walk-forward evaluation that matters.")
        for warning in metrics.warnings:
            print(f"  ! {warning}")
        return 0

    # args.command == "run"
    from .config import ExperimentConfig
    from .research import run_experiment

    if args.config:
        cfg = ExperimentConfig.from_json(args.config)
    else:
        cfg = ExperimentConfig(
            name=args.name, symbols=args.symbols, strategies=args.strategies,
            start=args.start, end=args.end, data_source=args.source,
        )
        cfg.backtest.seed = args.seed
        cfg.walk_forward.train_bars = args.train_bars
        cfg.walk_forward.test_bars = args.test_bars
        cfg.monte_carlo.n_simulations = args.simulations
        if args.risk_per_trade is not None:
            cfg.backtest.risk.risk_per_trade = args.risk_per_trade
        cfg.validate()

    outcome = run_experiment(cfg, output_dir=args.output)
    print(f"\nReport: {outcome['report_path']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
