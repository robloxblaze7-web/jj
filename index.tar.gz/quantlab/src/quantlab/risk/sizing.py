"""Position sizing.

Sizing is where most of a system's realised risk actually lives.  Two traders
running the same signals with different sizing rules do not have similar results
with different volatility; they have different businesses, and one of them may
be mathematically guaranteed to go broke.

Three methods are provided:

``fixed_risk``
    Risk a constant fraction of *current* equity between entry and stop.  Size
    falls automatically as volatility rises (the stop is ATR-based) and as
    equity falls.  This is the default because it makes the R-multiple
    well-defined: every trade risks 1R by construction, so the R-distribution
    describes the strategy rather than the sizing.

``fixed_fraction``
    Constant notional as a fraction of equity.  Simple, but a fixed notional in
    a volatile instrument is a much larger bet than the same notional in a calm
    one, which shows up as unstable risk across regimes.

``vol_target``
    Size so the position's annualised volatility hits a target, using ATR as the
    volatility estimate.  Equalises risk across instruments, which is what makes
    a multi-instrument comparison meaningful.

Every method then passes through the same cap chain, and sizes are always
rounded **down** to a tradeable increment, so a cap can never be exceeded by
rounding.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from ..config import RiskConfig
from ..data.universe import InstrumentSpec


@dataclass(frozen=True)
class SizingDecision:
    """The size to trade and, if reduced, what reduced it."""

    units: float
    notional: float
    margin_required: float
    risk_amount: float
    capped_by: Optional[str] = None
    rejected_reason: Optional[str] = None

    @property
    def is_tradeable(self) -> bool:
        return self.units > 0 and self.rejected_reason is None


def _raw_units(
    method: str,
    equity: float,
    price: float,
    stop_distance: float,
    atr_value: float,
    spec: InstrumentSpec,
    cfg: RiskConfig,
    bars_per_year: float,
) -> float:
    pv = spec.point_value
    if method == "fixed_risk":
        risk_per_unit = stop_distance * pv
        if not np.isfinite(risk_per_unit) or risk_per_unit <= 0:
            return 0.0
        return (equity * cfg.risk_per_trade) / risk_per_unit

    if method == "fixed_fraction":
        denom = price * pv
        if denom <= 0:
            return 0.0
        return (equity * cfg.fixed_fraction) / denom

    if method == "vol_target":
        if not np.isfinite(atr_value) or atr_value <= 0 or price <= 0:
            return 0.0
        # ATR is a daily-range measure; treat it as a proxy for the daily
        # standard deviation of price and annualise.  It overstates sigma
        # somewhat (range > stdev), which sizes conservatively.
        ann_vol_price = atr_value * np.sqrt(bars_per_year)
        if ann_vol_price <= 0:
            return 0.0
        return (equity * cfg.target_annual_vol) / (ann_vol_price * pv)

    raise ValueError(f"unknown sizing method {method!r}")


def size_position(
    *,
    equity: float,
    price: float,
    stop_distance: float,
    atr_value: float,
    spec: InstrumentSpec,
    cfg: RiskConfig,
    existing_notional: float = 0.0,
    free_equity: Optional[float] = None,
    bars_per_year: float = 252.0,
) -> SizingDecision:
    """Compute a tradeable position size, applying every cap in order.

    Parameters
    ----------
    equity:
        Current account equity (balance + unrealised P&L).  Using equity rather
        than the starting balance is what makes the sizing anti-martingale: the
        bet shrinks after losses.
    stop_distance:
        Distance from entry to stop in price units.  Required for ``fixed_risk``.
    existing_notional:
        Gross notional already open, so the account leverage cap accounts for
        the whole book rather than one position at a time.
    """
    if equity <= 0:
        return SizingDecision(0.0, 0.0, 0.0, 0.0, rejected_reason="equity_exhausted")
    if price <= 0 or not np.isfinite(price):
        return SizingDecision(0.0, 0.0, 0.0, 0.0, rejected_reason="invalid_price")

    free_equity = equity if free_equity is None else free_equity
    units = _raw_units(
        cfg.sizing_method, equity, price, stop_distance, atr_value, spec, cfg, bars_per_year
    )
    if not np.isfinite(units) or units <= 0:
        return SizingDecision(0.0, 0.0, 0.0, 0.0, rejected_reason="undefined_size")

    capped_by = None
    pv = spec.point_value

    # 1. single-position cap
    max_units_position = (equity * cfg.max_position_fraction) / (price * pv)
    if units > max_units_position:
        units, capped_by = max_units_position, "max_position_fraction"

    # 2. account gross leverage cap (includes what is already open)
    allowed_gross = equity * cfg.max_account_leverage
    remaining_gross = max(allowed_gross - existing_notional, 0.0)
    max_units_leverage = remaining_gross / (price * pv)
    if units > max_units_leverage:
        units, capped_by = max_units_leverage, "max_account_leverage"

    # 3. instrument margin: the position must be funded
    if spec.margin_rate > 0:
        max_units_margin = free_equity / (price * pv * spec.margin_rate)
        if units > max_units_margin:
            units, capped_by = max_units_margin, "margin_available"

    # 4. round DOWN to a tradeable increment
    units = spec.round_units(units)

    if units < spec.min_units or units <= 0:
        return SizingDecision(
            0.0, 0.0, 0.0, 0.0, capped_by=capped_by, rejected_reason="below_min_size"
        )

    notional = units * price * pv
    return SizingDecision(
        units=float(units),
        notional=float(notional),
        margin_required=float(notional * spec.margin_rate),
        risk_amount=float(units * stop_distance * pv),
        capped_by=capped_by,
    )


def stop_and_target(
    *,
    direction: int,
    entry_price: float,
    atr_value: float,
    cfg: RiskConfig,
    spec: InstrumentSpec,
) -> Tuple[float, Optional[float]]:
    """ATR-based stop and (optional) take-profit levels for a new position.

    A stop is mandatory: without one, position size is undefined under
    ``fixed_risk`` and the R-multiple has no denominator.  More importantly, an
    unstopped backtest can ride a losing position for years and still report a
    beautiful win rate.
    """
    if direction not in (1, -1):
        raise ValueError("direction must be +1 or -1")
    if not np.isfinite(atr_value) or atr_value <= 0:
        raise ValueError("a positive ATR is required to place a stop")

    stop_distance = atr_value * cfg.stop_atr_multiple
    stop = entry_price - direction * stop_distance
    stop = max(stop, spec.tick_size) if direction > 0 else stop

    target = None
    if cfg.take_profit_atr_multiple > 0:
        target = entry_price + direction * atr_value * cfg.take_profit_atr_multiple
    return float(stop), (float(target) if target is not None else None)
