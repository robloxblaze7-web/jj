"""Account-level risk limits: daily loss cap and drawdown kill switch.

These are portfolio circuit breakers, not signal logic.  They exist in a
research framework for one reason: a strategy's headline statistics are computed
over the full sample, but a real account can be closed by a drawdown long before
the sample ends.  Running the same strategy with and without a kill switch tells
you how much of the reported performance depended on surviving a period that
would, in practice, have ended the account.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import pandas as pd

from ..config import RiskConfig


@dataclass
class RiskState:
    """Mutable risk state tracked bar by bar."""

    peak_equity: float
    session_start_equity: float
    current_session: Optional[pd.Timestamp] = None
    kill_switch_active: bool = False
    entries_blocked_until_session: Optional[pd.Timestamp] = None
    events: List[str] = field(default_factory=list)


class RiskLimits:
    """Evaluates whether new positions may be opened."""

    def __init__(self, cfg: RiskConfig, initial_equity: float):
        self.cfg = cfg
        self.state = RiskState(peak_equity=initial_equity, session_start_equity=initial_equity)

    def update(self, timestamp: pd.Timestamp, equity: float) -> None:
        """Update peak equity, session boundaries and the kill switch."""
        st = self.state
        session = pd.Timestamp(timestamp).normalize()

        if st.current_session is None:
            st.current_session = session
            st.session_start_equity = equity
        elif session != st.current_session:
            # New session: evaluate the previous session's loss before resetting.
            if self.cfg.daily_loss_limit > 0 and st.session_start_equity > 0:
                loss = 1.0 - equity / st.session_start_equity
                if loss >= self.cfg.daily_loss_limit:
                    st.entries_blocked_until_session = session
                    st.events.append(
                        f"{st.current_session.date()}: session loss {loss:.2%} hit the "
                        f"{self.cfg.daily_loss_limit:.2%} daily limit; entries blocked for "
                        f"{session.date()}"
                    )
            st.current_session = session
            st.session_start_equity = equity

        if equity > st.peak_equity:
            st.peak_equity = equity

        if self.cfg.max_drawdown_stop > 0 and not st.kill_switch_active and st.peak_equity > 0:
            dd = 1.0 - equity / st.peak_equity
            if dd >= self.cfg.max_drawdown_stop:
                st.kill_switch_active = True
                st.events.append(
                    f"{session.date()}: drawdown {dd:.2%} hit the "
                    f"{self.cfg.max_drawdown_stop:.2%} kill-switch threshold; no further "
                    f"entries and open positions are closed"
                )

    def can_open(self, timestamp: pd.Timestamp) -> Tuple[bool, Optional[str]]:
        st = self.state
        if st.kill_switch_active:
            return False, "kill_switch"
        session = pd.Timestamp(timestamp).normalize()
        if (
            st.entries_blocked_until_session is not None
            and session <= st.entries_blocked_until_session
        ):
            return False, "daily_loss_limit"
        return True, None

    @property
    def kill_switch_active(self) -> bool:
        return self.state.kill_switch_active

    @property
    def events(self) -> List[str]:
        return list(self.state.events)
