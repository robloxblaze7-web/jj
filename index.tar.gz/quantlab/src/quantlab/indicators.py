"""Causal technical indicators.

Every function here obeys one rule: the value at bar *t* depends only on bars
``<= t``.  No centred windows, no ``shift(-1)``, no full-sample statistics
(z-scores use rolling windows, never the whole series' mean).

:func:`check_causal` verifies the rule empirically by recomputing an indicator
on truncated prefixes of the input and asserting the overlapping values are
unchanged.  The test suite runs it against every public function in this module,
so a future indicator that peeks fails CI rather than quietly improving the
backtest.

A note on ``exclude_current``: for breakout logic the relevant level is the
highest high of the *prior* N bars.  Including the current bar makes
``high >= rolling_max`` true on every new high by construction — an
edge-destroying bug that is easy to write and hard to see on a chart.  The
default is therefore ``exclude_current=True`` for the channel functions.
"""

from __future__ import annotations

from typing import Callable

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------- #
# moving averages and dispersion
# --------------------------------------------------------------------------- #
def sma(series: pd.Series, window: int) -> pd.Series:
    _check_window(window)
    return series.rolling(window, min_periods=window).mean()


def ema(series: pd.Series, window: int) -> pd.Series:
    """Exponential MA with ``adjust=False`` (recursive form).

    ``adjust=True`` reweights the entire history every bar, which is still
    causal but makes the value at bar *t* depend on how much history happens to
    be loaded — two runs over different date ranges would disagree on the same
    bar.  The recursive form is stable and is what a live implementation would
    compute.
    """
    _check_window(window)
    return series.ewm(span=window, adjust=False, min_periods=window).mean()


def moving_average(series: pd.Series, window: int, kind: str = "sma") -> pd.Series:
    if kind == "sma":
        return sma(series, window)
    if kind == "ema":
        return ema(series, window)
    raise ValueError(f"unknown moving average kind {kind!r} (use 'sma' or 'ema')")


def rolling_std(series: pd.Series, window: int) -> pd.Series:
    _check_window(window)
    return series.rolling(window, min_periods=window).std(ddof=1)


def rolling_zscore(series: pd.Series, window: int) -> pd.Series:
    m = sma(series, window)
    s = rolling_std(series, window)
    return (series - m) / s.replace(0.0, np.nan)


# --------------------------------------------------------------------------- #
# range and volatility
# --------------------------------------------------------------------------- #
def wilder_rma(series: pd.Series, window: int) -> pd.Series:
    """Wilder's running moving average, seeded the way Wilder specified.

    The seed at bar ``window`` is the simple mean of the first ``window``
    observations; every later bar is ``prev + (x - prev)/window``.  Using
    ``ewm(alpha=1/n, adjust=False)`` straight from bar 0 instead — a very common
    shortcut — converges to the same thing but disagrees near the start of the
    sample and, worse, makes the value at a given bar depend on how much history
    was loaded.  Two backtests over different date ranges would then produce
    different signals on the same day.
    """
    _check_window(window)
    x = series.to_numpy(dtype=float)
    n = len(x)
    out = np.full(n, np.nan)
    if n < window:
        return pd.Series(out, index=series.index)

    valid = ~np.isnan(x)
    first_valid = int(np.argmax(valid)) if valid.any() else n
    seed_end = first_valid + window
    if seed_end > n or not valid[first_valid:seed_end].all():
        return pd.Series(out, index=series.index)

    prev = float(np.mean(x[first_valid:seed_end]))
    out[seed_end - 1] = prev
    inv = 1.0 / window
    for i in range(seed_end, n):
        xi = x[i]
        if np.isnan(xi):
            out[i] = prev
            continue
        prev = prev + (xi - prev) * inv
        out[i] = prev
    return pd.Series(out, index=series.index)


def true_range(df: pd.DataFrame) -> pd.Series:
    """Wilder's true range: max(H-L, |H-C_prev|, |L-C_prev|)."""
    prev_close = df["close"].shift(1)
    a = (df["high"] - df["low"]).to_numpy(dtype=float)
    b = (df["high"] - prev_close).abs().to_numpy(dtype=float)
    c = (df["low"] - prev_close).abs().to_numpy(dtype=float)
    # numpy rather than pd.concat(...).max(axis=1): concat propagates DataFrame
    # .attrs, and the first bar's b/c are NaN.  np.fmax ignores NaN, so bar 0
    # falls back to H-L.
    return pd.Series(np.fmax(a, np.fmax(b, c)), index=df.index)


def atr(df: pd.DataFrame, window: int = 14, method: str = "wilder") -> pd.Series:
    """Average true range.

    ``wilder`` uses the classic RMA (alpha = 1/n) smoothing; ``sma`` uses a
    simple mean.  Both are causal.
    """
    _check_window(window)
    tr = true_range(df)
    if method == "wilder":
        return wilder_rma(tr, window)
    if method == "sma":
        return tr.rolling(window, min_periods=window).mean()
    raise ValueError(f"unknown atr method {method!r}")


def realised_vol(series: pd.Series, window: int = 20, bars_per_year: float = 252.0) -> pd.Series:
    """Annualised volatility of log returns over a trailing window."""
    rets = np.log(series).diff()
    return rets.rolling(window, min_periods=window).std(ddof=1) * np.sqrt(bars_per_year)


# --------------------------------------------------------------------------- #
# channels
# --------------------------------------------------------------------------- #
def rolling_max(series: pd.Series, window: int, exclude_current: bool = True) -> pd.Series:
    _check_window(window)
    src = series.shift(1) if exclude_current else series
    return src.rolling(window, min_periods=window).max()


def rolling_min(series: pd.Series, window: int, exclude_current: bool = True) -> pd.Series:
    _check_window(window)
    src = series.shift(1) if exclude_current else series
    return src.rolling(window, min_periods=window).min()


def donchian(df: pd.DataFrame, window: int, exclude_current: bool = True) -> pd.DataFrame:
    upper = rolling_max(df["high"], window, exclude_current)
    lower = rolling_min(df["low"], window, exclude_current)
    return pd.DataFrame({"upper": upper, "lower": lower, "mid": (upper + lower) / 2.0})


# --------------------------------------------------------------------------- #
# oscillators and momentum
# --------------------------------------------------------------------------- #
def rsi(series: pd.Series, window: int = 14) -> pd.Series:
    """Wilder's RSI in [0, 100].

    Flat series yield 50 rather than NaN or a divide-by-zero, matching the
    convention that "no movement" is neutral.
    """
    _check_window(window)
    delta = series.diff()
    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)
    # Wilder seeding: the first average is a simple mean of the first `window`
    # changes.  ``delta`` is NaN at bar 0, so the seed lands on bar `window`,
    # which is where a hand calculation of RSI produces its first value.
    avg_gain = wilder_rma(gain, window)
    avg_loss = wilder_rma(loss, window)
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    out = 100.0 - (100.0 / (1.0 + rs))
    flat = (avg_loss == 0.0) & (avg_gain == 0.0)
    only_gains = (avg_loss == 0.0) & (avg_gain > 0.0)
    out = out.mask(only_gains, 100.0).mask(flat, 50.0)
    return out.where(avg_gain.notna(), np.nan)


def roc(series: pd.Series, window: int) -> pd.Series:
    """Rate of change over ``window`` bars, as a simple return."""
    _check_window(window)
    return series.pct_change(window)


def log_momentum(series: pd.Series, window: int) -> pd.Series:
    _check_window(window)
    return np.log(series).diff(window)


def slope(series: pd.Series, window: int) -> pd.Series:
    """Least-squares slope per bar over a trailing window, scaled by price."""
    _check_window(window)
    x = np.arange(window, dtype=float)
    x_centred = x - x.mean()
    denom = float((x_centred**2).sum())

    def _fit(win: np.ndarray) -> float:
        y = win - win.mean()
        return float((x_centred * y).sum() / denom)

    return series.rolling(window, min_periods=window).apply(_fit, raw=True) / series


# --------------------------------------------------------------------------- #
# causality verification
# --------------------------------------------------------------------------- #
def check_causal(
    func: Callable[..., "pd.Series | pd.DataFrame"],
    data: "pd.Series | pd.DataFrame",
    *args,
    cut: float = 0.6,
    tol: float = 1e-9,
    **kwargs,
) -> bool:
    """Return True if ``func`` uses no future information.

    The indicator is computed on the full sample and on the first ``cut``
    fraction of it.  If any overlapping value differs by more than ``tol``, the
    output at some bar depended on data after that bar.

    Note the direction of the guarantee: passing does not *prove* causality for
    every possible input, but any realistic look-ahead (a centred window, a
    negative shift, a full-sample mean) fails immediately.
    """
    n = len(data)
    k = int(n * cut)
    full = func(data, *args, **kwargs)
    partial = func(data.iloc[:k], *args, **kwargs)

    full_head = full.iloc[:k]
    a = full_head.to_numpy(dtype=float)
    b = partial.to_numpy(dtype=float)

    both_nan = np.isnan(a) & np.isnan(b)
    close = np.isclose(a, b, rtol=0.0, atol=tol, equal_nan=True)
    return bool(np.all(close | both_nan))


def _check_window(window: int) -> None:
    if not isinstance(window, (int, np.integer)) or window < 1:
        raise ValueError(f"window must be a positive integer, got {window!r}")


__all__ = [
    "sma", "ema", "moving_average", "rolling_std", "rolling_zscore", "wilder_rma",
    "true_range", "atr", "realised_vol", "rolling_max", "rolling_min", "donchian",
    "rsi", "roc", "log_momentum", "slope", "check_causal",
]
