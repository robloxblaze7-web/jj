"""The research pipeline: data -> walk-forward -> Monte Carlo -> diagnostics -> report.

This module is the thing you actually run.  It exists so that a full study is one
reproducible call rather than a notebook that only its author can re-execute.

The ordering is deliberate.  Walk-forward comes first and produces the headline;
the in-sample split results are computed afterwards and labelled as diagnostics,
so there is no path through this code that reports an in-sample number as a
result.
"""

from __future__ import annotations

import json
import time
from dataclasses import replace as dc_replace
from pathlib import Path
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from . import __version__
from .analytics.metrics import metrics_from_result, monthly_returns, rolling_sharpe
from .analytics.monte_carlo import run_monte_carlo
from .analytics.overfitting import build_overfitting_report
from .analytics.walkforward import run_walk_forward
from .backtest.engine import run_backtest
from .config import CostConfig, ExperimentConfig
from .data import (
    DEFAULT_UNIVERSE,
    load_dataset,
    quality_report,
    three_way_split,
)
from .reporting import charts
from .reporting.report import RunRecord, build_report, write_report
from .strategies.registry import build_strategy, strategy_grid

FALSIFICATION_CRITERIA = [
    "positive out-of-sample expectancy",
    "majority of folds positive",
    "Sharpe above the best-of-N null",
    "deflated Sharpe >= 0.95",
    "PBO < 0.5",
    "survives 2x costs",
]


def _log(message: str, verbose: bool = True) -> None:
    if verbose:
        print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)


def cost_sensitivity(
    df: pd.DataFrame, strategy_name: str, params: Dict, cfg, spec, multipliers=(1.0, 2.0, 3.0)
) -> Dict[str, float]:
    """Re-run the same strategy under progressively worse execution.

    A result that inverts between 1x and 2x costs was never trading a signal.
    """
    out: Dict[str, float] = {}
    for m in multipliers:
        run_cfg = dc_replace(
            cfg,
            costs=CostConfig(
                spread_multiplier=cfg.costs.spread_multiplier * m,
                slippage_bps=cfg.costs.slippage_bps * m,
                slippage_atr_fraction=cfg.costs.slippage_atr_fraction * m,
                commission_multiplier=cfg.costs.commission_multiplier * m,
            ),
        )
        result = run_backtest(
            df, build_strategy(strategy_name, params), config=run_cfg, spec=spec
        )
        out[f"{m:g}x spread, slippage and commission"] = (
            result.final_equity / result.initial_balance - 1.0
        )
    return out


def evaluate_criteria(record: RunRecord) -> Dict[str, bool]:
    """Score one run against the six falsification criteria stated in the report."""
    m = record.oos_metrics
    of = record.overfitting
    wf = record.walk_forward

    fold_returns = [
        f.selected_test_metrics.total_return
        for f in wf.folds
        if f.selected_test_metrics is not None
    ]
    majority = (
        float(np.mean([r > 0 for r in fold_returns])) > 0.5 if fold_returns else False
    )

    base = record.cost_sensitivity.get("1x spread, slippage and commission", float("nan"))
    doubled = record.cost_sensitivity.get("2x spread, slippage and commission", float("nan"))
    survives_costs = bool(np.isfinite(doubled) and doubled > 0)

    return {
        FALSIFICATION_CRITERIA[0]: bool(m.n_trades > 0 and m.expectancy_r > 0),
        FALSIFICATION_CRITERIA[1]: bool(majority),
        FALSIFICATION_CRITERIA[2]: bool(
            of is not None
            and np.isfinite(of.expected_max_null_sharpe)
            and m.sharpe_ratio > of.expected_max_null_sharpe
        ),
        FALSIFICATION_CRITERIA[3]: bool(
            of is not None and np.isfinite(of.deflated_sharpe) and of.deflated_sharpe >= 0.95
        ),
        FALSIFICATION_CRITERIA[4]: bool(
            of is not None and of.pbo is not None and np.isfinite(of.pbo.pbo) and of.pbo.pbo < 0.5
        ),
        FALSIFICATION_CRITERIA[5]: survives_costs and bool(np.isfinite(base)),
    }


def executive_summary(records: List[RunRecord], synthetic: bool) -> str:
    """The summary is generated from the criteria, not written by hand.

    That is the point: it cannot drift into optimism, because it is arithmetic.
    """
    scored = {rec.label: evaluate_criteria(rec) for rec in records}
    passed_all = [label for label, checks in scored.items() if all(checks.values())]
    n = len(records)

    counts = {
        criterion: sum(1 for checks in scored.values() if checks[criterion])
        for criterion in FALSIFICATION_CRITERIA
    }
    rows = "\n".join(
        f"| {criterion} | {counts[criterion]} / {n} |" for criterion in FALSIFICATION_CRITERIA
    )

    positive_expectancy = [
        rec.label for rec in records if rec.oos_metrics.expectancy_r > 0
    ]
    best = max(records, key=lambda r: r.oos_metrics.expectancy_r) if records else None

    verdict = (
        f"**{len(passed_all)} of {n} strategy/instrument runs cleared all six criteria.**"
    )
    if passed_all:
        listed = ", ".join(passed_all)
        follow_up = (
            f" Runs clearing every criterion: {listed}. Clearing the criteria means the "
            f"result is *not explained by* the search — it is not a finding of "
            f"profitability, and on synthetic data it cannot be one."
            if synthetic
            else f" Runs clearing every criterion: {listed}. Clearing the criteria means "
            f"the result is *not explained by* the search. The appropriate next step is "
            f"forward paper trading on unseen data, not capital."
        )
    else:
        follow_up = (
            " No run survived the full set. Under these cost and execution assumptions, "
            "none of the four baseline strategies produced out-of-sample evidence that "
            "would survive its own falsification test."
        )

    synthetic_note = (
        "\n\n> Because this run used synthetic data, the only valid reading of the table "
        "below is whether the machinery behaves correctly. A strategy that cleared every "
        "criterion here has demonstrated something about the generator's parameters, not "
        "about any market."
        if synthetic
        else ""
    )

    best_line = ""
    if best is not None:
        bm = best.oos_metrics
        best_line = (
            f"\n\nHighest out-of-sample expectancy: **{best.label}** at "
            f"{bm.expectancy_r:+.3f}R per trade over {bm.n_trades} trades "
            f"(Sharpe {bm.sharpe_ratio:.2f}, t={bm.sharpe_t_stat:.1f}, "
            f"max drawdown {bm.max_drawdown:.1%}). "
            f"{'It cleared' if best.label in passed_all else 'It did not clear'} all six criteria."
        )

    return f"""## Summary

{verdict}{follow_up}

| Criterion | Runs clearing it |
|---|---|
{rows}

Runs with positive out-of-sample expectancy: {len(positive_expectancy)} / {n}.{best_line}{synthetic_note}
"""


def run_experiment(
    config: Optional[ExperimentConfig] = None,
    *,
    output_dir: Optional[str] = None,
    verbose: bool = True,
    progress: Optional[Callable[[str], None]] = None,
) -> Dict[str, object]:
    """Execute a full study and write the report, charts and machine-readable results."""
    cfg = config or ExperimentConfig()
    cfg.validate()

    out_root = Path(output_dir or cfg.output_dir) / cfg.name
    chart_dir = out_root / "charts"
    out_root.mkdir(parents=True, exist_ok=True)
    chart_dir.mkdir(parents=True, exist_ok=True)

    _log(f"loading {len(cfg.symbols)} symbols from {cfg.data_source}", verbose)
    dataset = load_dataset(
        cfg.symbols, source=cfg.data_source, start=cfg.start, end=cfg.end,
        seed=cfg.backtest.seed,
    )
    synthetic = any(df.attrs.get("synthetic", False) for df in dataset.values())
    quality = quality_report(dataset)
    provenance = [df.attrs.get("provenance", "unknown") for df in dataset.values()]
    survivorship_warnings = DEFAULT_UNIVERSE.audit_survivorship(cfg.symbols, cfg.start, cfg.end)
    for w in survivorship_warnings:
        _log(f"survivorship: {w}", verbose)

    caption_stub = (
        "SYNTHETIC DATA — generated for pipeline validation. Not market data."
        if synthetic
        else "Out-of-sample walk-forward result. Costs and execution assumptions as stated."
    )

    records: List[RunRecord] = []
    for symbol in cfg.symbols:
        df = dataset[symbol.upper()]
        spec = DEFAULT_UNIVERSE.get(symbol)
        splits = three_way_split(df.index, cfg.split)

        for strategy_name in cfg.strategies:
            started = time.time()
            _log(f"walk-forward: {symbol}/{strategy_name}", verbose)
            wf = run_walk_forward(
                df, strategy_name, symbol=symbol, spec=spec,
                backtest_config=cfg.backtest, wf_config=cfg.walk_forward,
                progress=progress,
            )

            mc = run_monte_carlo(wf.trades, cfg.monte_carlo)

            # In-sample split diagnostics, computed AFTER the out-of-sample result
            # and labelled as diagnostics so they can never become the headline.
            split_metrics = {}
            for split_name, split in splits.items():
                sub = split.apply(df)
                if len(sub) > cfg.backtest.warmup_bars + 30:
                    res = run_backtest(
                        sub, build_strategy(strategy_name), config=cfg.backtest, spec=spec
                    )
                    split_metrics[split_name] = metrics_from_result(
                        res, cfg.backtest.bars_per_year, cfg.backtest.risk_free_rate
                    )

            sens = cost_sensitivity(
                df, strategy_name, {}, cfg.backtest, spec
            )

            in_sample_sharpe = (
                split_metrics["train"].sharpe_ratio if "train" in split_metrics else float("nan")
            )
            overfitting = build_overfitting_report(
                label=f"{symbol}/{strategy_name}",
                observed_sharpe=wf.metrics.sharpe_ratio,
                raw_p_value=wf.metrics.sharpe_p_value,
                n_obs=max(len(wf.equity_curve), 2),
                n_trials=wf.n_candidates,
                skew=wf.metrics.return_skew,
                excess_kurtosis=wf.metrics.return_excess_kurtosis,
                bars_per_year=cfg.backtest.bars_per_year,
                folds=wf.folds,
                parameter_churn=wf.parameter_churn(),
                in_sample_sharpe=in_sample_sharpe,
                out_of_sample_sharpe=wf.metrics.sharpe_ratio,
            )

            prefix = f"{symbol}_{strategy_name}"
            chart_paths = {}
            if not wf.equity_curve.empty:
                equity = wf.equity_curve["equity"]
                chart_paths = charts.chart_set(
                    equity=equity, trades=wf.trades, monthly=monthly_returns(equity),
                    rolling=rolling_sharpe(
                        wf.equity_curve["returns"], bars_per_year=cfg.backtest.bars_per_year
                    ),
                    outdir=chart_dir, prefix=prefix,
                    caption=f"{symbol} / {strategy_name} — out-of-sample walk-forward. {caption_stub}",
                    fold_table=wf.fold_table(),
                    mc_drawdowns=mc.max_drawdowns if mc.n_trades else None,
                    mc_observed=mc.observed_max_drawdown,
                )

            records.append(
                RunRecord(
                    symbol=symbol, strategy=strategy_name, walk_forward=wf,
                    oos_metrics=wf.metrics, split_metrics=split_metrics,
                    monte_carlo=mc, overfitting=overfitting, charts=chart_paths,
                    cost_sensitivity=sens,
                )
            )
            _log(
                f"  {symbol}/{strategy_name}: {wf.metrics.headline()} "
                f"[{time.time() - started:.0f}s]",
                verbose,
            )

    instruments = [
        {
            "symbol": s.symbol, "asset_class": s.asset_class,
            "typical_spread": s.typical_spread, "commission_rate": s.commission_rate,
            "margin_rate": s.margin_rate,
            "financing_rate_annual_long": s.financing_rate_annual_long,
            "financing_rate_annual_short": s.financing_rate_annual_short,
        }
        for s in (DEFAULT_UNIVERSE.get(sym) for sym in cfg.symbols)
    ]

    config_summary = {**cfg.to_dict(), "version": __version__}
    report_text = build_report(
        title=f"Systematic strategy research: {cfg.name}",
        records=records,
        config=config_summary,
        instruments=instruments,
        quality=quality,
        provenance=provenance,
        survivorship_notes=DEFAULT_UNIVERSE.survivorship_notes(),
        survivorship_warnings=survivorship_warnings,
        synthetic=synthetic,
        chart_root=out_root,
        executive_summary=executive_summary(records, synthetic),
    )
    report_path = write_report(report_text, out_root / "research_report.md")

    # Machine-readable artefacts, so results can be diffed between runs.
    summary_rows = []
    for rec in records:
        row = {"symbol": rec.symbol, "strategy": rec.strategy}
        row.update(rec.oos_metrics.to_dict())
        row.update({f"criterion::{k}": v for k, v in evaluate_criteria(rec).items()})
        if rec.overfitting:
            row.update({f"overfit::{k}": v for k, v in rec.overfitting.to_dict().items()})
        row.pop("warnings", None)
        summary_rows.append(row)
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(out_root / "summary.csv", index=False)

    all_trades = pd.concat(
        [rec.walk_forward.trades.assign(run=rec.label) for rec in records if not rec.walk_forward.trades.empty],
        ignore_index=True,
    ) if any(not rec.walk_forward.trades.empty for rec in records) else pd.DataFrame()
    if not all_trades.empty:
        all_trades.to_csv(out_root / "out_of_sample_trades.csv", index=False)

    cfg.to_json(out_root / "config.json")
    (out_root / "quality.csv").write_text(quality.to_csv(), encoding="utf-8")
    with open(out_root / "criteria.json", "w", encoding="utf-8") as fh:
        json.dump(
            {rec.label: evaluate_criteria(rec) for rec in records}, fh, indent=2, sort_keys=True
        )

    _log(f"report written to {report_path}", verbose)
    return {
        "records": records,
        "summary": summary,
        "report_path": report_path,
        "output_dir": str(out_root),
        "synthetic": synthetic,
    }
