"""QuantLab — a research-only systematic trading laboratory.

This package backtests, analyses and stress-tests trading strategies on
historical data.  It has no broker connectivity, no order-routing code and no
credential handling, and it is not to be given any: it is a research and
paper-trading system.

The design assumption throughout is that a backtest's default failure mode is
to look *better* than reality, so every ambiguous choice is resolved
pessimistically (next-bar fills, stop-before-target on ambiguous bars, costs on
every fill, sizes rounded down) and every result is reported with the
overfitting diagnostics needed to discount it.
"""

__version__ = "0.1.0"

LIVE_TRADING_SUPPORTED = False

__all__ = ["__version__", "LIVE_TRADING_SUPPORTED"]
