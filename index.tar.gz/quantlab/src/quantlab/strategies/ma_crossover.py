"""Moving-average crossover — the canonical trend-following baseline.

Included as a *baseline*, not a recommendation.  Crossovers are the most
data-snooped rule in the retail literature: the parameter pair that looks best
on any given sample is almost always the winner of a search, not a discovery.
Treat its walk-forward result as the bar any more elaborate idea has to clear.
"""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
import pandas as pd

from ..indicators import moving_average
from .base import Strategy, StrategyError, expand_grid


class MACrossover(Strategy):
    """Hold long while the fast MA is above the slow MA, short while below.

    Parameters
    ----------
    fast, slow:
        Moving-average windows in bars; ``fast`` must be strictly shorter.
    ma_type:
        ``sma`` or ``ema``.
    min_separation:
        Minimum gap between the averages, as a fraction of price, before a
        position is taken.  A small buffer suppresses the whipsaw trades that
        occur when the two averages sit on top of each other — which is where
        crossover systems bleed their costs.
    """

    name = "ma_crossover"
    defaults: Dict[str, Any] = {
        "fast": 20,
        "slow": 100,
        "ma_type": "sma",
        "min_separation": 0.0,
    }

    def validate(self) -> None:
        p = self.params
        if int(p["fast"]) < 1 or int(p["slow"]) < 2:
            raise StrategyError("fast >= 1 and slow >= 2 required")
        if int(p["fast"]) >= int(p["slow"]):
            raise StrategyError(f"fast ({p['fast']}) must be < slow ({p['slow']})")
        if p["ma_type"] not in ("sma", "ema"):
            raise StrategyError("ma_type must be 'sma' or 'ema'")
        if float(p["min_separation"]) < 0:
            raise StrategyError("min_separation must be >= 0")

    @property
    def lookback(self) -> int:
        return int(self.params["slow"]) + 1

    def _signals(self, df: pd.DataFrame) -> pd.Series:
        close = df["close"]
        fast = moving_average(close, int(self.params["fast"]), self.params["ma_type"])
        slow = moving_average(close, int(self.params["slow"]), self.params["ma_type"])
        gap = (fast - slow) / close

        buffer = float(self.params["min_separation"])
        sig = pd.Series(0.0, index=df.index)
        sig[gap > buffer] = 1.0
        sig[gap < -buffer] = -1.0
        if buffer > 0:
            # Inside the buffer, hold whatever was held rather than flipping to
            # flat and paying a round trip to re-enter moments later.
            sig = sig.replace(0.0, np.nan).ffill().fillna(0.0)
        return sig

    @classmethod
    def param_grid(cls) -> List[Dict[str, Any]]:
        combos = expand_grid(
            {
                "fast": [10, 20, 50],
                "slow": [50, 100, 200],
                "ma_type": ["sma", "ema"],
                "min_separation": [0.0],
            }
        )
        return [c for c in combos if int(c["fast"]) < int(c["slow"])]
