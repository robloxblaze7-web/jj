"""Time-series (absolute) momentum.

Go long when the trailing return over ``lookback`` bars is positive, short when
negative, with the most recent ``skip_bars`` excluded.

The skip is not decoration.  In the momentum literature the standard
construction is a 12-month return skipping the most recent month, because the
last few weeks carry short-term reversal that works against the momentum signal.
It also has a mechanical benefit here: the signal cannot be driven by the same
bar the trade is priced from.

``entry_threshold`` requires the move to exceed a volatility-scaled hurdle
before taking a position, so the system stays flat when the trailing return is
statistically indistinguishable from zero — which is most of the time.
"""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
import pandas as pd

from ..indicators import log_momentum, realised_vol, sma
from .base import Strategy, StrategyError, expand_grid


class Momentum(Strategy):
    """Absolute (time-series) momentum with an optional trend confirmation.

    Parameters
    ----------
    lookback:
        Bars over which the trailing return is measured.
    skip_bars:
        Most recent bars excluded from the measurement.
    entry_threshold:
        Hurdle in units of the annualised volatility scaled to the lookback
        horizon.  0 means "any positive return is a long".
    vol_window:
        Window for the volatility used by ``entry_threshold``.
    confirm_ma:
        If > 0, longs additionally require price above this SMA and shorts
        require price below it.
    """

    name = "momentum"
    defaults: Dict[str, Any] = {
        "lookback": 120,
        "skip_bars": 5,
        "entry_threshold": 0.25,
        "vol_window": 60,
        "confirm_ma": 200,
    }

    def validate(self) -> None:
        p = self.params
        if int(p["lookback"]) < 2:
            raise StrategyError("lookback must be >= 2")
        if int(p["skip_bars"]) < 0:
            raise StrategyError("skip_bars must be >= 0")
        if float(p["entry_threshold"]) < 0:
            raise StrategyError("entry_threshold must be >= 0")
        if int(p["vol_window"]) < 2:
            raise StrategyError("vol_window must be >= 2")
        if int(p["confirm_ma"]) < 0:
            raise StrategyError("confirm_ma must be >= 0")

    @property
    def lookback(self) -> int:
        p = self.params
        return int(
            max(
                int(p["lookback"]) + int(p["skip_bars"]),
                int(p["vol_window"]),
                int(p["confirm_ma"]),
            )
        ) + 1

    def _signals(self, df: pd.DataFrame) -> pd.Series:
        p = self.params
        close = df["close"]
        skip = int(p["skip_bars"])
        lb = int(p["lookback"])

        # Momentum measured from t-skip-lb to t-skip, so the freshest bars are
        # excluded from the signal entirely.
        base = close.shift(skip)
        mom = log_momentum(base, lb)

        vol = realised_vol(close, int(p["vol_window"]))
        horizon_vol = vol * np.sqrt(lb / 252.0)
        hurdle = horizon_vol * float(p["entry_threshold"])

        sig = pd.Series(0.0, index=df.index)
        sig[mom > hurdle] = 1.0
        sig[mom < -hurdle] = -1.0

        cma = int(p["confirm_ma"])
        if cma > 0:
            trend = sma(close, cma)
            block_long = (close <= trend) & sig.gt(0)
            block_short = (close >= trend) & sig.lt(0)
            sig[block_long | block_short] = 0.0
            sig[trend.isna()] = 0.0

        return sig.fillna(0.0)

    @classmethod
    def param_grid(cls) -> List[Dict[str, Any]]:
        return expand_grid(
            {
                "lookback": [60, 120, 250],
                "skip_bars": [0, 5],
                "entry_threshold": [0.0, 0.25],
                "vol_window": [60],
                "confirm_ma": [0, 200],
            }
        )
