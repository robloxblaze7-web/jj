"""Donchian channel breakout (Turtle-style), with an explicit state machine.

Entry: close above the highest high of the prior ``entry_lookback`` bars.
Exit:  close below the lowest low of the prior ``exit_lookback`` bars.
Shorts are the mirror image.

The channel deliberately **excludes the current bar** (see
:func:`quantlab.indicators.rolling_max`).  Comparing today's close to a window
that already contains today's high is a subtle look-ahead-flavoured bug: it
turns "broke out" into "is the highest bar so far", which fires far more often
and far too early.
"""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
import pandas as pd

from ..indicators import atr, rolling_max, rolling_min
from .base import Strategy, StrategyError, expand_grid


class Breakout(Strategy):
    """Channel breakout with separate entry and exit lookbacks.

    Parameters
    ----------
    entry_lookback:
        Channel length for entries.
    exit_lookback:
        Channel length for exits; shorter than the entry channel gives back less
        open profit but exits more trades prematurely.
    min_atr_break:
        Require the close to exceed the channel by this many ATRs before
        entering.  Filters marginal pokes through the level, at the cost of a
        worse entry price on genuine breakouts.
    atr_period:
        ATR window used by ``min_atr_break``.
    """

    name = "breakout"
    defaults: Dict[str, Any] = {
        "entry_lookback": 55,
        "exit_lookback": 20,
        "min_atr_break": 0.0,
        "atr_period": 14,
    }

    def validate(self) -> None:
        p = self.params
        if int(p["entry_lookback"]) < 2:
            raise StrategyError("entry_lookback must be >= 2")
        if int(p["exit_lookback"]) < 1:
            raise StrategyError("exit_lookback must be >= 1")
        if float(p["min_atr_break"]) < 0:
            raise StrategyError("min_atr_break must be >= 0")
        if int(p["atr_period"]) < 2:
            raise StrategyError("atr_period must be >= 2")

    @property
    def lookback(self) -> int:
        p = self.params
        return int(
            max(int(p["entry_lookback"]), int(p["exit_lookback"]), int(p["atr_period"]))
        ) + 1

    def _signals(self, df: pd.DataFrame) -> pd.Series:
        p = self.params
        close = df["close"].to_numpy(dtype=float)

        entry_hi = rolling_max(df["high"], int(p["entry_lookback"])).to_numpy(dtype=float)
        entry_lo = rolling_min(df["low"], int(p["entry_lookback"])).to_numpy(dtype=float)
        exit_lo = rolling_min(df["low"], int(p["exit_lookback"])).to_numpy(dtype=float)
        exit_hi = rolling_max(df["high"], int(p["exit_lookback"])).to_numpy(dtype=float)

        buf = float(p["min_atr_break"])
        band = (
            atr(df, int(p["atr_period"])).to_numpy(dtype=float) * buf
            if buf > 0
            else np.zeros(len(df))
        )
        band = np.nan_to_num(band, nan=0.0)

        n = len(df)
        state = np.zeros(n, dtype=float)
        pos = 0.0
        for i in range(n):
            c = close[i]
            # Exits are evaluated before entries so a bar that both exits and
            # re-enters resolves as flat-then-enter, never as an impossible
            # simultaneous hold of two directions.
            if pos > 0 and not np.isnan(exit_lo[i]) and c < exit_lo[i]:
                pos = 0.0
            elif pos < 0 and not np.isnan(exit_hi[i]) and c > exit_hi[i]:
                pos = 0.0

            if pos == 0.0:
                if not np.isnan(entry_hi[i]) and c > entry_hi[i] + band[i]:
                    pos = 1.0
                elif not np.isnan(entry_lo[i]) and c < entry_lo[i] - band[i]:
                    pos = -1.0
            state[i] = pos

        return pd.Series(state, index=df.index)

    @classmethod
    def param_grid(cls) -> List[Dict[str, Any]]:
        combos = expand_grid(
            {
                "entry_lookback": [20, 55, 100],
                "exit_lookback": [10, 20, 40],
                "min_atr_break": [0.0, 0.25],
                "atr_period": [14],
            }
        )
        return [c for c in combos if int(c["exit_lookback"]) <= int(c["entry_lookback"])]
