"""Strategy interface.

A strategy's only job is to answer one question, bar by bar: *given everything I
know at the close of bar t, what position do I want to hold?*  It returns ``+1``
(long), ``0`` (flat) or ``-1`` (short).

It does not size positions, place stops, know the account balance, or decide
when the order fills.  Those belong to the risk module and the engine.  Keeping
the boundary sharp is what makes it possible to hold the strategy constant while
varying costs, sizing or execution assumptions — which is how you find out
whether an apparent edge is a signal or an artefact of one of those choices.

The base class enforces the contract on every subclass's output:

* the returned index must equal the input index exactly,
* values must be in {-1, 0, +1},
* NaN becomes 0 (flat) rather than propagating,
* the first ``lookback`` bars are forced flat, since indicators are not yet
  defined there and a signal from a partial window is noise,
* shorts are zeroed when constructed with ``long_only=True``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Iterable, List, Mapping

import numpy as np
import pandas as pd

SIGNAL_NAME = "signal"


class StrategyError(ValueError):
    """Invalid strategy parameters or a contract violation in the output."""


class Strategy(ABC):
    """Base class for all signal generators."""

    name: str = "base"

    #: Parameter names and defaults; subclasses override.
    defaults: Dict[str, Any] = {}

    def __init__(self, long_only: bool = False, **params: Any):
        unknown = set(params) - set(self.defaults)
        if unknown:
            raise StrategyError(
                f"{self.name}: unknown parameter(s) {sorted(unknown)}; "
                f"valid: {sorted(self.defaults)}"
            )
        self.params: Dict[str, Any] = {**self.defaults, **params}
        self.long_only = bool(long_only)
        self.validate()

    @abstractmethod
    def _signals(self, df: pd.DataFrame) -> pd.Series:
        """Return the raw desired position per bar, using only data <= t."""

    @property
    @abstractmethod
    def lookback(self) -> int:
        """Bars of history required before the first valid signal."""

    def validate(self) -> None:
        """Raise :class:`StrategyError` for nonsensical parameters."""

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        required = {"open", "high", "low", "close"}
        missing = required - set(df.columns)
        if missing:
            raise StrategyError(f"{self.name}: input is missing column(s) {sorted(missing)}")

        raw = self._signals(df)
        if not isinstance(raw, pd.Series):
            raise StrategyError(f"{self.name}: _signals must return a Series")
        if not raw.index.equals(df.index):
            raise StrategyError(f"{self.name}: signal index does not match the input index")

        sig = raw.astype("float64").fillna(0.0)
        sig = np.sign(sig).clip(-1.0, 1.0)
        if self.long_only:
            sig = sig.clip(lower=0.0)

        bad = sig[~sig.isin([-1.0, 0.0, 1.0])]
        if len(bad):
            raise StrategyError(f"{self.name}: signals must be -1/0/+1, found {bad.unique()[:5]}")

        lb = int(self.lookback)
        if lb > 0:
            sig.iloc[: min(lb, len(sig))] = 0.0
        return sig.rename(SIGNAL_NAME)

    @classmethod
    def param_grid(cls) -> List[Dict[str, Any]]:
        """Candidate parameter sets for optimisation.

        Keep these grids small and economically motivated.  Every extra
        combination inflates the multiple-testing penalty applied in
        :mod:`quantlab.analytics.overfitting`, and a grid of 400 variants
        searched on 1,000 bars will find something that looks wonderful and
        means nothing.
        """
        return [dict(cls.defaults)]

    def clone(self, **overrides: Any) -> "Strategy":
        return type(self)(long_only=self.long_only, **{**self.params, **overrides})

    def param_str(self) -> str:
        return ",".join(f"{k}={self.params[k]}" for k in sorted(self.params))

    def describe(self) -> str:
        direction = "long-only" if self.long_only else "long/short"
        return f"{self.name}({self.param_str()}) [{direction}]"

    def __repr__(self) -> str:  # pragma: no cover - display only
        return f"<{type(self).__name__} {self.param_str()}>"


def expand_grid(grid: Mapping[str, Iterable[Any]]) -> List[Dict[str, Any]]:
    """Cartesian product of a ``{param: values}`` mapping."""
    import itertools

    keys = list(grid)
    return [dict(zip(keys, combo)) for combo in itertools.product(*(list(grid[k]) for k in keys))]
