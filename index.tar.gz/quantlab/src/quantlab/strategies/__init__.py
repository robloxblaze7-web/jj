"""Baseline strategies.

All four are textbook constructions, present as *reference points* rather than
as trading recommendations.  Their value is that they are simple enough to
reason about when the framework produces a surprising number: if a new idea
cannot beat a 20/100 moving-average crossover out-of-sample after costs, the
number to doubt is the new idea's.
"""

from .base import Strategy, StrategyError, expand_grid
from .breakout import Breakout
from .ma_crossover import MACrossover
from .momentum import Momentum
from .registry import (
    STRATEGY_REGISTRY,
    all_strategy_names,
    build_strategy,
    get_strategy_class,
    strategy_grid,
)
from .rsi_reversion import RSIReversion

__all__ = [
    "Strategy", "StrategyError", "expand_grid", "MACrossover", "Breakout",
    "RSIReversion", "Momentum", "STRATEGY_REGISTRY", "get_strategy_class",
    "build_strategy", "strategy_grid", "all_strategy_names",
]
