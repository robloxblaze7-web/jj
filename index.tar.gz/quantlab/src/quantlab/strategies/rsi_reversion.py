"""RSI mean reversion, optionally filtered by a longer-term trend.

Buy when RSI is oversold, exit when it returns to neutral; mirror for shorts.

Two structural warnings that belong with the code rather than in a footnote:

* Mean-reversion equity curves are made of many small wins and rare large
  losses.  A high win rate here is the *expected* shape and is not evidence of
  an edge — expectancy and the tail of the R-multiple distribution are what
  matter.  This is the strategy family most flattered by a naive win-rate
  headline.
* Reversion entries are, by construction, taken against short-term momentum, so
  fills are adverse.  Whether the modelled slippage is realistic decides most of
  the result.
"""

from __future__ import annotations

from typing import Any, Dict, List

import numpy as np
import pandas as pd

from ..indicators import rsi, sma
from .base import Strategy, StrategyError, expand_grid


class RSIReversion(Strategy):
    """Oversold/overbought entries with a neutral-zone exit.

    Parameters
    ----------
    rsi_period:
        Wilder RSI window.
    oversold / overbought:
        Entry thresholds.
    exit_level:
        RSI level at which an open position is closed (crossing up through it
        for longs, down through it for shorts).
    trend_filter:
        SMA window for a regime filter; longs are only taken above it and shorts
        only below it.  0 disables the filter, which typically raises trade
        count and lowers expectancy.
    """

    name = "rsi_reversion"
    # A 14-period RSI with a 200-SMA filter fires roughly six times in sixteen
    # years of daily data — too few trades to say anything statistically.  The
    # default is therefore a 7-period RSI, which is more responsive without
    # abandoning the classic 30/70 thresholds.
    defaults: Dict[str, Any] = {
        "rsi_period": 7,
        "oversold": 30.0,
        "overbought": 70.0,
        "exit_level": 50.0,
        "trend_filter": 200,
    }

    def validate(self) -> None:
        p = self.params
        if int(p["rsi_period"]) < 2:
            raise StrategyError("rsi_period must be >= 2")
        lo, hi, ex = float(p["oversold"]), float(p["overbought"]), float(p["exit_level"])
        if not 0 < lo < hi < 100:
            raise StrategyError("require 0 < oversold < overbought < 100")
        if not lo < ex < hi:
            raise StrategyError("exit_level must sit between oversold and overbought")
        if int(p["trend_filter"]) < 0:
            raise StrategyError("trend_filter must be >= 0")

    @property
    def lookback(self) -> int:
        p = self.params
        return int(max(int(p["rsi_period"]) * 2, int(p["trend_filter"]))) + 1

    def _signals(self, df: pd.DataFrame) -> pd.Series:
        p = self.params
        close = df["close"]
        r = rsi(close, int(p["rsi_period"])).to_numpy(dtype=float)

        tf = int(p["trend_filter"])
        if tf > 0:
            trend = sma(close, tf)
            above = (close > trend).to_numpy(dtype=bool)
            below = (close < trend).to_numpy(dtype=bool)
            defined = trend.notna().to_numpy(dtype=bool)
        else:
            above = np.ones(len(df), dtype=bool)
            below = np.ones(len(df), dtype=bool)
            defined = np.ones(len(df), dtype=bool)

        lo, hi, ex = float(p["oversold"]), float(p["overbought"]), float(p["exit_level"])
        n = len(df)
        state = np.zeros(n, dtype=float)
        pos = 0.0
        for i in range(n):
            ri = r[i]
            if np.isnan(ri):
                state[i] = 0.0
                pos = 0.0
                continue
            if pos > 0 and ri >= ex:
                pos = 0.0
            elif pos < 0 and ri <= ex:
                pos = 0.0

            if pos == 0.0 and defined[i]:
                if ri <= lo and above[i]:
                    pos = 1.0
                elif ri >= hi and below[i]:
                    pos = -1.0
            state[i] = pos
        return pd.Series(state, index=df.index)

    @classmethod
    def param_grid(cls) -> List[Dict[str, Any]]:
        return expand_grid(
            {
                "rsi_period": [7, 14],
                "oversold": [20.0, 30.0],
                "overbought": [70.0, 80.0],
                "exit_level": [50.0],
                "trend_filter": [0, 200],
            }
        )
