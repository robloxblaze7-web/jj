"""Strategy registry: name -> class, with construction and grid helpers."""

from __future__ import annotations

from typing import Any, Dict, List, Type

from .base import Strategy
from .breakout import Breakout
from .ma_crossover import MACrossover
from .momentum import Momentum
from .rsi_reversion import RSIReversion

STRATEGY_REGISTRY: Dict[str, Type[Strategy]] = {
    MACrossover.name: MACrossover,
    Breakout.name: Breakout,
    RSIReversion.name: RSIReversion,
    Momentum.name: Momentum,
}


def get_strategy_class(name: str) -> Type[Strategy]:
    key = name.strip().lower()
    if key not in STRATEGY_REGISTRY:
        raise KeyError(f"unknown strategy {name!r}; known: {sorted(STRATEGY_REGISTRY)}")
    return STRATEGY_REGISTRY[key]


def build_strategy(
    name: str, params: Dict[str, Any] | None = None, long_only: bool = False
) -> Strategy:
    cls = get_strategy_class(name)
    return cls(long_only=long_only, **(params or {}))


def strategy_grid(name: str) -> List[Dict[str, Any]]:
    """Candidate parameter sets for ``name``.

    The size of this list is recorded with every walk-forward result and feeds
    the multiple-testing penalty: searching 24 variants and reporting only the
    best without adjusting for the search is the textbook definition of data
    snooping.
    """
    return get_strategy_class(name).param_grid()


def all_strategy_names() -> List[str]:
    return sorted(STRATEGY_REGISTRY)
