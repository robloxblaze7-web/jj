"""Configuration objects for QuantLab.

Everything that changes the behaviour of a backtest lives in a dataclass here,
so that a run can be described (and archived) by a single JSON blob.  That is a
research-integrity feature, not a convenience: if you cannot reproduce the exact
configuration that produced a result, the result is an anecdote, not evidence.

No third-party config libraries are used (no PyYAML) to keep the dependency
surface at numpy/pandas/matplotlib.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Type, TypeVar, get_type_hints

T = TypeVar("T")


def _from_dict(cls: Type[T], data: Mapping[str, Any]) -> T:
    """Build a (possibly nested) dataclass from a mapping, rejecting typos.

    Unknown keys raise instead of being silently ignored.  A silently ignored
    ``risk_per_trad`` key is exactly the kind of bug that makes a backtest look
    good for the wrong reason.
    """
    if not is_dataclass(cls):
        raise TypeError(f"{cls!r} is not a dataclass")

    known = {f.name: f for f in fields(cls)}
    unknown = set(data) - set(known)
    if unknown:
        raise ValueError(
            f"unknown config key(s) for {cls.__name__}: {sorted(unknown)}; "
            f"valid keys are {sorted(known)}"
        )

    # ``from __future__ import annotations`` turns field types into strings, so
    # resolve them before testing for nested dataclasses.
    hints = get_type_hints(cls)

    kwargs: Dict[str, Any] = {}
    for name in known:
        if name not in data:
            continue
        value = data[name]
        ftype = hints.get(name)
        if is_dataclass(ftype) and isinstance(value, Mapping):
            kwargs[name] = _from_dict(ftype, value)  # type: ignore[arg-type]
        else:
            kwargs[name] = value
    return cls(**kwargs)  # type: ignore[return-value]


@dataclass
class CostConfig:
    """Transaction cost assumptions.

    All three components are applied on *every* fill.  Defaults are deliberately
    pessimistic: it is far cheaper to be wrong in the conservative direction.

    Attributes
    ----------
    spread_multiplier:
        Scales the instrument's typical spread.  Set >1 to stress-test how much
        of an apparent edge survives worse execution.
    slippage_bps:
        Fixed slippage in basis points of price, always adverse.
    slippage_atr_fraction:
        Additional slippage as a fraction of current ATR, always adverse.  This
        makes costs scale with volatility, which is how real markets behave.
    commission_multiplier:
        Scales the instrument's commission schedule.
    apply_spread_on_entry / apply_spread_on_exit:
        Whether the half-spread is crossed on each side.  Both default True
        (i.e. the full round-turn spread is paid), which matches a retail
        market-order round trip.
    """

    spread_multiplier: float = 1.0
    slippage_bps: float = 0.5
    slippage_atr_fraction: float = 0.02
    commission_multiplier: float = 1.0
    apply_spread_on_entry: bool = True
    apply_spread_on_exit: bool = True

    def validate(self) -> None:
        if self.spread_multiplier < 0:
            raise ValueError("spread_multiplier must be >= 0")
        if self.slippage_bps < 0:
            raise ValueError("slippage_bps must be >= 0")
        if self.slippage_atr_fraction < 0:
            raise ValueError("slippage_atr_fraction must be >= 0")
        if self.commission_multiplier < 0:
            raise ValueError("commission_multiplier must be >= 0")


@dataclass
class RiskConfig:
    """Position sizing and risk limits.

    Attributes
    ----------
    sizing_method:
        One of ``fixed_risk`` (risk a fixed fraction of equity per trade, sized
        off the stop distance), ``fixed_fraction`` (notional is a fixed fraction
        of equity) or ``vol_target`` (size so that annualised position vol hits
        a target).
    risk_per_trade:
        Fraction of *current equity* put at risk between entry and stop.
        0.005 = 0.5%.
    stop_atr_multiple / take_profit_atr_multiple:
        Stop and target distances in ATR units.  Setting the take profit to 0
        disables it (exits then come from the signal or the stop).
    max_account_leverage:
        Hard cap on gross notional / equity.
    max_position_fraction:
        Cap on a single position's notional as a fraction of equity.
    daily_loss_limit:
        Fraction of start-of-session equity that, once lost, halts new entries
        for the following session.  0 disables.
    max_drawdown_stop:
        Fraction of peak equity that, once lost, permanently halts new entries
        and closes open positions (a kill switch).  0 disables.
    min_units:
        Smallest tradeable size.  Orders below this are skipped rather than
        rounded up, so risk limits are never silently exceeded.
    """

    sizing_method: str = "fixed_risk"
    risk_per_trade: float = 0.005
    fixed_fraction: float = 0.10
    target_annual_vol: float = 0.10
    stop_atr_multiple: float = 2.0
    take_profit_atr_multiple: float = 3.0
    max_account_leverage: float = 5.0
    max_position_fraction: float = 2.0
    daily_loss_limit: float = 0.0
    max_drawdown_stop: float = 0.35
    min_units: float = 1e-6

    VALID_METHODS = ("fixed_risk", "fixed_fraction", "vol_target")

    def validate(self) -> None:
        if self.sizing_method not in self.VALID_METHODS:
            raise ValueError(
                f"sizing_method must be one of {self.VALID_METHODS}, got {self.sizing_method!r}"
            )
        if not 0 < self.risk_per_trade < 1:
            raise ValueError("risk_per_trade must be in (0, 1)")
        if not 0 < self.fixed_fraction <= 100:
            raise ValueError("fixed_fraction must be in (0, 100]")
        if self.stop_atr_multiple <= 0:
            raise ValueError("stop_atr_multiple must be > 0 (a stop is mandatory)")
        if self.take_profit_atr_multiple < 0:
            raise ValueError("take_profit_atr_multiple must be >= 0")
        if self.max_account_leverage <= 0:
            raise ValueError("max_account_leverage must be > 0")
        if not 0 <= self.daily_loss_limit < 1:
            raise ValueError("daily_loss_limit must be in [0, 1)")
        if not 0 <= self.max_drawdown_stop < 1:
            raise ValueError("max_drawdown_stop must be in [0, 1)")


@dataclass
class SplitConfig:
    """In-sample / validation / out-of-sample partitioning.

    The three fractions must sum to 1.  ``embargo_bars`` drops bars at each
    boundary so that indicators with long lookbacks cannot leak information from
    the training window into the validation or test window.
    """

    train_fraction: float = 0.50
    validation_fraction: float = 0.25
    test_fraction: float = 0.25
    embargo_bars: int = 20

    def validate(self) -> None:
        total = self.train_fraction + self.validation_fraction + self.test_fraction
        if abs(total - 1.0) > 1e-9:
            raise ValueError(f"split fractions must sum to 1.0, got {total}")
        for name in ("train_fraction", "validation_fraction", "test_fraction"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be > 0")
        if self.embargo_bars < 0:
            raise ValueError("embargo_bars must be >= 0")


@dataclass
class WalkForwardConfig:
    """Rolling or anchored walk-forward analysis.

    ``train_bars`` are used to select parameters; the selected parameters are
    then applied, untouched, to the following ``test_bars``.  The window then
    advances by ``step_bars`` (defaults to ``test_bars``, giving non-overlapping
    test segments).
    """

    train_bars: int = 750
    test_bars: int = 250
    step_bars: Optional[int] = None
    anchored: bool = False
    embargo_bars: int = 5
    selection_metric: str = "sharpe_ratio"
    min_trades_for_selection: int = 10

    def resolved_step(self) -> int:
        return int(self.step_bars) if self.step_bars else int(self.test_bars)

    def validate(self) -> None:
        if self.train_bars <= 0 or self.test_bars <= 0:
            raise ValueError("train_bars and test_bars must be > 0")
        if self.step_bars is not None and self.step_bars <= 0:
            raise ValueError("step_bars must be > 0 when set")
        if self.embargo_bars < 0:
            raise ValueError("embargo_bars must be >= 0")


@dataclass
class MonteCarloConfig:
    """Monte Carlo resampling of the realised trade sequence."""

    n_simulations: int = 5000
    method: str = "bootstrap"  # bootstrap | shuffle | block_bootstrap
    block_size: int = 5
    confidence_levels: List[float] = field(default_factory=lambda: [0.5, 0.75, 0.95, 0.99])
    seed: int = 20260907

    VALID_METHODS = ("bootstrap", "shuffle", "block_bootstrap")

    def validate(self) -> None:
        if self.method not in self.VALID_METHODS:
            raise ValueError(f"monte carlo method must be one of {self.VALID_METHODS}")
        if self.n_simulations <= 0:
            raise ValueError("n_simulations must be > 0")
        if self.block_size <= 0:
            raise ValueError("block_size must be > 0")
        for level in self.confidence_levels:
            if not 0 < level < 1:
                raise ValueError("confidence levels must be in (0, 1)")


@dataclass
class BacktestConfig:
    """Everything the engine needs that is not the data or the strategy.

    ``execution_lag_bars`` is deliberately not configurable below 1.  A signal
    computed from bar *t*'s close cannot be executed inside bar *t*; allowing
    that is the single most common way backtests manufacture returns that do not
    exist.
    """

    initial_balance: float = 100_000.0
    account_currency: str = "USD"
    allow_short: bool = True
    execution_lag_bars: int = 1
    atr_period: int = 14
    bars_per_year: float = 252.0
    risk_free_rate: float = 0.0
    costs: CostConfig = field(default_factory=CostConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    warmup_bars: int = 200
    seed: int = 20260907

    def validate(self) -> None:
        if self.initial_balance <= 0:
            raise ValueError("initial_balance must be > 0")
        if self.execution_lag_bars < 1:
            raise ValueError(
                "execution_lag_bars must be >= 1; executing on the signal bar itself "
                "is look-ahead bias"
            )
        if self.atr_period < 2:
            raise ValueError("atr_period must be >= 2")
        if self.bars_per_year <= 0:
            raise ValueError("bars_per_year must be > 0")
        if self.warmup_bars < 0:
            raise ValueError("warmup_bars must be >= 0")
        self.costs.validate()
        self.risk.validate()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "BacktestConfig":
        cfg = _from_dict(cls, data)
        cfg.validate()
        return cfg

    @classmethod
    def from_json(cls, path: str | Path) -> "BacktestConfig":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))

    def to_json(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2, sort_keys=True)


@dataclass
class ExperimentConfig:
    """A complete, archivable description of a research run."""

    name: str = "baseline"
    symbols: List[str] = field(
        default_factory=lambda: ["EURUSD", "GBPUSD", "XAUUSD", "SPX500"]
    )
    strategies: List[str] = field(
        default_factory=lambda: ["ma_crossover", "breakout", "rsi_reversion", "momentum"]
    )
    start: str = "2010-01-01"
    end: str = "2025-12-31"
    backtest: BacktestConfig = field(default_factory=BacktestConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    walk_forward: WalkForwardConfig = field(default_factory=WalkForwardConfig)
    monte_carlo: MonteCarloConfig = field(default_factory=MonteCarloConfig)
    data_source: str = "synthetic"  # synthetic | csv
    output_dir: str = "reports/runs"

    def validate(self) -> None:
        if not self.symbols:
            raise ValueError("at least one symbol is required")
        if not self.strategies:
            raise ValueError("at least one strategy is required")
        if self.data_source not in ("synthetic", "csv"):
            raise ValueError("data_source must be 'synthetic' or 'csv'")
        self.backtest.validate()
        self.split.validate()
        self.walk_forward.validate()
        self.monte_carlo.validate()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ExperimentConfig":
        cfg = _from_dict(cls, data)
        cfg.validate()
        return cfg

    @classmethod
    def from_json(cls, path: str | Path) -> "ExperimentConfig":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))

    def to_json(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2, sort_keys=True)
