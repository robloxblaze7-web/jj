"""Charts for the research report.

Design rules applied here (they are the reason the functions look the way they
do, so they are stated rather than left implicit):

* **One axis per chart.**  No dual-scale plots.  Where two quantities of
  different scale matter, they get two stacked panels sharing an x-axis.
* **Colour by job.**  A fixed categorical order (blue, orange, aqua) for
  identity; a blue->red diverging ramp with a neutral grey midpoint, centred
  exactly on zero, for the monthly-returns heatmap where the sign is the point;
  reserved red/green only for gain/loss status.  Colours are never cycled and
  never assigned by rank.
* **Recessive furniture.**  Thin marks, light grid, no chart junk.  Text is ink
  coloured, never the series colour, so identity always comes from a legend or a
  direct label rather than from colour alone.
* **Every chart states what it cannot tell you.**  Captions carry the caveat
  (synthetic data, in-sample vs out-of-sample) into the image itself, because
  images are what get screenshotted and forwarded without their surrounding
  paragraph.

The palette is the validated reference instance; the three categorical slots used
here clear the colour-blindness and normal-vision separation gates as a set.
Matplotlib renders to a file, so a chart cannot adapt to a viewer's theme: light
and dark are provided as explicit, separately specified themes.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import matplotlib

matplotlib.use("Agg")  # headless rendering; no display required
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


@dataclass(frozen=True)
class Theme:
    """Colour roles for one rendering mode."""

    surface: str
    text_primary: str
    text_secondary: str
    text_muted: str
    grid: str
    axis: str
    series_1: str      # blue
    series_2: str      # orange
    series_3: str      # aqua
    positive: str
    negative: str
    neutral_mid: str
    diverging_low: str
    diverging_high: str


LIGHT = Theme(
    surface="#fcfcfb", text_primary="#0b0b0b", text_secondary="#52514e",
    text_muted="#7a7973", grid="#e6e5e1", axis="#c9c8c3",
    series_1="#2a78d6", series_2="#eb6834", series_3="#1baf7a",
    positive="#1baf7a", negative="#e34948", neutral_mid="#f0efec",
    diverging_low="#e34948", diverging_high="#2a78d6",
)

DARK = Theme(
    surface="#1a1a19", text_primary="#ffffff", text_secondary="#c3c2b7",
    text_muted="#8f8e86", grid="#2e2e2c", axis="#4a4a46",
    series_1="#3987e5", series_2="#d95926", series_3="#199e70",
    positive="#199e70", negative="#e66767", neutral_mid="#383835",
    diverging_low="#e66767", diverging_high="#3987e5",
)

FIGSIZE = (11.0, 5.0)
DPI = 130


def _style(ax, theme: Theme, *, ygrid: bool = True, xgrid: bool = False) -> None:
    ax.set_facecolor(theme.surface)
    ax.tick_params(colors=theme.text_secondary, labelsize=9, length=3, width=0.8)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(theme.axis)
        ax.spines[side].set_linewidth(0.8)
    if ygrid:
        ax.grid(True, axis="y", color=theme.grid, linewidth=0.7, alpha=0.9)
    if xgrid:
        ax.grid(True, axis="x", color=theme.grid, linewidth=0.7, alpha=0.9)
    ax.set_axisbelow(True)


def _finish(fig, ax_or_axes, theme: Theme, title: str, caption: str, path) -> str:
    axes = ax_or_axes if isinstance(ax_or_axes, (list, tuple, np.ndarray)) else [ax_or_axes]
    fig.patch.set_facecolor(theme.surface)
    axes[0].set_title(title, color=theme.text_primary, fontsize=12.5, loc="left", pad=12)
    if caption:
        fig.text(
            0.008, 0.008, caption, color=theme.text_muted, fontsize=8.2,
            ha="left", va="bottom", wrap=True,
        )
        fig.tight_layout(rect=(0, 0.055, 1, 1))
    else:
        fig.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=DPI, facecolor=theme.surface)
    plt.close(fig)
    return str(path)


def _pct(x, _pos=None) -> str:
    return f"{x:.0%}"


# --------------------------------------------------------------------------- #
# 1. equity curve
# --------------------------------------------------------------------------- #
def plot_equity_curve(
    equity: pd.Series,
    path,
    *,
    title: str = "Equity curve",
    caption: str = "",
    benchmark: Optional[pd.Series] = None,
    benchmark_label: str = "Buy and hold",
    log_scale: bool = False,
    theme: Theme = LIGHT,
) -> str:
    """Account equity over time, optionally against a benchmark.

    A log scale is offered because on a linear axis a long compounding curve
    makes early drawdowns invisible — the same 20% loss looks trivial at the
    start and catastrophic at the end.
    """
    fig, ax = plt.subplots(figsize=FIGSIZE)
    _style(ax, theme)

    ax.plot(equity.index, equity.to_numpy(), color=theme.series_1, linewidth=2.0,
            label="Strategy equity", solid_capstyle="round")
    if benchmark is not None and len(benchmark):
        bench = benchmark.reindex(equity.index).ffill()
        bench = bench / bench.iloc[0] * float(equity.iloc[0])
        ax.plot(bench.index, bench.to_numpy(), color=theme.series_2, linewidth=1.6,
                linestyle="--", label=benchmark_label)

    start_equity = float(equity.iloc[0])
    ax.axhline(start_equity, color=theme.axis, linewidth=0.9, linestyle=":", zorder=1)
    if log_scale:
        ax.set_yscale("log")

    # One direct label rather than a number on every point.
    final = float(equity.iloc[-1])
    ax.scatter([equity.index[-1]], [final], s=34, color=theme.series_1, zorder=5,
               edgecolor=theme.surface, linewidth=1.5)
    ax.annotate(
        f"{final:,.0f} ({final / start_equity - 1:+.1%})",
        xy=(equity.index[-1], final), xytext=(-10, 20), textcoords="offset points",
        color=theme.text_primary, fontsize=9.5, ha="right", fontweight="medium",
        bbox=dict(boxstyle="round,pad=0.25", facecolor=theme.surface, edgecolor="none",
                  alpha=0.85),
    )

    ax.set_ylabel("Account equity", color=theme.text_secondary, fontsize=9.5)
    if benchmark is not None and len(benchmark):
        leg = ax.legend(frameon=False, fontsize=9, loc="upper left")
        for text in leg.get_texts():
            text.set_color(theme.text_secondary)
    return _finish(fig, ax, theme, title, caption, path)


# --------------------------------------------------------------------------- #
# 2. drawdown
# --------------------------------------------------------------------------- #
def plot_drawdown(
    equity: pd.Series,
    path,
    *,
    title: str = "Drawdown from peak equity",
    caption: str = "",
    theme: Theme = LIGHT,
) -> str:
    """Underwater curve.

    Plotted separately from equity rather than on a second axis: a dual-scale
    chart makes the relationship between the two look like whatever the axis
    limits were chosen to make it look like.
    """
    dd = (equity / equity.cummax() - 1.0).astype(float)
    fig, ax = plt.subplots(figsize=(FIGSIZE[0], 3.6))
    _style(ax, theme)

    ax.fill_between(dd.index, dd.to_numpy(), 0.0, color=theme.negative, alpha=0.22, linewidth=0)
    ax.plot(dd.index, dd.to_numpy(), color=theme.negative, linewidth=1.4)
    ax.axhline(0.0, color=theme.axis, linewidth=0.9)

    worst_idx = dd.idxmin()
    worst = float(dd.min())
    ax.annotate(
        f"worst {worst:.1%}", xy=(worst_idx, worst), xytext=(8, -12),
        textcoords="offset points", color=theme.text_primary, fontsize=9.5,
    )
    ax.scatter([worst_idx], [worst], s=36, color=theme.negative, zorder=5,
               edgecolor=theme.surface, linewidth=1.5)

    ax.yaxis.set_major_formatter(plt.FuncFormatter(_pct))
    ax.set_ylabel("Drawdown", color=theme.text_secondary, fontsize=9.5)
    return _finish(fig, ax, theme, title, caption, path)


# --------------------------------------------------------------------------- #
# 3. monthly returns heatmap
# --------------------------------------------------------------------------- #
def plot_monthly_returns(
    table: pd.DataFrame,
    path,
    *,
    title: str = "Monthly returns (%)",
    caption: str = "",
    theme: Theme = LIGHT,
) -> str:
    """Year x month heatmap of returns.

    Sign is the quantity of interest, so the ramp is diverging (red -> neutral
    grey -> blue) and is centred exactly on zero: a colour scale whose midpoint
    drifts with the data makes losing months look positive.  Every cell also
    carries its number, which satisfies the relief rule for the lighter steps and
    means the chart is readable in greyscale or by a colour-blind reader.
    """
    if table.empty:
        fig, ax = plt.subplots(figsize=(FIGSIZE[0], 2.2))
        _style(ax, theme, ygrid=False)
        ax.text(0.5, 0.5, "no completed months", ha="center", va="center",
                color=theme.text_muted, transform=ax.transAxes)
        ax.set_xticks([]); ax.set_yticks([])
        return _finish(fig, ax, theme, title, caption, path)

    cmap = LinearSegmentedColormap.from_list(
        "quantlab_div", [theme.diverging_low, theme.neutral_mid, theme.diverging_high], N=256
    )
    values = table.to_numpy(dtype=float)
    finite = values[np.isfinite(values)]
    limit = float(np.nanmax(np.abs(finite))) if finite.size else 0.01
    limit = max(limit, 1e-6)
    norm = TwoSlopeNorm(vmin=-limit, vcenter=0.0, vmax=limit)

    height = max(2.4, 0.34 * len(table) + 1.5)
    fig, ax = plt.subplots(figsize=(FIGSIZE[0], height))
    ax.set_facecolor(theme.surface)
    ax.imshow(values, cmap=cmap, norm=norm, aspect="auto", interpolation="nearest")

    month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    ax.set_xticks(range(len(table.columns)))
    ax.set_xticklabels([month_names[int(m) - 1] for m in table.columns], fontsize=9)
    ax.set_yticks(range(len(table.index)))
    ax.set_yticklabels([str(y) for y in table.index], fontsize=9)
    ax.tick_params(colors=theme.text_secondary, length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)

    # 2px surface gap between cells
    ax.set_xticks(np.arange(-0.5, len(table.columns), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(table.index), 1), minor=True)
    ax.grid(which="minor", color=theme.surface, linewidth=2.0)
    ax.tick_params(which="minor", length=0)

    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            v = values[i, j]
            if not np.isfinite(v):
                continue
            ax.text(j, i, f"{v * 100:.1f}", ha="center", va="center", fontsize=7.6,
                    color=theme.text_primary)
    return _finish(fig, ax, theme, title, caption, path)


# --------------------------------------------------------------------------- #
# 4. trade distribution
# --------------------------------------------------------------------------- #
def plot_trade_distribution(
    r_multiples: Sequence[float],
    path,
    *,
    title: str = "Trade outcomes (R-multiples)",
    caption: str = "",
    theme: Theme = LIGHT,
) -> str:
    """Histogram of trade outcomes in units of risk.

    Bars are coloured by sign (a reserved status pair, not a categorical hue) and
    two reference lines are drawn: -1R, the planned maximum loss, and the mean.
    Mass to the left of -1R is the part of the distribution that the position
    sizing did not plan for — gaps through stops and round-turn costs.
    """
    r = np.asarray(list(r_multiples), dtype=float)
    r = r[np.isfinite(r)]
    fig, ax = plt.subplots(figsize=FIGSIZE)
    _style(ax, theme)

    if r.size == 0:
        ax.text(0.5, 0.5, "no trades", ha="center", va="center",
                color=theme.text_muted, transform=ax.transAxes)
        return _finish(fig, ax, theme, title, caption, path)

    bins = np.histogram_bin_edges(r, bins=min(40, max(12, int(np.sqrt(r.size) * 2))))
    counts, edges = np.histogram(r, bins=bins)
    centres = (edges[:-1] + edges[1:]) / 2
    colors = [theme.positive if c > 0 else theme.negative for c in centres]
    ax.bar(centres, counts, width=(edges[1] - edges[0]) * 0.9, color=colors,
           edgecolor=theme.surface, linewidth=0.8)

    ax.axvline(-1.0, color=theme.text_secondary, linewidth=1.2, linestyle="--")
    ax.annotate("planned stop (-1R)", xy=(-1.0, ax.get_ylim()[1]), xytext=(4, -12),
                textcoords="offset points", color=theme.text_secondary, fontsize=8.6)
    mean_r = float(r.mean())
    ax.axvline(mean_r, color=theme.series_1, linewidth=1.6)
    ax.annotate(f"mean {mean_r:+.2f}R", xy=(mean_r, ax.get_ylim()[1]), xytext=(4, -28),
                textcoords="offset points", color=theme.text_primary, fontsize=9)

    beyond = float((r < -1.0 - 1e-9).mean())
    ax.set_xlabel(
        f"R-multiple   ({beyond:.0%} of trades lost more than the planned 1R)",
        color=theme.text_secondary, fontsize=9.5,
    )
    ax.set_ylabel("Trades", color=theme.text_secondary, fontsize=9.5)
    return _finish(fig, ax, theme, title, caption, path)


# --------------------------------------------------------------------------- #
# 5. rolling Sharpe
# --------------------------------------------------------------------------- #
def plot_rolling_sharpe(
    rolling: pd.Series,
    path,
    *,
    window_label: str = "252-bar",
    title: str = "Rolling Sharpe ratio",
    caption: str = "",
    theme: Theme = LIGHT,
) -> str:
    """Trailing Sharpe through time.

    The point of this chart is instability, not level.  A band at +/-0.5 marks the
    region that is statistically indistinguishable from zero over a one-year
    window, so a line that wanders in and out of it is telling you the headline
    Sharpe is an average of noise.
    """
    fig, ax = plt.subplots(figsize=(FIGSIZE[0], 3.8))
    _style(ax, theme)
    series = rolling.dropna()

    if series.empty:
        ax.text(0.5, 0.5, "not enough history for a rolling window", ha="center",
                va="center", color=theme.text_muted, transform=ax.transAxes)
        return _finish(fig, ax, theme, title, caption, path)

    ax.axhspan(-0.5, 0.5, color=theme.grid, alpha=0.7, zorder=0)
    ax.plot(series.index, series.to_numpy(), color=theme.series_1, linewidth=1.8)
    ax.axhline(0.0, color=theme.axis, linewidth=1.0)
    ax.annotate("indistinguishable from zero", xy=(series.index[0], 0.5),
                xytext=(4, 4), textcoords="offset points",
                color=theme.text_muted, fontsize=8.4)
    ax.set_ylabel(f"{window_label} Sharpe", color=theme.text_secondary, fontsize=9.5)
    return _finish(fig, ax, theme, title, caption, path)


# --------------------------------------------------------------------------- #
# 6. Monte Carlo drawdown distribution
# --------------------------------------------------------------------------- #
def plot_monte_carlo_drawdowns(
    max_drawdowns: Sequence[float],
    observed: float,
    path,
    *,
    title: str = "Simulated maximum drawdown",
    caption: str = "",
    theme: Theme = LIGHT,
) -> str:
    """Distribution of maximum drawdown across resampled trade orderings.

    The historical drawdown is one draw from this distribution.  Its position in
    the distribution — not its value — is what says whether the backtest got a
    lucky sequence.
    """
    dd = np.asarray(list(max_drawdowns), dtype=float)
    dd = dd[np.isfinite(dd)]
    fig, ax = plt.subplots(figsize=FIGSIZE)
    _style(ax, theme)

    if dd.size == 0:
        ax.text(0.5, 0.5, "no simulations", ha="center", va="center",
                color=theme.text_muted, transform=ax.transAxes)
        return _finish(fig, ax, theme, title, caption, path)

    ax.hist(dd, bins=60, color=theme.series_1, alpha=0.85, edgecolor=theme.surface,
            linewidth=0.6)
    p95 = float(np.quantile(dd, 0.05))   # 5th pct of a negative quantity = deep tail
    ax.axvline(observed, color=theme.series_2, linewidth=2.0)
    ax.annotate(f"historical {observed:.1%}", xy=(observed, ax.get_ylim()[1]),
                xytext=(5, -14), textcoords="offset points",
                color=theme.text_primary, fontsize=9)
    ax.axvline(p95, color=theme.text_secondary, linewidth=1.3, linestyle="--")
    ax.annotate(f"1-in-20 worst {p95:.1%}", xy=(p95, ax.get_ylim()[1]),
                xytext=(5, -32), textcoords="offset points",
                color=theme.text_secondary, fontsize=9)

    ax.xaxis.set_major_formatter(plt.FuncFormatter(_pct))
    ax.set_xlabel("Maximum drawdown of a resampled trade sequence",
                  color=theme.text_secondary, fontsize=9.5)
    ax.set_ylabel("Simulations", color=theme.text_secondary, fontsize=9.5)
    return _finish(fig, ax, theme, title, caption, path)


# --------------------------------------------------------------------------- #
# 7. walk-forward: in-sample vs out-of-sample per fold
# --------------------------------------------------------------------------- #
def plot_walk_forward_folds(
    fold_table: pd.DataFrame,
    path,
    *,
    metric_label: str = "Sharpe",
    title: str = "Selected parameters: in-sample vs out-of-sample",
    caption: str = "",
    theme: Theme = LIGHT,
) -> str:
    """Per-fold training score beside the score the same parameters achieved next.

    This is the single most informative chart in the report.  Bars that are tall
    on the left and short or negative on the right are the visual signature of an
    optimiser fitting noise.
    """
    fig, ax = plt.subplots(figsize=FIGSIZE)
    _style(ax, theme)

    if fold_table.empty:
        ax.text(0.5, 0.5, "no folds", ha="center", va="center",
                color=theme.text_muted, transform=ax.transAxes)
        return _finish(fig, ax, theme, title, caption, path)

    folds = fold_table["fold"].to_numpy()
    x = np.arange(len(folds), dtype=float)
    width = 0.4
    train = fold_table["train_score"].to_numpy(dtype=float)
    test = fold_table["test_score"].to_numpy(dtype=float)

    ax.bar(x - width / 2, train, width * 0.94, color=theme.series_1,
           label="in-sample (selection)", edgecolor=theme.surface, linewidth=1.0)
    ax.bar(x + width / 2, test, width * 0.94, color=theme.series_2,
           label="out-of-sample (next window)", edgecolor=theme.surface, linewidth=1.0)
    ax.axhline(0.0, color=theme.axis, linewidth=1.0)

    ax.set_xticks(x)
    ax.set_xticklabels([str(int(f)) for f in folds], fontsize=9)
    ax.set_xlabel("Walk-forward fold", color=theme.text_secondary, fontsize=9.5)
    ax.set_ylabel(metric_label, color=theme.text_secondary, fontsize=9.5)
    leg = ax.legend(frameon=False, fontsize=9, loc="best")
    for text in leg.get_texts():
        text.set_color(theme.text_secondary)
    return _finish(fig, ax, theme, title, caption, path)


def chart_set(
    *,
    equity: pd.Series,
    trades: pd.DataFrame,
    monthly: pd.DataFrame,
    rolling: pd.Series,
    outdir,
    prefix: str,
    caption: str = "",
    fold_table: Optional[pd.DataFrame] = None,
    mc_drawdowns: Optional[Sequence[float]] = None,
    mc_observed: float = float("nan"),
    theme: Theme = LIGHT,
) -> Dict[str, str]:
    """Render the standard chart set for one result and return the paths."""
    outdir = Path(outdir)
    paths: Dict[str, str] = {}
    paths["equity"] = plot_equity_curve(
        equity, outdir / f"{prefix}_equity.png", caption=caption, theme=theme,
        title=f"{prefix.replace('_', ' ')} — equity curve",
    )
    paths["drawdown"] = plot_drawdown(
        equity, outdir / f"{prefix}_drawdown.png", caption=caption, theme=theme
    )
    paths["monthly"] = plot_monthly_returns(
        monthly, outdir / f"{prefix}_monthly.png", caption=caption, theme=theme
    )
    paths["trades"] = plot_trade_distribution(
        trades["r_multiple"].tolist() if "r_multiple" in trades else [],
        outdir / f"{prefix}_trades.png", caption=caption, theme=theme,
    )
    paths["rolling_sharpe"] = plot_rolling_sharpe(
        rolling, outdir / f"{prefix}_rolling_sharpe.png", caption=caption, theme=theme
    )
    if fold_table is not None:
        paths["folds"] = plot_walk_forward_folds(
            fold_table, outdir / f"{prefix}_folds.png", caption=caption, theme=theme
        )
    if mc_drawdowns is not None and len(mc_drawdowns):
        paths["monte_carlo"] = plot_monte_carlo_drawdowns(
            mc_drawdowns, mc_observed, outdir / f"{prefix}_monte_carlo.png",
            caption=caption, theme=theme,
        )
    return paths
