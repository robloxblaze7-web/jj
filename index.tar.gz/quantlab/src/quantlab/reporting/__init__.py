"""Reporting: charts and markdown research reports."""

from . import charts
from .charts import (
    DARK,
    LIGHT,
    Theme,
    chart_set,
    plot_drawdown,
    plot_equity_curve,
    plot_monte_carlo_drawdowns,
    plot_monthly_returns,
    plot_rolling_sharpe,
    plot_trade_distribution,
    plot_walk_forward_folds,
)
from .report import RunRecord, build_report, write_report

__all__ = [
    "charts", "Theme", "LIGHT", "DARK", "chart_set", "plot_equity_curve",
    "plot_drawdown", "plot_monthly_returns", "plot_trade_distribution",
    "plot_rolling_sharpe", "plot_monte_carlo_drawdowns", "plot_walk_forward_folds",
    "RunRecord", "build_report", "write_report",
]
