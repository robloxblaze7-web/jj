"""Backtesting: cost model, execution engine and result containers.

This package simulates trading.  It contains no broker connectivity, no API
keys, no order routing and no live-execution path, and none should be added: the
project is a research and paper-trading system by design.
"""

from .costs import CostModel, FillCosts
from .engine import BacktestEngine, run_backtest
from .types import (
    BacktestResult,
    DIRECTION_NAMES,
    ExitReason,
    FLAT,
    LONG,
    Position,
    SHORT,
    Trade,
    trades_to_frame,
)

__all__ = [
    "CostModel", "FillCosts", "BacktestEngine", "run_backtest", "BacktestResult",
    "Trade", "Position", "ExitReason", "trades_to_frame", "LONG", "SHORT", "FLAT",
    "DIRECTION_NAMES",
]
