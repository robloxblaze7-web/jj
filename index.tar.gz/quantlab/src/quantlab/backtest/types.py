"""Value objects for the backtest: positions, trades and results.

These are plain data containers.  Keeping them free of behaviour makes the
engine's state explicit and, more importantly, makes the trade blotter something
you can audit line by line — the only reliable way to find out why a backtest
produced a number you did not expect.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

LONG = 1
SHORT = -1
FLAT = 0

DIRECTION_NAMES = {LONG: "long", SHORT: "short", FLAT: "flat"}


class ExitReason:
    """Why a position was closed. Recorded on every trade."""

    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"
    SIGNAL = "signal"
    REVERSAL = "reversal"
    KILL_SWITCH = "kill_switch"
    END_OF_DATA = "end_of_data"
    MARGIN_CALL = "margin_call"


@dataclass
class Position:
    """An open position and everything needed to close and account for it."""

    symbol: str
    direction: int
    units: float
    entry_price: float
    entry_time: pd.Timestamp
    entry_bar: int
    stop_price: float
    take_profit_price: Optional[float]
    risk_per_unit: float          # |entry - stop| in price units
    entry_costs: float            # cash costs paid at entry (commission)
    entry_spread_cost: float
    entry_slippage_cost: float
    atr_at_entry: float
    financing_paid: float = 0.0
    mae_price: float = np.nan     # worst price seen while open
    mfe_price: float = np.nan     # best price seen while open
    entry_reference_price: float = np.nan   # pre-cost price the fill was struck from
    equity_at_entry: float = np.nan

    @property
    def notional(self) -> float:
        return abs(self.units) * self.entry_price

    @property
    def risk_amount(self) -> float:
        """Cash at risk between entry and stop, ignoring gaps and costs.

        This is the denominator of the R-multiple.  It is the *planned* risk:
        realised losses can exceed it when a bar gaps through the stop or when
        round-turn costs push the net loss past the stop distance, and exposing
        that difference is the point of the R-multiple distribution.
        """
        return abs(self.units) * self.risk_per_unit

    def unrealised_pnl(self, price: float) -> float:
        return self.direction * (price - self.entry_price) * abs(self.units)


@dataclass
class Trade:
    """A completed round trip."""

    symbol: str
    strategy: str
    direction: int
    units: float
    entry_time: pd.Timestamp
    entry_price: float
    exit_time: pd.Timestamp
    exit_price: float
    bars_held: int
    gross_pnl: float
    commission: float
    spread_cost: float
    slippage_cost: float
    financing_cost: float
    net_pnl: float
    risk_amount: float
    r_multiple: float
    exit_reason: str
    stop_price: float
    take_profit_price: Optional[float]
    mae: float                    # max adverse excursion, in cash
    mfe: float                    # max favourable excursion, in cash
    equity_at_entry: float
    notional: float

    @property
    def total_costs(self) -> float:
        return self.commission + self.spread_cost + self.slippage_cost + self.financing_cost

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def trades_to_frame(trades: List[Trade]) -> pd.DataFrame:
    """Trade blotter as a DataFrame, with stable columns even when empty."""
    columns = [
        "symbol", "strategy", "direction", "units", "entry_time", "entry_price",
        "exit_time", "exit_price", "bars_held", "gross_pnl", "commission",
        "spread_cost", "slippage_cost", "financing_cost", "net_pnl",
        "risk_amount", "r_multiple", "exit_reason", "stop_price",
        "take_profit_price", "mae", "mfe", "equity_at_entry", "notional",
    ]
    if not trades:
        return pd.DataFrame(columns=columns)
    df = pd.DataFrame([t.to_dict() for t in trades])[columns]
    df["entry_time"] = pd.to_datetime(df["entry_time"])
    df["exit_time"] = pd.to_datetime(df["exit_time"])
    df["total_costs"] = (
        df["commission"] + df["spread_cost"] + df["slippage_cost"] + df["financing_cost"]
    )
    df["direction_name"] = df["direction"].map(DIRECTION_NAMES)
    return df.sort_values("exit_time").reset_index(drop=True)


@dataclass
class BacktestResult:
    """Everything one backtest produced, plus the assumptions behind it."""

    symbol: str
    strategy: str
    params: Dict[str, Any]
    equity_curve: pd.DataFrame          # index=timestamp; equity, balance, ...
    trades: pd.DataFrame
    initial_balance: float
    config_snapshot: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    synthetic_data: bool = False
    bars: int = 0
    rejected_orders: int = 0
    kill_switch_triggered: bool = False

    @property
    def final_equity(self) -> float:
        if self.equity_curve.empty:
            return self.initial_balance
        return float(self.equity_curve["equity"].iloc[-1])

    @property
    def n_trades(self) -> int:
        return int(len(self.trades))

    @property
    def returns(self) -> pd.Series:
        """Bar-over-bar simple returns of equity."""
        if self.equity_curve.empty:
            return pd.Series(dtype="float64")
        return self.equity_curve["equity"].pct_change().fillna(0.0)

    def label(self) -> str:
        param_str = ",".join(f"{k}={v}" for k, v in sorted(self.params.items()))
        return f"{self.symbol}/{self.strategy}({param_str})"

    def summary_line(self) -> str:
        return (
            f"{self.label()}: {self.n_trades} trades, "
            f"final equity {self.final_equity:,.0f} "
            f"({self.final_equity / self.initial_balance - 1:+.1%})"
        )
