"""Transaction cost model: spread, slippage, commission and financing.

Costs are applied on every fill, in the adverse direction, without exception.
There is no "ignore costs" switch, because a costless backtest is not a
simplified backtest — it is a different (and non-existent) market, and rules
that only work without costs are precisely the rules that look most impressive.

Decomposition
-------------
* **Spread** — half the quoted spread is crossed on each side.  Modelled in the
  fill price and reported separately in cash.
* **Slippage** — a fixed component in basis points plus a component proportional
  to current ATR, so execution degrades in volatile conditions.  Always adverse:
  the model never grants price improvement, even though real fills sometimes
  improve, because assuming otherwise flatters every result.
* **Commission** — a rate on traded notional per side, with an optional floor.
* **Financing** — carry on the notional for each bar a position is held.  Both
  directions are charged as a cost by default.

If a strategy's edge disappears when ``spread_multiplier`` is raised to 2, the
edge was an artefact of the cost assumption, not a property of the market.  The
report runs exactly that sensitivity.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from ..config import CostConfig
from ..data.universe import InstrumentSpec

BARS_PER_YEAR_DEFAULT = 252.0


@dataclass(frozen=True)
class FillCosts:
    """Cash cost decomposition of a single fill."""

    spread_cost: float
    slippage_cost: float
    commission: float

    @property
    def total(self) -> float:
        return self.spread_cost + self.slippage_cost + self.commission


class CostModel:
    """Turns a reference price into an executable price plus cash costs."""

    def __init__(
        self,
        spec: InstrumentSpec,
        config: CostConfig | None = None,
        bars_per_year: float = BARS_PER_YEAR_DEFAULT,
    ):
        self.spec = spec
        self.config = config or CostConfig()
        self.config.validate()
        self.bars_per_year = float(bars_per_year)

    def half_spread(self) -> float:
        return self.spec.typical_spread * self.config.spread_multiplier / 2.0

    def slippage_per_unit(self, reference_price: float, atr_value: float) -> float:
        """Adverse price movement per unit, always >= 0."""
        fixed = reference_price * (self.config.slippage_bps / 10_000.0)
        vol_part = 0.0
        if np.isfinite(atr_value) and atr_value > 0:
            vol_part = atr_value * self.config.slippage_atr_fraction
        return float(max(fixed + vol_part, 0.0))

    def fill_price(
        self, side: int, reference_price: float, atr_value: float, *, is_entry: bool
    ) -> Tuple[float, float, float]:
        """Executable price for a market order.

        ``side`` is +1 to buy, -1 to sell.  Buying fills above the reference,
        selling fills below it — always.

        Returns ``(fill_price, spread_cost_per_unit, slippage_cost_per_unit)``.
        """
        if side not in (1, -1):
            raise ValueError(f"side must be +1 or -1, got {side}")

        apply_spread = (
            self.config.apply_spread_on_entry if is_entry else self.config.apply_spread_on_exit
        )
        spread_component = self.half_spread() if apply_spread else 0.0
        slip_component = self.slippage_per_unit(reference_price, atr_value)

        fill = reference_price + side * (spread_component + slip_component)
        fill = max(fill, self.spec.tick_size)   # a fill price can never be <= 0
        return float(fill), float(spread_component), float(slip_component)

    def commission(self, units: float, price: float) -> float:
        notional = abs(units) * price * self.spec.point_value
        raw = notional * self.spec.commission_rate * self.config.commission_multiplier
        return float(max(raw, self.spec.min_commission if abs(units) > 0 else 0.0))

    def fill_costs(
        self, units: float, fill_price: float, spread_per_unit: float, slip_per_unit: float
    ) -> FillCosts:
        u = abs(units) * self.spec.point_value
        return FillCosts(
            spread_cost=float(spread_per_unit * u),
            slippage_cost=float(slip_per_unit * u),
            commission=self.commission(units, fill_price),
        )

    def financing_cost(
        self, units: float, price: float, direction: int, bars: float = 1.0
    ) -> float:
        """Carry charged for holding ``units`` for ``bars`` bars."""
        if units == 0 or direction == 0:
            return 0.0
        rate = (
            self.spec.financing_rate_annual_long
            if direction > 0
            else self.spec.financing_rate_annual_short
        )
        notional = abs(units) * price * self.spec.point_value
        return float(notional * rate * (bars / self.bars_per_year))

    def round_turn_cost_estimate(self, units: float, price: float, atr_value: float) -> float:
        """Approximate all-in cost of a round trip, for sanity checks.

        Used in the report to compare typical trade P&L against the cost of
        simply doing the trade.  When the average winner is smaller than this
        number, the strategy is a cost-transfer machine regardless of its
        Sharpe ratio.
        """
        slip = self.slippage_per_unit(price, atr_value)
        spread = self.half_spread()
        per_unit = 2.0 * (spread + slip)
        return float(
            per_unit * abs(units) * self.spec.point_value + 2.0 * self.commission(units, price)
        )

    def describe(self) -> dict:
        return {
            "symbol": self.spec.symbol,
            "typical_spread": self.spec.typical_spread,
            "spread_multiplier": self.config.spread_multiplier,
            "slippage_bps": self.config.slippage_bps,
            "slippage_atr_fraction": self.config.slippage_atr_fraction,
            "commission_rate": self.spec.commission_rate * self.config.commission_multiplier,
            "financing_long": self.spec.financing_rate_annual_long,
            "financing_short": self.spec.financing_rate_annual_short,
            "margin_rate": self.spec.margin_rate,
        }
