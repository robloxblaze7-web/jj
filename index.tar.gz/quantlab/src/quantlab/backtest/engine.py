"""The backtest engine: a bar-by-bar simulation with explicit execution rules.

EXECUTION MODEL
---------------
The rules below are the whole point of the module.  Each one is chosen so that,
where reality is ambiguous, the simulation resolves against the strategy.

1. **Next-bar execution.**  A signal derived from bar *t* is executed at the
   *open of bar t+1*.  ``execution_lag_bars`` cannot be set below 1
   (:class:`~quantlab.config.BacktestConfig` rejects it).  Filling at the close
   of the bar that produced the signal is the single most common way a backtest
   invents returns.

2. **Stops and targets resolve pessimistically.**  If a bar's range touches both
   the stop and the take-profit, the engine records the *stop*.  Daily bars
   contain no information about which came first, and assuming the favourable
   order is how a mediocre system is made to look excellent.  The number of such
   ambiguous bars is reported, so you can see how much of the result rests on
   the assumption.

3. **Gaps fill at the open, not at the level.**  If a bar opens beyond the stop,
   the fill is the open — worse than the stop.  Realised losses can therefore
   exceed the planned 1R, which is exactly what the R-multiple distribution is
   there to show.

4. **Exits before entries within a bar.**  A signal-driven exit happens at the
   open, so it precedes any intrabar stop; a position opened at the open of a
   bar is still exposed to that same bar's range.

5. **Costs on every fill.**  Spread and slippage move the fill price adversely;
   commission and financing are charged in cash.  No fill ever improves.

6. **Margin is real.**  Positions are funded; equity below maintenance margin
   forces liquidation at the close.

7. **Sizing uses current equity**, so risk compounds down after losses and up
   after gains, rather than being computed once from the starting balance.

WHAT THIS ENGINE IS NOT
-----------------------
It is not connected to a broker and has no order-routing code.  It simulates a
single instrument per run; portfolio construction across instruments is done at
the analytics layer by combining independent runs, which deliberately ignores
cross-instrument correlation of drawdowns.  Do not read a portfolio aggregate as
a portfolio backtest.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..config import BacktestConfig
from ..data.universe import DEFAULT_UNIVERSE, InstrumentSpec
from ..indicators import atr as atr_indicator
from ..risk.limits import RiskLimits
from ..risk.sizing import size_position, stop_and_target
from .costs import CostModel
from .types import BacktestResult, ExitReason, Position, Trade, trades_to_frame

MAINTENANCE_MARGIN_FRACTION = 0.5  # liquidate below 50% of initial margin


class BacktestEngine:
    """Simulates one strategy on one instrument."""

    def __init__(
        self,
        config: Optional[BacktestConfig] = None,
        spec: Optional[InstrumentSpec] = None,
        symbol: str = "EURUSD",
    ):
        self.config = config or BacktestConfig()
        self.config.validate()
        self.spec = spec or DEFAULT_UNIVERSE.get(symbol)
        self.costs = CostModel(self.spec, self.config.costs, self.config.bars_per_year)
        self._current_strategy = ""

    # ------------------------------------------------------------------ #
    def run(
        self,
        df: pd.DataFrame,
        signals: pd.Series,
        *,
        strategy_name: str = "unknown",
        params: Optional[Dict[str, Any]] = None,
        trade_from: Optional[pd.Timestamp] = None,
    ) -> BacktestResult:
        """Run the simulation.

        Parameters
        ----------
        df:
            Validated OHLCV bars.
        signals:
            Desired position (-1/0/+1) per bar, aligned to ``df.index``.  These
            must already be causal; the engine adds the execution lag on top.
        trade_from:
            First timestamp at which a position may be opened.  Bars before it
            are used for indicator warm-up only.  This is what makes
            walk-forward test windows genuinely out-of-sample while still having
            defined indicators on their first bar.
        """
        if not signals.index.equals(df.index):
            raise ValueError("signals must be aligned to the price index")
        self._current_strategy = strategy_name

        cfg = self.config
        spec = self.spec
        n = len(df)

        o = df["open"].to_numpy(dtype=float)
        h = df["high"].to_numpy(dtype=float)
        low_arr = df["low"].to_numpy(dtype=float)
        c = df["close"].to_numpy(dtype=float)
        index = df.index

        atr_arr = atr_indicator(df, cfg.atr_period).to_numpy(dtype=float)

        raw_sig = signals.to_numpy(dtype=float)
        lag = int(cfg.execution_lag_bars)
        # desired[i] is the position wanted at bar i, decided `lag` bars ago.
        desired = np.zeros(n, dtype=float)
        if lag < n:
            desired[lag:] = raw_sig[: n - lag]

        # First bar at which a position may be opened.
        start_idx = max(int(cfg.warmup_bars), lag, int(cfg.atr_period) + 1)
        if trade_from is not None:
            start_idx = max(start_idx, int(index.searchsorted(pd.Timestamp(trade_from), "left")))
        start_idx = min(start_idx, n)

        balance = float(cfg.initial_balance)
        position: Optional[Position] = None
        trades: List[Trade] = []
        limits = RiskLimits(cfg.risk, balance)

        rejected = ambiguous_bars = gap_through_stop = margin_calls = 0
        rows: List[tuple] = []
        rec_index: List[pd.Timestamp] = []

        for i in range(start_idx, n):
            price_open, price_high, price_low, price_close = o[i], h[i], low_arr[i], c[i]
            ts = index[i]

            if not np.isfinite([price_open, price_high, price_low, price_close]).all():
                # A bar with no price is a bar on which nothing can be traded or
                # marked.  Carry state forward untouched rather than inventing a
                # price by forward filling.
                mark = price_close if np.isfinite(price_close) else np.nan
                equity = balance + (
                    position.unrealised_pnl(mark) if position and np.isfinite(mark) else 0.0
                )
                exposure = (
                    abs(position.units) * mark * spec.point_value
                    if position and np.isfinite(mark)
                    else 0.0
                )
                rows.append(
                    (
                        equity, balance,
                        position.direction * position.units if position else 0.0,
                        exposure, mark,
                    )
                )
                rec_index.append(ts)
                continue

            # --- 1. financing on the carried position ---------------------- #
            if position is not None:
                fin = self.costs.financing_cost(position.units, c[i - 1], position.direction, 1.0)
                balance -= fin
                position.financing_paid += fin

            atr_prev = atr_arr[i - 1] if i > 0 else np.nan
            want = desired[i]

            # --- 2. exits driven by the signal or the kill switch ---------- #
            if position is not None:
                if limits.kill_switch_active:
                    tr, cash = self._close(
                        position, price_open, atr_prev, ts, i, ExitReason.KILL_SWITCH, balance
                    )
                    trades.append(tr)
                    balance += cash
                    position = None
                elif want != position.direction:
                    reason = ExitReason.SIGNAL if want == 0 else ExitReason.REVERSAL
                    tr, cash = self._close(position, price_open, atr_prev, ts, i, reason, balance)
                    trades.append(tr)
                    balance += cash
                    position = None

            # --- 3. entries ------------------------------------------------ #
            if position is None and want != 0:
                allowed, _reason = limits.can_open(ts)
                if not allowed:
                    rejected += 1
                elif not np.isfinite(atr_prev) or atr_prev <= 0:
                    rejected += 1
                else:
                    side = int(np.sign(want))
                    fill, spread_pu, slip_pu = self.costs.fill_price(
                        side, price_open, atr_prev, is_entry=True
                    )
                    stop, target = stop_and_target(
                        direction=side, entry_price=fill, atr_value=atr_prev,
                        cfg=cfg.risk, spec=spec,
                    )
                    equity_now = balance
                    decision = size_position(
                        equity=equity_now,
                        price=fill,
                        stop_distance=abs(fill - stop),
                        atr_value=atr_prev,
                        spec=spec,
                        cfg=cfg.risk,
                        existing_notional=0.0,
                        free_equity=equity_now,
                        bars_per_year=cfg.bars_per_year,
                    )
                    if not decision.is_tradeable:
                        rejected += 1
                    else:
                        comm = self.costs.commission(decision.units, fill)
                        balance -= comm
                        position = Position(
                            symbol=spec.symbol,
                            direction=side,
                            units=decision.units,
                            entry_price=fill,
                            entry_time=ts,
                            entry_bar=i,
                            stop_price=stop,
                            take_profit_price=target,
                            risk_per_unit=abs(fill - stop),
                            entry_costs=comm,
                            entry_spread_cost=spread_pu * decision.units * spec.point_value,
                            entry_slippage_cost=slip_pu * decision.units * spec.point_value,
                            atr_at_entry=float(atr_prev),
                            mae_price=price_open,
                            mfe_price=price_open,
                            entry_reference_price=price_open,
                            equity_at_entry=equity_now,
                        )

            # --- 4. intrabar stop / take profit ---------------------------- #
            if position is not None:
                exit_ref, reason, flags = self._intrabar_exit(
                    position, price_open, price_high, price_low
                )
                ambiguous_bars += flags["ambiguous"]
                gap_through_stop += flags["gapped"]
                if exit_ref is not None:
                    tr, cash = self._close(position, exit_ref, atr_prev, ts, i, reason, balance)
                    trades.append(tr)
                    balance += cash
                    position = None

            # --- 5. excursions and mark to market -------------------------- #
            if position is not None:
                if position.direction > 0:
                    position.mae_price = np.nanmin([position.mae_price, price_low])
                    position.mfe_price = np.nanmax([position.mfe_price, price_high])
                else:
                    position.mae_price = np.nanmax([position.mae_price, price_high])
                    position.mfe_price = np.nanmin([position.mfe_price, price_low])

            equity = balance + (position.unrealised_pnl(price_close) if position else 0.0)

            # --- 6. margin call -------------------------------------------- #
            if position is not None:
                required = (
                    abs(position.units) * price_close * spec.point_value * spec.margin_rate
                )
                if equity <= required * MAINTENANCE_MARGIN_FRACTION:
                    tr, cash = self._close(
                        position, price_close, atr_prev, ts, i, ExitReason.MARGIN_CALL, balance
                    )
                    trades.append(tr)
                    balance += cash
                    position = None
                    margin_calls += 1
                    equity = balance

            limits.update(ts, equity)

            exposure = abs(position.units) * price_close * spec.point_value if position else 0.0
            rows.append(
                (
                    equity, balance,
                    position.direction * position.units if position else 0.0,
                    exposure, price_close,
                )
            )
            rec_index.append(ts)

        # --- close anything still open at the end --------------------------- #
        if position is not None and n > 0:
            i = n - 1
            tr, cash = self._close(
                position, c[i], atr_arr[i - 1] if i > 0 else np.nan, index[i], i,
                ExitReason.END_OF_DATA, balance,
            )
            trades.append(tr)
            balance += cash
            if rows:
                rows[-1] = (balance, balance, 0.0, 0.0, c[i])
            position = None

        equity_curve = pd.DataFrame(
            rows,
            columns=["equity", "balance", "position_units", "exposure", "price"],
            index=pd.DatetimeIndex(rec_index, name="timestamp"),
        )
        if not equity_curve.empty:
            equity_curve["drawdown"] = (
                equity_curve["equity"] / equity_curve["equity"].cummax() - 1.0
            )
            equity_curve["returns"] = equity_curve["equity"].pct_change().fillna(0.0)

        warnings = self._build_warnings(
            trades, ambiguous_bars, gap_through_stop, rejected, margin_calls, limits
        )

        return BacktestResult(
            symbol=spec.symbol,
            strategy=strategy_name,
            params=dict(params or {}),
            equity_curve=equity_curve,
            trades=trades_to_frame(trades),
            initial_balance=float(cfg.initial_balance),
            config_snapshot={
                "backtest": cfg.to_dict(),
                "costs": self.costs.describe(),
                "execution": {
                    "execution_lag_bars": lag,
                    "ambiguous_stop_target_bars": int(ambiguous_bars),
                    "gap_through_stop_fills": int(gap_through_stop),
                    "margin_calls": int(margin_calls),
                    "trade_from": str(index[start_idx]) if start_idx < n else None,
                },
            },
            warnings=warnings,
            synthetic_data=bool(df.attrs.get("synthetic", False)),
            bars=int(max(n - start_idx, 0)),
            rejected_orders=int(rejected),
            kill_switch_triggered=limits.kill_switch_active,
        )

    # ------------------------------------------------------------------ #
    def _intrabar_exit(
        self, position: Position, o: float, h: float, low: float
    ) -> Tuple[Optional[float], str, Dict[str, int]]:
        """Resolve stop/take-profit against one bar's range.

        Returns the *reference* exit price (before costs), the reason, and flags
        counting ambiguous and gapped bars for the report.
        """
        flags = {"ambiguous": 0, "gapped": 0}
        stop, target = position.stop_price, position.take_profit_price

        if position.direction > 0:
            stop_hit = low <= stop
            tp_hit = target is not None and h >= target
        else:
            stop_hit = h >= stop
            tp_hit = target is not None and low <= target

        if stop_hit and tp_hit:
            flags["ambiguous"] = 1

        if stop_hit:
            # Gap: the bar opened past the stop, so the fill is the open.
            if position.direction > 0 and o <= stop:
                flags["gapped"] = 1
                return float(o), ExitReason.STOP_LOSS, flags
            if position.direction < 0 and o >= stop:
                flags["gapped"] = 1
                return float(o), ExitReason.STOP_LOSS, flags
            return float(stop), ExitReason.STOP_LOSS, flags

        if tp_hit and target is not None:
            if position.direction > 0 and o >= target:
                return float(o), ExitReason.TAKE_PROFIT, flags
            if position.direction < 0 and o <= target:
                return float(o), ExitReason.TAKE_PROFIT, flags
            return float(target), ExitReason.TAKE_PROFIT, flags

        return None, "", flags

    def _close(
        self,
        position: Position,
        reference_price: float,
        atr_value: float,
        ts: pd.Timestamp,
        bar: int,
        reason: str,
        balance: float,
    ) -> Tuple[Trade, float]:
        """Build the :class:`Trade` for closing ``position``, and the cash it releases.

        Returns ``(trade, close_cash)`` where ``close_cash`` is what the closing
        fill actually adds to the balance: the price move between the entry and
        exit fills, less the exit commission.  Entry commission was charged at
        entry and financing was charged bar by bar, so applying only
        ``close_cash`` here charges each component exactly once.  The identity
        that must hold, and that the test suite asserts, is::

            sum(trade.net_pnl) == final_equity - initial_balance
        """
        spec = self.spec
        side = -position.direction  # closing trades against the position
        fill, spread_pu, slip_pu = self.costs.fill_price(
            side, reference_price, atr_value, is_entry=False
        )
        units = position.units
        pv = spec.point_value

        exit_commission = self.costs.commission(units, fill)
        exit_spread = spread_pu * units * pv
        exit_slippage = slip_pu * units * pv

        entry_ref = (
            position.entry_reference_price
            if np.isfinite(position.entry_reference_price)
            else position.entry_price
        )
        gross = position.direction * (reference_price - entry_ref) * units * pv
        spread_cost = position.entry_spread_cost + exit_spread
        slippage_cost = position.entry_slippage_cost + exit_slippage
        commission = position.entry_costs + exit_commission
        financing = position.financing_paid
        net = gross - spread_cost - slippage_cost - commission - financing

        risk_amount = position.risk_amount
        r_multiple = net / risk_amount if risk_amount > 0 else np.nan

        mae = position.direction * (position.mae_price - position.entry_price) * units * pv
        mfe = position.direction * (position.mfe_price - position.entry_price) * units * pv

        close_cash = position.direction * (fill - position.entry_price) * units * pv - exit_commission

        trade = Trade(
            symbol=position.symbol,
            strategy=self._current_strategy,
            direction=position.direction,
            units=float(units),
            entry_time=position.entry_time,
            entry_price=float(position.entry_price),
            exit_time=ts,
            exit_price=float(fill),
            bars_held=int(bar - position.entry_bar),
            gross_pnl=float(gross),
            commission=float(commission),
            spread_cost=float(spread_cost),
            slippage_cost=float(slippage_cost),
            financing_cost=float(financing),
            net_pnl=float(net),
            risk_amount=float(risk_amount),
            r_multiple=float(r_multiple),
            exit_reason=reason,
            stop_price=float(position.stop_price),
            take_profit_price=(
                float(position.take_profit_price)
                if position.take_profit_price is not None
                else None
            ),
            mae=float(min(mae, 0.0)),
            mfe=float(max(mfe, 0.0)),
            equity_at_entry=float(
                position.equity_at_entry if np.isfinite(position.equity_at_entry) else balance
            ),
            notional=float(abs(units) * position.entry_price * pv),
        )
        return trade, float(close_cash)

    # ------------------------------------------------------------------ #
    def _build_warnings(
        self,
        trades: List[Trade],
        ambiguous: int,
        gapped: int,
        rejected: int,
        margin_calls: int,
        limits: RiskLimits,
    ) -> List[str]:
        w: List[str] = []
        n = len(trades)
        if n == 0:
            w.append("No trades were taken; performance statistics are undefined, not zero.")
        elif n < 30:
            w.append(
                f"Only {n} trades: sampling error dominates every statistic below. A Sharpe "
                f"ratio computed from {n} trades has a standard error of roughly "
                f"{1.0 / max(np.sqrt(n), 1e-9):.2f}."
            )
        if ambiguous:
            w.append(
                f"{ambiguous} bar(s) touched both the stop and the take-profit "
                f"({ambiguous / max(n, 1):.2f} per trade). Each was resolved as a stop. With "
                f"intrabar data some would have been targets, so the true result lies between "
                f"this run and an optimistic one."
            )
        if gapped:
            w.append(
                f"{gapped} stop(s) filled on a gap beyond the stop level, so realised loss "
                f"exceeded the planned 1R on those trades."
            )
        if rejected:
            w.append(
                f"{rejected} entry signal(s) were not taken (risk limits, minimum size or "
                f"undefined ATR). The traded strategy is therefore not identical to the "
                f"signal series."
            )
        if margin_calls:
            w.append(f"{margin_calls} forced liquidation(s) on maintenance margin.")
        for event in limits.events:
            w.append(f"Risk limit: {event}")
        return w


def run_backtest(
    df: pd.DataFrame,
    strategy,
    *,
    config: Optional[BacktestConfig] = None,
    spec: Optional[InstrumentSpec] = None,
    symbol: Optional[str] = None,
    trade_from: Optional[pd.Timestamp] = None,
) -> BacktestResult:
    """Convenience wrapper: generate signals from ``strategy`` and simulate."""
    sym = symbol or df.attrs.get("symbol") or (spec.symbol if spec else "EURUSD")
    engine = BacktestEngine(config=config, spec=spec, symbol=sym)
    signals = strategy.generate_signals(df)
    result = engine.run(
        df, signals, strategy_name=strategy.name, params=dict(strategy.params),
        trade_from=trade_from,
    )
    return result
