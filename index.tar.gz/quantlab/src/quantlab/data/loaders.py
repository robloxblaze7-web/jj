"""Loading price data from CSV or the synthetic generator, with a local cache."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, Optional

import pandas as pd

from .schema import coerce_ohlcv, describe_quality, validate_ohlcv
from .synthetic import generate_ohlcv

DEFAULT_DATA_DIR = Path("data")


def load_csv(
    path: str | Path, symbol: str = "?", *, max_gap_days: float | None = None
) -> pd.DataFrame:
    """Load one CSV of OHLCV bars.

    Vendor column spellings are normalised; nothing is filled or repaired.  A
    file that fails validation raises, because the correct response to bad
    market data is to fix the file, not to let the engine trade through it.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"no data file at {path}")
    raw = pd.read_csv(path)
    df = coerce_ohlcv(raw)
    validate_ohlcv(df, symbol, max_gap_days=max_gap_days)
    df.attrs["synthetic"] = False
    df.attrs["symbol"] = symbol.upper()
    df.attrs["provenance"] = f"CSV: {path.resolve()}"
    return df


def load_symbol(
    symbol: str,
    *,
    source: str = "synthetic",
    start: str = "2010-01-01",
    end: str = "2025-12-31",
    seed: int = 20260907,
    data_dir: str | Path = DEFAULT_DATA_DIR,
    use_cache: bool = True,
) -> pd.DataFrame:
    """Load one symbol from ``source`` (``synthetic`` or ``csv``).

    CSV files are looked up at ``<data_dir>/raw/<SYMBOL>.csv``.  Synthetic series
    are cached under ``<data_dir>/cache/``; the generator is deterministic
    anyway, so the cache is a speed-up rather than a correctness requirement.
    """
    symbol = symbol.upper()
    data_dir = Path(data_dir)

    if source == "csv":
        df = load_csv(data_dir / "raw" / f"{symbol}.csv", symbol)
        return df.loc[str(start) : str(end)]

    if source != "synthetic":
        raise ValueError(f"unknown data source {source!r} (use 'synthetic' or 'csv')")

    cache_path = data_dir / "cache" / f"{symbol}_{seed}_{start}_{end}.csv"
    if use_cache and cache_path.exists():
        raw = pd.read_csv(cache_path)
        df = coerce_ohlcv(raw)
        validate_ohlcv(df, symbol)
        df.attrs["synthetic"] = True
        df.attrs["symbol"] = symbol
        df.attrs["seed"] = seed
        df.attrs["provenance"] = f"SYNTHETIC (cached) seed={seed} -> {cache_path}"
        return df

    df = generate_ohlcv(symbol, start=start, end=end, seed=seed)
    if use_cache:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(cache_path, index_label="timestamp")
    return df


def load_dataset(
    symbols: Iterable[str],
    *,
    source: str = "synthetic",
    start: str = "2010-01-01",
    end: str = "2025-12-31",
    seed: int = 20260907,
    data_dir: str | Path = DEFAULT_DATA_DIR,
    use_cache: bool = True,
) -> Dict[str, pd.DataFrame]:
    return {
        s.upper(): load_symbol(
            s, source=source, start=start, end=end, seed=seed,
            data_dir=data_dir, use_cache=use_cache,
        )
        for s in symbols
    }


def quality_report(dataset: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """One row per symbol summarising data quality, for the report's appendix."""
    rows = []
    for symbol, df in dataset.items():
        row = {"symbol": symbol, "synthetic": bool(df.attrs.get("synthetic", False))}
        row.update(describe_quality(df))
        rows.append(row)
    return pd.DataFrame(rows).set_index("symbol").sort_index()


def align_dataset(dataset: Dict[str, pd.DataFrame], how: str = "outer") -> Dict[str, pd.DataFrame]:
    """Reindex all symbols onto a common calendar.

    ``how='inner'`` keeps only timestamps present for every symbol, which avoids
    implicitly assuming a market was open when it was not.  Missing bars are left
    as NaN rather than forward-filled, and the engine skips NaN bars;
    forward-filling would let a position be marked, stopped out or sized off a
    price that never traded.
    """
    if not dataset:
        return {}
    index: Optional[pd.DatetimeIndex] = None
    for df in dataset.values():
        index = (
            df.index
            if index is None
            else (index.union(df.index) if how == "outer" else index.intersection(df.index))
        )
    assert index is not None
    return {s: df.reindex(index) for s, df in dataset.items()}
