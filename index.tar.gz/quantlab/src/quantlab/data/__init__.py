"""Data layer: schema, instrument specs, synthetic generation, loading, splitting."""

from .loaders import align_dataset, load_csv, load_dataset, load_symbol, quality_report
from .schema import (
    DataValidationError,
    OHLCV_COLUMNS,
    coerce_ohlcv,
    describe_quality,
    validate_ohlcv,
)
from .splits import (
    Split,
    WalkForwardWindow,
    assert_no_overlap,
    three_way_split,
    walk_forward_windows,
)
from .synthetic import generate_ohlcv, generate_universe
from .universe import DEFAULT_INSTRUMENTS, DEFAULT_UNIVERSE, InstrumentSpec, Universe

__all__ = [
    "DataValidationError", "OHLCV_COLUMNS", "coerce_ohlcv", "describe_quality",
    "validate_ohlcv", "InstrumentSpec", "Universe", "DEFAULT_UNIVERSE",
    "DEFAULT_INSTRUMENTS", "generate_ohlcv", "generate_universe", "load_csv",
    "load_symbol", "load_dataset", "quality_report", "align_dataset", "Split",
    "three_way_split", "WalkForwardWindow", "walk_forward_windows", "assert_no_overlap",
]
