"""Canonical OHLCV schema and validation.

Every DataFrame that enters the engine passes through :func:`validate_ohlcv`.
Bad data is the cheapest way to produce an impressive-looking backtest, so the
validator is strict by default and raises rather than repairing: a silent fix
(forward-filling a gap, clipping a bad high) changes the results in ways that
never appear in the report.
"""

from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np
import pandas as pd

OHLCV_COLUMNS: Sequence[str] = ("open", "high", "low", "close", "volume")
INDEX_NAME = "timestamp"

_ALIASES = {
    "date": "timestamp",
    "datetime": "timestamp",
    "time": "timestamp",
    "o": "open",
    "h": "high",
    "l": "low",
    "c": "close",
    "v": "volume",
    "adj close": "close",
    "adj_close": "close",
    "vol": "volume",
}


class DataValidationError(ValueError):
    """Raised when a price series violates the OHLCV contract."""


def coerce_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """Normalise column names, index and dtypes without changing any values.

    Accepts the common vendor spellings (``Date``/``Adj Close``/``Vol``) and
    returns a frame with a sorted, tz-naive ``timestamp`` index and float
    columns.  It does *not* fill, clip or interpolate anything.
    """
    out = df.copy()
    out.columns = [
        _ALIASES.get(str(c).strip().lower(), str(c).strip().lower()) for c in out.columns
    ]

    if INDEX_NAME in out.columns:
        out = out.set_index(INDEX_NAME)
    elif out.index.name and str(out.index.name).lower() in _ALIASES:
        out.index.name = INDEX_NAME

    if not isinstance(out.index, pd.DatetimeIndex):
        out.index = pd.to_datetime(out.index, utc=False, errors="raise")
    if getattr(out.index, "tz", None) is not None:
        out.index = out.index.tz_convert("UTC").tz_localize(None)
    out.index.name = INDEX_NAME

    if "volume" not in out.columns:
        out["volume"] = np.nan

    missing = [c for c in OHLCV_COLUMNS if c not in out.columns]
    if missing:
        raise DataValidationError(f"missing required column(s): {missing}")

    out = out.loc[:, list(OHLCV_COLUMNS)].astype("float64")
    return out.sort_index()


def validate_ohlcv(
    df: pd.DataFrame,
    symbol: str = "?",
    *,
    allow_missing_volume: bool = True,
    max_gap_days: float | None = None,
) -> pd.DataFrame:
    """Validate a coerced OHLCV frame, raising :class:`DataValidationError`.

    Checks performed
    ----------------
    * required columns present, float dtype, no infinities
    * monotonically increasing, unique, tz-naive DatetimeIndex
    * no NaN in OHLC (volume may be NaN when ``allow_missing_volume``)
    * strictly positive prices
    * ``high >= max(open, close)``, ``low <= min(open, close)``, ``high >= low``
      — violated bars make stop and target fills meaningless
    * non-negative volume
    * optionally, no calendar gap larger than ``max_gap_days``
    """
    if not isinstance(df, pd.DataFrame):
        raise DataValidationError(f"[{symbol}] expected a DataFrame, got {type(df)!r}")
    if df.empty:
        raise DataValidationError(f"[{symbol}] price frame is empty")

    missing = [c for c in OHLCV_COLUMNS if c not in df.columns]
    if missing:
        raise DataValidationError(f"[{symbol}] missing required column(s): {missing}")

    if not isinstance(df.index, pd.DatetimeIndex):
        raise DataValidationError(f"[{symbol}] index must be a DatetimeIndex")
    if getattr(df.index, "tz", None) is not None:
        raise DataValidationError(f"[{symbol}] index must be tz-naive (store UTC)")
    if not df.index.is_monotonic_increasing:
        raise DataValidationError(f"[{symbol}] index must be sorted ascending")
    if df.index.has_duplicates:
        dupes = df.index[df.index.duplicated()][:5].tolist()
        raise DataValidationError(f"[{symbol}] duplicate timestamps, e.g. {dupes}")

    ohlc = df[["open", "high", "low", "close"]]
    if ohlc.isna().to_numpy().any():
        first_bad = df.index[ohlc.isna().any(axis=1)][0]
        raise DataValidationError(f"[{symbol}] NaN in OHLC, first at {first_bad}")
    if np.isinf(ohlc.to_numpy()).any():
        raise DataValidationError(f"[{symbol}] non-finite value in OHLC")
    if (ohlc.to_numpy() <= 0).any():
        first_bad = df.index[(ohlc <= 0).any(axis=1)][0]
        raise DataValidationError(f"[{symbol}] non-positive price, first at {first_bad}")

    hi_ok = df["high"] >= df[["open", "close"]].max(axis=1) - 1e-12
    lo_ok = df["low"] <= df[["open", "close"]].min(axis=1) + 1e-12
    rng_ok = df["high"] >= df["low"] - 1e-12
    bad = ~(hi_ok & lo_ok & rng_ok)
    if bad.any():
        first_bad = df.index[bad][0]
        raise DataValidationError(
            f"[{symbol}] inconsistent bar (high/low do not bracket open/close), "
            f"first at {first_bad}"
        )

    vol = df["volume"]
    if not allow_missing_volume and vol.isna().any():
        raise DataValidationError(f"[{symbol}] NaN volume not permitted")
    if (vol.dropna() < 0).any():
        raise DataValidationError(f"[{symbol}] negative volume")

    if max_gap_days is not None and len(df) > 1:
        gaps = df.index.to_series().diff().dropna().dt.total_seconds() / 86400.0
        if (gaps > max_gap_days).any():
            worst = gaps.max()
            at = gaps.idxmax()
            raise DataValidationError(
                f"[{symbol}] calendar gap of {worst:.1f} days at {at} exceeds "
                f"max_gap_days={max_gap_days}"
            )
    return df


def describe_quality(df: pd.DataFrame) -> dict:
    """Summary statistics used in the data-quality section of the report."""
    rets = np.log(df["close"]).diff().dropna()
    gaps = df.index.to_series().diff().dropna().dt.total_seconds() / 86400.0
    return {
        "bars": int(len(df)),
        "start": str(df.index[0].date()),
        "end": str(df.index[-1].date()),
        "max_gap_days": float(gaps.max()) if len(gaps) else 0.0,
        "zero_range_bars": int(((df["high"] - df["low"]) <= 0).sum()),
        "duplicate_closes": int((df["close"].diff() == 0).sum()),
        "ann_vol": float(rets.std(ddof=1) * np.sqrt(252.0)) if len(rets) > 2 else float("nan"),
        "worst_bar_return": float(rets.min()) if len(rets) else float("nan"),
        "best_bar_return": float(rets.max()) if len(rets) else float("nan"),
    }


def assert_columns(df: pd.DataFrame, required: Iterable[str]) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise DataValidationError(f"missing column(s): {missing}")
