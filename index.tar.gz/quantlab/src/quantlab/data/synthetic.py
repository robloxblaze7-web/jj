"""Deterministic synthetic OHLCV generator.

WHY SYNTHETIC DATA EXISTS HERE
------------------------------
It exists so the pipeline can be *tested* — engine, metrics, walk-forward,
Monte Carlo, charts — anywhere, with no vendor account and no network.  It does
**not** exist to evaluate strategies.

A performance number computed on this data says nothing about any real market.
The generator produces trends and mean-reverting regimes because it was written
to produce them, so a trend strategy "working" here is a statement about the
generator's parameters, not about the world.  Read every result on synthetic
data as: *the machinery ran and produced internally consistent numbers*.

The process is a regime-switching stochastic-volatility jump diffusion:

* a 3-state Markov chain (trend / range / stress) with persistent states,
* AR(1) log-volatility around a regime-dependent level,
* a drift redrawn on entry to the trend state, so trends have direction and
  duration rather than being an artefact of a constant mu,
* Poisson jumps with fat-tailed but bounded sizes,
* intrabar highs and lows from a Brownian bridge between open and close, so
  ranges are consistent with the realised close-to-close move rather than being
  invented independently,
* volume correlated with absolute return.

Everything is a pure function of ``(symbol, seed, start, end)``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .schema import coerce_ohlcv, validate_ohlcv

TREND, RANGE, STRESS = 0, 1, 2
REGIME_NAMES = {TREND: "trend", RANGE: "range", STRESS: "stress"}

# Rows are "from" states, columns "to".  Diagonals are high so regimes persist
# for weeks-to-months rather than flickering daily.
TRANSITION_MATRIX = np.array(
    [
        [0.975, 0.020, 0.005],   # from trend
        [0.018, 0.975, 0.007],   # from range
        [0.060, 0.070, 0.870],   # from stress (shorter lived)
    ]
)


@dataclass
class SyntheticParams:
    """Per-instrument generator parameters.

    ``annual_drift`` is the unconditional drift; the trend regime adds a
    persistent directional component on top of it, and the range regime adds
    mean reversion toward a slow-moving anchor.
    """

    start_price: float
    annual_drift: float = 0.0
    base_annual_vol: float = 0.10
    vol_regime_multiplier: Dict[int, float] = field(
        default_factory=lambda: {TREND: 0.95, RANGE: 0.80, STRESS: 2.30}
    )
    vol_ar_phi: float = 0.94
    vol_ar_sigma: float = 0.14
    trend_annual_drift: float = 0.16
    reversion_strength: float = 0.030
    reversion_halflife_days: float = 45.0
    jump_prob_per_day: float = 0.004
    jump_scale_in_sigmas: float = 3.2
    overnight_gap_fraction: float = 0.18
    base_volume: float = 100_000.0
    volume_return_beta: float = 0.9
    price_floor: float = 1e-6


# Parameters chosen so each series has a plausible *shape* (level, volatility,
# trend persistence) for its asset class.  They are not fitted to history.
DEFAULT_PARAMS: Dict[str, SyntheticParams] = {
    "EURUSD": SyntheticParams(
        start_price=1.1400, annual_drift=-0.005, base_annual_vol=0.075,
        trend_annual_drift=0.085, reversion_strength=0.035, base_volume=180_000.0,
    ),
    "GBPUSD": SyntheticParams(
        start_price=1.5600, annual_drift=-0.012, base_annual_vol=0.090,
        trend_annual_drift=0.105, reversion_strength=0.030,
        jump_prob_per_day=0.006, base_volume=120_000.0,
    ),
    "XAUUSD": SyntheticParams(
        start_price=1_120.0, annual_drift=0.045, base_annual_vol=0.155,
        trend_annual_drift=0.190, reversion_strength=0.018,
        jump_prob_per_day=0.007, base_volume=60_000.0,
    ),
    "SPX500": SyntheticParams(
        start_price=1_130.0, annual_drift=0.075, base_annual_vol=0.160,
        trend_annual_drift=0.150, reversion_strength=0.020,
        jump_prob_per_day=0.008, jump_scale_in_sigmas=3.8,
        vol_regime_multiplier={TREND: 0.85, RANGE: 0.75, STRESS: 2.80},
        base_volume=2_000_000.0,
    ),
}

TRADING_DAYS_PER_YEAR = 252.0


def _symbol_seed(symbol: str, seed: int) -> int:
    """Stable per-symbol seed so each series is independent but reproducible."""
    h = 0
    for ch in symbol.upper():
        h = (h * 131 + ord(ch)) % 1_000_003
    return int((seed * 1_000_003 + h) % (2**31 - 1))


def _simulate_regimes(rng: np.random.Generator, n: int) -> np.ndarray:
    states = np.empty(n, dtype=np.int8)
    state = RANGE
    draws = rng.random(n)
    for i in range(n):
        row = TRANSITION_MATRIX[state]
        state = int(np.searchsorted(np.cumsum(row), draws[i], side="right"))
        state = min(state, 2)
        states[i] = state
    return states


def generate_ohlcv(
    symbol: str,
    start: str = "2010-01-01",
    end: str = "2025-12-31",
    seed: int = 20260907,
    params: Optional[SyntheticParams] = None,
    intrabar_steps: int = 16,
    freq: str = "B",
) -> pd.DataFrame:
    """Generate one deterministic synthetic OHLCV series.

    Returns a validated frame indexed by timestamp.  ``df.attrs`` carries the
    regime path and a loud ``synthetic`` flag that the reporting layer uses to
    stamp every output.
    """
    p = params or DEFAULT_PARAMS.get(
        symbol.upper(), SyntheticParams(start_price=100.0, base_annual_vol=0.15)
    )
    dates = pd.date_range(start=start, end=end, freq=freq)
    n = len(dates)
    if n < 2:
        raise ValueError(f"date range {start}..{end} yields {n} bars")

    rng = np.random.default_rng(_symbol_seed(symbol, seed))
    dt = 1.0 / TRADING_DAYS_PER_YEAR

    regimes = _simulate_regimes(rng, n)

    # --- volatility path: AR(1) in logs around a regime-dependent level ----- #
    base_daily_vol = p.base_annual_vol * np.sqrt(dt)
    regime_mult = np.array([p.vol_regime_multiplier[int(r)] for r in regimes])
    log_level = np.log(base_daily_vol * regime_mult)
    log_vol = np.empty(n)
    dev = 0.0
    shocks = rng.normal(0.0, p.vol_ar_sigma, n)
    for i in range(n):
        dev = p.vol_ar_phi * dev + shocks[i]
        log_vol[i] = log_level[i] + dev
    # Cap the deviation so one tail draw cannot produce a physically absurd day.
    log_vol = np.clip(log_vol, np.log(base_daily_vol * 0.25), np.log(base_daily_vol * 5.0))
    sigma = np.exp(log_vol)

    # --- drift: unconditional + persistent trend-state component ------------ #
    daily_drift = np.full(n, p.annual_drift * dt)
    trend_daily = p.trend_annual_drift * dt
    trend_sign = 0.0
    prev_regime = -1
    drift_extra = np.zeros(n)
    for i in range(n):
        r = int(regimes[i])
        if r == TREND and prev_regime != TREND:
            trend_sign = 1.0 if rng.random() < 0.55 else -1.0   # slight long bias
        if r == TREND:
            drift_extra[i] = trend_sign * trend_daily
        prev_regime = r

    # --- jumps -------------------------------------------------------------- #
    # Fat-tailed but bounded: an unbounded Student-t draw multiplied by a
    # stochastic vol that is itself elevated produces single days no liquid
    # market has ever printed, and those fake outliers would dominate every
    # drawdown statistic downstream.
    jump_hits = rng.random(n) < p.jump_prob_per_day
    jump_dir = np.where(rng.random(n) < 0.42, 1.0, -1.0)        # jumps skew down
    jump_mag = np.abs(rng.standard_t(df=4, size=n)) * p.jump_scale_in_sigmas
    jump_cap = 6.0 * base_daily_vol
    jumps = np.where(jump_hits, np.clip(jump_dir * jump_mag * sigma, -jump_cap, jump_cap), 0.0)

    # --- close path --------------------------------------------------------- #
    shock = rng.standard_normal(n)
    log_close = np.empty(n)
    log_price = np.log(p.start_price)
    anchor = log_price
    anchor_alpha = 1.0 - np.exp(-np.log(2.0) / max(p.reversion_halflife_days, 1.0))
    for i in range(n):
        r = int(regimes[i])
        pull = p.reversion_strength * (anchor - log_price) if r == RANGE else 0.0
        step = (
            daily_drift[i] + drift_extra[i] + pull
            - 0.5 * sigma[i] ** 2 + sigma[i] * shock[i] + jumps[i]
        )
        # Bound a single bar at 10 unconditional daily sigmas.  Real markets gap,
        # but not without limit, and uncapped tails would let one simulated bar
        # decide every drawdown statistic in the report.
        step = float(np.clip(step, -10.0 * base_daily_vol, 10.0 * base_daily_vol))
        log_price += step
        anchor += anchor_alpha * (log_price - anchor)
        log_close[i] = log_price

    close = np.exp(log_close)

    # --- opens: previous close plus an overnight gap ------------------------ #
    gap_sigma = sigma * p.overnight_gap_fraction
    gaps = rng.normal(0.0, 1.0, n) * gap_sigma
    log_open = np.empty(n)
    log_open[0] = np.log(p.start_price)
    log_open[1:] = log_close[:-1] + gaps[1:]
    open_ = np.exp(log_open)

    # --- intrabar path via Brownian bridge open -> close --------------------- #
    k = max(int(intrabar_steps), 2)
    idx = np.arange(1, k + 1) / k
    inc = rng.normal(0.0, 1.0, size=(n, k)) * (sigma[:, None] / np.sqrt(k))
    cum = np.cumsum(inc, axis=1)
    bridge = cum - idx[None, :] * cum[:, -1][:, None]           # pinned at both ends
    drift_line = log_open[:, None] + idx[None, :] * (log_close - log_open)[:, None]
    path = drift_line + bridge

    log_high = np.maximum(path.max(axis=1), np.maximum(log_open, log_close))
    log_low = np.minimum(path.min(axis=1), np.minimum(log_open, log_close))
    high = np.exp(log_high)
    low = np.exp(log_low)

    # --- volume: driven by absolute return, lognormal noise ------------------ #
    abs_z = np.abs((log_close - log_open) / np.maximum(sigma, 1e-12))
    volume = p.base_volume * np.exp(
        p.volume_return_beta * np.clip(abs_z, 0, 6) * 0.35 + rng.normal(0.0, 0.28, n) - 0.05
    )

    df = pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": np.round(volume, 0)},
        index=pd.DatetimeIndex(dates, name="timestamp"),
    )

    # Floating point can leave high a hair below max(open, close); repair the
    # representation, never the economics.
    df["high"] = df[["high", "open", "close"]].max(axis=1)
    df["low"] = df[["low", "open", "close"]].min(axis=1)
    df = coerce_ohlcv(df)
    validate_ohlcv(df, symbol)

    df.attrs["synthetic"] = True
    df.attrs["symbol"] = symbol.upper()
    df.attrs["seed"] = seed
    # Stored as a plain list, not a Series/array: pandas compares .attrs with
    # ``==`` when propagating them through concat/merge, and a Series or ndarray
    # there raises "truth value is ambiguous" deep inside unrelated pandas calls.
    df.attrs["regime_path"] = [int(r) for r in regimes]
    df.attrs["regime_shares"] = {
        REGIME_NAMES[r]: float((regimes == r).mean()) for r in (TREND, RANGE, STRESS)
    }
    df.attrs["provenance"] = (
        f"SYNTHETIC regime-switching SV-jump process, symbol={symbol.upper()}, seed={seed}. "
        "Not market data. Any performance measured on it is a property of the generator."
    )
    return df


def generate_universe(
    symbols: List[str],
    start: str = "2010-01-01",
    end: str = "2025-12-31",
    seed: int = 20260907,
    **kwargs,
) -> Dict[str, pd.DataFrame]:
    return {
        s.upper(): generate_ohlcv(s, start=start, end=end, seed=seed, **kwargs) for s in symbols
    }
