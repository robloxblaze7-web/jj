"""Chronological data partitioning: train / validation / test, and walk-forward.

Two rules are enforced structurally rather than by convention.

1. **Splits are chronological, never random.**  Shuffled splits on time series
   leak the future into the past through autocorrelation and overlapping
   indicator windows.  There is no ``shuffle=True`` option here, on purpose.

2. **Boundaries are embargoed.**  An indicator with a 200-bar lookback computed
   on the first test bar has already seen 200 training bars.  Dropping
   ``embargo_bars`` at each boundary keeps the evaluation honest.  The embargo
   should be at least as long as the longest lookback any candidate uses.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import pandas as pd

from ..config import SplitConfig, WalkForwardConfig


@dataclass(frozen=True)
class Split:
    """A named, contiguous slice of the timeline."""

    name: str
    start_idx: int
    end_idx: int          # exclusive
    start: pd.Timestamp
    end: pd.Timestamp

    @property
    def n_bars(self) -> int:
        return self.end_idx - self.start_idx

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        return df.iloc[self.start_idx : self.end_idx]

    def __repr__(self) -> str:  # pragma: no cover - display only
        return f"Split({self.name}: {self.start.date()}..{self.end.date()}, {self.n_bars} bars)"


def three_way_split(
    index: pd.DatetimeIndex, config: Optional[SplitConfig] = None
) -> Dict[str, Split]:
    """Split a timeline into train / validation / test with embargo gaps.

    Embargoed bars belong to no split: they are discarded, not reassigned.
    """
    cfg = config or SplitConfig()
    cfg.validate()
    n = len(index)
    emb = int(cfg.embargo_bars)
    if n < 3 * (emb + 1) + 3:
        raise ValueError(
            f"need at least {3 * (emb + 1) + 3} bars to split with embargo={emb}, got {n}"
        )

    train_end = int(round(n * cfg.train_fraction))
    val_end = int(round(n * (cfg.train_fraction + cfg.validation_fraction)))

    bounds = [
        ("train", 0, train_end),
        ("validation", train_end + emb, val_end),
        ("test", val_end + emb, n),
    ]

    splits: Dict[str, Split] = {}
    for name, lo, hi in bounds:
        if hi - lo <= 0:
            raise ValueError(
                f"split {name!r} is empty; reduce embargo_bars or lengthen the sample"
            )
        splits[name] = Split(name, lo, hi, index[lo], index[hi - 1])
    return splits


@dataclass(frozen=True)
class WalkForwardWindow:
    """One train/test pair in a walk-forward schedule."""

    fold: int
    train_start_idx: int
    train_end_idx: int      # exclusive
    test_start_idx: int
    test_end_idx: int       # exclusive
    train_start: pd.Timestamp
    train_end: pd.Timestamp
    test_start: pd.Timestamp
    test_end: pd.Timestamp

    @property
    def n_train(self) -> int:
        return self.train_end_idx - self.train_start_idx

    @property
    def n_test(self) -> int:
        return self.test_end_idx - self.test_start_idx

    def train_slice(self, df: pd.DataFrame) -> pd.DataFrame:
        return df.iloc[self.train_start_idx : self.train_end_idx]

    def test_slice(self, df: pd.DataFrame, warmup_bars: int = 0) -> pd.DataFrame:
        """Test bars, optionally preceded by ``warmup_bars`` of history.

        Warm-up history is needed so indicators are defined on the first test
        bar, but it must never be *traded*.  The engine receives the warm-up
        prefix together with ``trade_from`` so it can compute indicators over the
        prefix while restricting fills to the test window itself.
        """
        lo = max(0, self.test_start_idx - int(warmup_bars))
        return df.iloc[lo : self.test_end_idx]


def walk_forward_windows(
    index: pd.DatetimeIndex, config: Optional[WalkForwardConfig] = None
) -> List[WalkForwardWindow]:
    """Build a walk-forward schedule over ``index``.

    ``anchored=False`` gives rolling windows of fixed length (adapts to regime
    change, less data per fit); ``anchored=True`` grows the training window from
    the start of the sample (more data, slower to adapt).  Neither is universally
    right, which is itself worth reporting.

    The embargo sits *between* train and test in every fold, so parameters are
    never selected using bars adjacent to the ones they are evaluated on.
    """
    cfg = config or WalkForwardConfig()
    cfg.validate()
    n = len(index)
    step = cfg.resolved_step()
    emb = int(cfg.embargo_bars)

    windows: List[WalkForwardWindow] = []
    fold = 0
    train_end = int(cfg.train_bars)
    while True:
        test_start = train_end + emb
        test_end = min(test_start + int(cfg.test_bars), n)
        if test_start >= n or test_end - test_start <= 0:
            break
        train_start = 0 if cfg.anchored else max(0, train_end - int(cfg.train_bars))
        if train_end - train_start < int(cfg.train_bars) and not cfg.anchored:
            break
        windows.append(
            WalkForwardWindow(
                fold=fold,
                train_start_idx=train_start,
                train_end_idx=train_end,
                test_start_idx=test_start,
                test_end_idx=test_end,
                train_start=index[train_start],
                train_end=index[train_end - 1],
                test_start=index[test_start],
                test_end=index[test_end - 1],
            )
        )
        fold += 1
        train_end += step
        if train_end + emb >= n:
            break
    return windows


def assert_no_overlap(windows: Sequence[WalkForwardWindow]) -> None:
    """Fail loudly if any fold's test window overlaps its own training window.

    This is the check that a walk-forward implementation is actually
    out-of-sample.  It runs on every use, not only in tests.
    """
    for w in windows:
        if w.test_start_idx < w.train_end_idx:
            raise AssertionError(
                f"fold {w.fold}: test starts at {w.test_start_idx} but training runs to "
                f"{w.train_end_idx} — the evaluation is not out-of-sample"
            )
    for a, b in zip(windows, windows[1:]):
        if b.test_start_idx < a.test_end_idx:
            raise AssertionError(
                f"folds {a.fold}/{b.fold}: test windows overlap, so out-of-sample bars are "
                f"counted more than once"
            )
