"""Instrument specifications and the point-in-time tradeable universe.

Two separate jobs live here.

1. **Contract specs.**  Spread, commission, margin, tick size and financing for
   each instrument.  These drive the cost model, so they are data, not magic
   numbers scattered through the engine.

2. **Survivorship control.**  Each instrument carries the dates between which it
   actually existed and was tradeable.  :meth:`Universe.active_at` returns only
   the instruments a trader could have held on a given date, and
   :meth:`Universe.audit_survivorship` flags a backtest that starts before an
   instrument was listed.  For a fixed four-instrument macro universe this is a
   light constraint, but the mechanism is what matters: the moment this project
   is pointed at equities, "the current S&P 500 members" is a survivorship-biased
   universe, and the audit is what stops you using it by accident.

All four default instruments are quoted in USD, so notional and P&L are already
in account currency.  ``point_value`` exists for instruments where that is not
true (a futures multiplier, a non-USD quote) and is applied uniformly.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Dict, Iterable, List, Optional

import pandas as pd


@dataclass(frozen=True)
class InstrumentSpec:
    """Static contract specification for one tradeable instrument.

    Attributes
    ----------
    typical_spread:
        Quoted bid/ask spread in *price* units (not pips).  Half is paid on each
        side of a round trip.
    commission_rate:
        Commission per side as a fraction of traded notional.  3.5e-5 is roughly
        the retail FX standard of $3.50 per $100k per side.
    margin_rate:
        Initial margin as a fraction of notional.  0.02 implies 50:1 maximum
        leverage on that instrument.
    financing_rate_annual_long / _short:
        Annualised carry to hold a position overnight, applied per bar held.
        Both are *costs* (positive = you pay), the conservative assumption; a
        genuine positive carry would be a negative number and should be
        justified with real broker data.
    listed_from / delisted_at:
        Point-in-time availability, used by the survivorship audit.
    """

    symbol: str
    name: str
    asset_class: str
    quote_currency: str = "USD"
    tick_size: float = 0.00001
    price_decimals: int = 5
    point_value: float = 1.0
    typical_spread: float = 0.0001
    commission_rate: float = 3.5e-5
    min_commission: float = 0.0
    margin_rate: float = 0.02
    financing_rate_annual_long: float = 0.02
    financing_rate_annual_short: float = 0.01
    min_units: float = 1.0
    unit_step: float = 1.0
    listed_from: str = "1990-01-01"
    delisted_at: Optional[str] = None
    data_notes: str = ""

    @property
    def max_instrument_leverage(self) -> float:
        return 1.0 / self.margin_rate if self.margin_rate > 0 else float("inf")

    @property
    def half_spread(self) -> float:
        return self.typical_spread / 2.0

    def is_active(self, when: pd.Timestamp) -> bool:
        when = pd.Timestamp(when)
        if when < pd.Timestamp(self.listed_from):
            return False
        if self.delisted_at is not None and when > pd.Timestamp(self.delisted_at):
            return False
        return True

    def round_price(self, price: float) -> float:
        return round(price, self.price_decimals)

    def round_units(self, units: float) -> float:
        """Round position size *down* to a tradeable increment.

        Rounding down (never up) guarantees that a size derived from a risk
        limit can only ever come in under that limit.
        """
        if self.unit_step <= 0:
            return float(units)
        steps = int(abs(units) / self.unit_step)
        rounded = steps * self.unit_step
        return float(rounded if units >= 0 else -rounded)

    def with_overrides(self, **kwargs) -> "InstrumentSpec":
        return replace(self, **kwargs)


# Spreads and commissions below are representative retail-broker figures for
# daily research, not a quote from any specific broker.  Replace them with your
# own venue's data before drawing conclusions about viability: for
# high-turnover strategies the cost assumption, not the signal, decides the
# result.
DEFAULT_INSTRUMENTS: Dict[str, InstrumentSpec] = {
    "EURUSD": InstrumentSpec(
        symbol="EURUSD", name="Euro / US Dollar", asset_class="fx_major",
        tick_size=0.00001, price_decimals=5, point_value=1.0,
        typical_spread=0.00008, commission_rate=3.5e-5, margin_rate=0.02,
        financing_rate_annual_long=0.015, financing_rate_annual_short=0.010,
        min_units=1_000.0, unit_step=1_000.0, listed_from="1999-01-04",
        data_notes="Spot FX; no dividends. Daily bars use a 17:00 New York close convention.",
    ),
    "GBPUSD": InstrumentSpec(
        symbol="GBPUSD", name="British Pound / US Dollar", asset_class="fx_major",
        tick_size=0.00001, price_decimals=5, point_value=1.0,
        typical_spread=0.00012, commission_rate=3.5e-5, margin_rate=0.02,
        financing_rate_annual_long=0.018, financing_rate_annual_short=0.012,
        min_units=1_000.0, unit_step=1_000.0, listed_from="1990-01-01",
        data_notes=(
            "Spot FX. Real history contains one-off regime breaks (2016 referendum, "
            "2022 gilt crisis) that no stationary model reproduces."
        ),
    ),
    "XAUUSD": InstrumentSpec(
        symbol="XAUUSD", name="Gold / US Dollar", asset_class="metal",
        tick_size=0.01, price_decimals=2, point_value=1.0,
        typical_spread=0.25, commission_rate=3.0e-5, margin_rate=0.05,
        financing_rate_annual_long=0.030, financing_rate_annual_short=0.020,
        min_units=1.0, unit_step=0.01, listed_from="1990-01-01",
        data_notes="Spot gold per troy ounce. No coupon; financing is a pure cost both ways.",
    ),
    "SPX500": InstrumentSpec(
        symbol="SPX500", name="S&P 500 Index (CFD proxy)", asset_class="equity_index",
        tick_size=0.1, price_decimals=2, point_value=1.0,
        typical_spread=0.5, commission_rate=2.0e-5, margin_rate=0.05,
        financing_rate_annual_long=0.045, financing_rate_annual_short=0.015,
        min_units=0.1, unit_step=0.1, listed_from="1990-01-01",
        data_notes=(
            "PRICE index, so dividends are excluded from returns while financing is still "
            "charged on long exposure — long-only results are therefore conservative. The "
            "index embeds survivorship at the constituent level: members are added and "
            "removed by committee, so index-level backtests say nothing about single-stock "
            "strategies."
        ),
    ),
}


class Universe:
    """A registry of instrument specs with point-in-time membership."""

    def __init__(self, instruments: Optional[Dict[str, InstrumentSpec]] = None):
        self._instruments: Dict[str, InstrumentSpec] = dict(
            instruments if instruments is not None else DEFAULT_INSTRUMENTS
        )

    def __contains__(self, symbol: str) -> bool:
        return symbol.upper() in self._instruments

    def __len__(self) -> int:
        return len(self._instruments)

    def symbols(self) -> List[str]:
        return sorted(self._instruments)

    def get(self, symbol: str) -> InstrumentSpec:
        key = symbol.upper()
        if key not in self._instruments:
            raise KeyError(f"unknown instrument {symbol!r}; known: {sorted(self._instruments)}")
        return self._instruments[key]

    def add(self, spec: InstrumentSpec) -> None:
        self._instruments[spec.symbol.upper()] = spec

    def active_at(self, when) -> List[str]:
        """Symbols that were listed and tradeable on ``when``."""
        ts = pd.Timestamp(when)
        return sorted(s for s, spec in self._instruments.items() if spec.is_active(ts))

    def audit_survivorship(self, symbols: Iterable[str], start, end) -> List[str]:
        """Warnings about the requested backtest window.

        A backtest that includes an instrument before it was listed is not
        merely empty for those dates — it silently changes the universe
        composition part way through, which is survivorship bias in its most
        direct form.
        """
        warnings: List[str] = []
        start_ts, end_ts = pd.Timestamp(start), pd.Timestamp(end)
        for symbol in symbols:
            spec = self.get(symbol)
            listed = pd.Timestamp(spec.listed_from)
            if listed > start_ts:
                warnings.append(
                    f"{spec.symbol}: not listed until {listed.date()}, after the requested "
                    f"start {start_ts.date()}; the effective universe changes mid-backtest."
                )
            if spec.delisted_at is not None and pd.Timestamp(spec.delisted_at) < end_ts:
                warnings.append(
                    f"{spec.symbol}: delisted {spec.delisted_at}, before the requested end "
                    f"{end_ts.date()}; positions must be closed at delisting, not carried."
                )
        return warnings

    def survivorship_notes(self) -> List[str]:
        return [
            f"{s}: {spec.data_notes}"
            for s, spec in sorted(self._instruments.items())
            if spec.data_notes
        ]


DEFAULT_UNIVERSE = Universe()
