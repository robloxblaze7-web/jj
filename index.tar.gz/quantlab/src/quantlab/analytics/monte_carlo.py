"""Monte Carlo analysis of trade sequences.

A backtest produces one ordering of trades.  That ordering is an accident.  The
same set of trades in a different order produces a different maximum drawdown, a
different longest losing streak and a different worst year — and *those* are the
numbers that decide whether a strategy is survivable in practice.

This module resamples the realised trade sequence to answer:

* How deep a drawdown should be expected from these trades, rather than how deep
  the historical one happened to be?
* How long a losing streak is normal for a system with this win rate?
* What is the probability of losing a given fraction of the account?

Three resampling schemes, with different assumptions:

``bootstrap``
    Draw trades with replacement (IID).  Assumes trade outcomes are
    independent.  Most common, and the most likely to understate drawdowns for
    strategies whose losses cluster in regimes.
``shuffle``
    Permute the actual trades.  Keeps the exact multiset of outcomes and asks
    only "what if they had arrived in a different order?".  The cleanest
    question, but it cannot say anything about outcomes worse than the worst one
    observed.
``block_bootstrap``
    Draw contiguous blocks of trades, preserving short-run clustering of wins
    and losses.  The right default when losses arrive in runs, which they
    usually do.

WHAT THIS DOES NOT DO
---------------------
Resampling cannot manufacture information that is not in the sample.  If the
backtest never experienced a 2008 or a 2015 franc unpeg, no amount of resampling
will produce one: the tails of these distributions are bounded by the tails that
were observed.  Read the results as "how bad can the *observed* kind of losing
get when it clusters", never as a worst case.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..config import MonteCarloConfig


@dataclass
class MonteCarloResult:
    """Distributions produced by resampling the trade sequence."""

    method: str
    n_simulations: int
    n_trades: int
    observed_max_drawdown: float
    observed_total_return: float
    observed_max_losing_streak: int

    max_drawdowns: np.ndarray = field(repr=False, default_factory=lambda: np.array([]))
    total_returns: np.ndarray = field(repr=False, default_factory=lambda: np.array([]))
    losing_streaks: np.ndarray = field(repr=False, default_factory=lambda: np.array([]))
    final_equities: np.ndarray = field(repr=False, default_factory=lambda: np.array([]))

    #: ``max_drawdown`` entries are positive DEPTHS (0.25 = a 25% drawdown);
    #: ``total_return`` and ``losing_streak`` are in their natural units.
    percentiles: Dict[str, Dict[str, float]] = field(default_factory=dict)
    prob_loss: float = float("nan")
    risk_of_ruin: Dict[str, float] = field(default_factory=dict)
    observed_dd_percentile: float = float("nan")
    warnings: List[str] = field(default_factory=list)

    def summary_frame(self) -> pd.DataFrame:
        rows = []
        for name, quantiles in self.percentiles.items():
            row = {"metric": name}
            row.update(quantiles)
            rows.append(row)
        return pd.DataFrame(rows).set_index("metric") if rows else pd.DataFrame()

    def headline(self) -> str:
        dd = self.percentiles.get("max_drawdown", {})
        streak = self.percentiles.get("losing_streak", {})
        return (
            f"median simulated maxDD {-dd.get('p50', float('nan')):.1%}, "
            f"1-in-20 worst {-dd.get('p95', float('nan')):.1%} "
            f"(observed {self.observed_max_drawdown:.1%}); "
            f"typical longest losing streak {streak.get('p50', float('nan')):.0f}, "
            f"95th pct {streak.get('p95', float('nan')):.0f} "
            f"(observed {self.observed_max_losing_streak})"
        )


def trade_returns_from_blotter(trades: pd.DataFrame) -> np.ndarray:
    """Per-trade returns as a fraction of the equity at entry.

    Using fractional returns rather than cash P&L keeps the resampled paths
    consistent with the compounding position sizing the engine actually used.
    Resampling raw cash amounts would implicitly assume a fixed bet size that the
    backtest never traded.
    """
    if trades.empty:
        return np.array([])
    equity = trades["equity_at_entry"].to_numpy(dtype=float)
    pnl = trades["net_pnl"].to_numpy(dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(equity > 0, pnl / equity, np.nan)
    return r[np.isfinite(r)]


def _resample_indices(rng: np.random.Generator, n: int, method: str, block_size: int) -> np.ndarray:
    if method == "bootstrap":
        return rng.integers(0, n, size=n)
    if method == "shuffle":
        return rng.permutation(n)
    if method == "block_bootstrap":
        block = max(int(block_size), 1)
        n_blocks = int(np.ceil(n / block))
        starts = rng.integers(0, n, size=n_blocks)
        idx = np.concatenate([(np.arange(s, s + block) % n) for s in starts])
        return idx[:n]
    raise ValueError(f"unknown resampling method {method!r}")


def _path_stats(returns: np.ndarray) -> tuple[float, float, int]:
    """Max drawdown, total return and longest losing streak for one path."""
    equity = np.cumprod(1.0 + returns)
    peak = np.maximum.accumulate(equity)
    dd = float(np.min(equity / peak - 1.0)) if equity.size else 0.0
    total = float(equity[-1] - 1.0) if equity.size else 0.0

    longest = current = 0
    for flag in returns < 0:
        current = current + 1 if flag else 0
        if current > longest:
            longest = current
    return dd, total, int(longest)


def run_monte_carlo(
    trades: pd.DataFrame,
    config: Optional[MonteCarloConfig] = None,
    *,
    ruin_thresholds: Sequence[float] = (0.10, 0.20, 0.30, 0.50),
) -> MonteCarloResult:
    """Resample the trade sequence and summarise the resulting distributions."""
    cfg = config or MonteCarloConfig()
    cfg.validate()

    returns = trade_returns_from_blotter(trades)
    n = returns.size
    warnings: List[str] = []

    if n == 0:
        return MonteCarloResult(
            method=cfg.method, n_simulations=0, n_trades=0, observed_max_drawdown=0.0,
            observed_total_return=0.0, observed_max_losing_streak=0,
            warnings=["No trades to resample; Monte Carlo analysis is undefined."],
        )
    if n < 20:
        warnings.append(
            f"Only {n} trades in the sample. Every resampled path is drawn from those {n} "
            f"outcomes, so the distributions below describe the sample, not the strategy. "
            f"Treat them as illustrative."
        )

    obs_dd, obs_total, obs_streak = _path_stats(returns)

    rng = np.random.default_rng(cfg.seed)
    sims = int(cfg.n_simulations)
    dds = np.empty(sims)
    totals = np.empty(sims)
    streaks = np.empty(sims, dtype=int)

    for i in range(sims):
        idx = _resample_indices(rng, n, cfg.method, cfg.block_size)
        dds[i], totals[i], streaks[i] = _path_stats(returns[idx])

    def pct(arr: np.ndarray) -> Dict[str, float]:
        levels = sorted({0.05, 0.25, 0.5, 0.75, 0.95, 0.99, *cfg.confidence_levels})
        out = {f"p{int(round(level * 100))}": float(np.quantile(arr, level)) for level in levels}
        out["mean"] = float(arr.mean())
        out["worst"] = float(arr.min())
        out["best"] = float(arr.max())
        return out

    # Drawdowns are stored signed (negative) but summarised as positive DEPTHS,
    # so that "p95" means "a drawdown this deep or deeper happens 5% of the time"
    # rather than the shallowest 5%.  Quantiles of a negative quantity read
    # backwards, and getting that wrong turns the most important number in the
    # report upside down.
    percentiles = {
        "max_drawdown": pct(-dds),          # positive depths
        "total_return": pct(totals),
        "losing_streak": pct(streaks.astype(float)),
    }

    risk_of_ruin = {
        f"prob_drawdown_worse_than_{int(t * 100)}pct": float((dds <= -t).mean())
        for t in ruin_thresholds
    }
    # Fraction of simulations at least as deep as the historical drawdown.
    observed_dd_percentile = float((dds <= obs_dd).mean())
    observed_depth = -obs_dd

    if observed_dd_percentile > 0.75:
        warnings.append(
            f"The historical maximum drawdown ({obs_dd:.1%}) is milder than "
            f"{observed_dd_percentile:.0%} of resampled orderings of the same trades. The "
            f"backtest experienced a favourable sequence; sizing an account off its drawdown "
            f"would understate the risk."
        )
    p95_depth = percentiles["max_drawdown"]["p95"]
    if p95_depth > observed_depth:
        warnings.append(
            f"A 1-in-20 reordering of these same trades produces a {-p95_depth:.1%} drawdown, "
            f"versus {obs_dd:.1%} historically. Plan capital against the former."
        )

    return MonteCarloResult(
        method=cfg.method, n_simulations=sims, n_trades=n,
        observed_max_drawdown=obs_dd, observed_total_return=obs_total,
        observed_max_losing_streak=obs_streak, max_drawdowns=dds, total_returns=totals,
        losing_streaks=streaks, final_equities=1.0 + totals, percentiles=percentiles,
        prob_loss=float((totals < 0).mean()), risk_of_ruin=risk_of_ruin,
        observed_dd_percentile=observed_dd_percentile, warnings=warnings,
    )


def expected_losing_streak(win_rate: float, n_trades: int) -> float:
    """Expected longest run of losses for a random sequence with this win rate.

    A useful anchor when a live system has "stopped working": with a 40% win
    rate over 200 trades, the longest expected losing run is about 8 in a row *by
    chance alone*.  Seeing one is not evidence that anything broke.
    """
    if not 0 < win_rate < 1 or n_trades < 1:
        return float("nan")
    p_loss = 1.0 - win_rate
    return float(np.log(n_trades * win_rate) / -np.log(p_loss)) if p_loss > 0 else 0.0


def streak_probability(win_rate: float, n_trades: int, streak: int) -> float:
    """Approximate probability of seeing at least ``streak`` consecutive losses."""
    if not 0 < win_rate < 1 or n_trades < streak or streak < 1:
        return float("nan")
    p_loss = 1.0 - win_rate
    expected_runs = (n_trades - streak + 1) * (p_loss**streak) * win_rate
    return float(1.0 - np.exp(-expected_runs))
