"""Analytics: performance metrics, walk-forward, Monte Carlo, overfitting checks."""

from .metrics import (
    DrawdownStats,
    PerformanceMetrics,
    RMultipleStats,
    compute_metrics,
    drawdown_series,
    drawdown_stats,
    metrics_from_result,
    metrics_table,
    monthly_returns,
    r_multiple_stats,
    rolling_sharpe,
    streak_summary,
)
from .monte_carlo import (
    MonteCarloResult,
    expected_losing_streak,
    run_monte_carlo,
    streak_probability,
    trade_returns_from_blotter,
)
from .overfitting import (
    OverfittingReport,
    PBOResult,
    build_overfitting_report,
    deflated_sharpe_ratio,
    expected_max_sharpe_null,
    haircut_sharpe,
    probability_of_backtest_overfitting,
    spearman_correlation,
)
from .walkforward import FoldResult, WalkForwardResult, run_walk_forward

__all__ = [
    "PerformanceMetrics", "compute_metrics", "metrics_from_result", "metrics_table",
    "DrawdownStats", "drawdown_stats", "drawdown_series", "RMultipleStats",
    "r_multiple_stats", "streak_summary", "monthly_returns", "rolling_sharpe",
    "run_walk_forward", "WalkForwardResult", "FoldResult",
    "run_monte_carlo", "MonteCarloResult", "trade_returns_from_blotter",
    "expected_losing_streak", "streak_probability",
    "build_overfitting_report", "OverfittingReport", "PBOResult",
    "deflated_sharpe_ratio", "expected_max_sharpe_null", "haircut_sharpe",
    "probability_of_backtest_overfitting", "spearman_correlation",
]
