"""Walk-forward analysis.

The question a single backtest cannot answer is: *would I have chosen these
parameters at the time?*  Walk-forward answers it by only ever evaluating
parameters that were selected using data strictly before the evaluation window.

For each fold:

1. every candidate parameter set is run on the training window,
2. the best one by ``selection_metric`` is chosen — with no knowledge of the
   test window,
3. that single choice is run on the test window, which follows the training
   window after an embargo gap,
4. the account balance carries forward, so the folds compose into one continuous
   out-of-sample equity curve.

Every candidate is *also* run on the test window.  Those extra runs never
influence the selection; they exist so the report can measure something the
headline number cannot show: whether in-sample ranking has any relationship to
out-of-sample ranking.  If the best in-sample parameters land in the bottom half
out-of-sample as often as not, the selection procedure is fitting noise, and the
stitched equity curve — however good it looks — is the product of a process with
no predictive content.  That statistic is the probability of backtest
overfitting, computed in :mod:`quantlab.analytics.overfitting`.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace as dc_replace
from typing import Any, Callable, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..backtest.engine import BacktestEngine
from ..backtest.types import BacktestResult
from ..config import BacktestConfig, WalkForwardConfig
from ..data.splits import assert_no_overlap, walk_forward_windows
from ..data.universe import DEFAULT_UNIVERSE, InstrumentSpec
from ..strategies.base import Strategy
from ..strategies.registry import build_strategy, strategy_grid
from .metrics import PerformanceMetrics, compute_metrics, metrics_from_result

HIGHER_IS_BETTER = {
    "sharpe_ratio", "sortino_ratio", "calmar_ratio", "total_return", "cagr",
    "profit_factor", "expectancy_r", "expectancy_cash", "win_rate", "recovery_factor",
}


@dataclass
class CandidateScore:
    params: Dict[str, Any]
    train_score: float
    train_trades: int
    test_score: float
    test_trades: int
    eligible: bool


@dataclass
class FoldResult:
    fold: int
    train_start: pd.Timestamp
    train_end: pd.Timestamp
    test_start: pd.Timestamp
    test_end: pd.Timestamp
    selected_params: Optional[Dict[str, Any]]
    train_score: float
    test_score: float
    n_candidates: int
    candidates: List[CandidateScore]
    result: Optional[BacktestResult]
    note: str = ""

    @property
    def selected_test_metrics(self) -> Optional[PerformanceMetrics]:
        return metrics_from_result(self.result) if self.result is not None else None


@dataclass
class WalkForwardResult:
    """Stitched out-of-sample record plus per-fold detail."""

    symbol: str
    strategy: str
    folds: List[FoldResult]
    equity_curve: pd.DataFrame
    trades: pd.DataFrame
    metrics: PerformanceMetrics
    initial_balance: float
    selection_metric: str
    n_candidates: int
    warnings: List[str] = field(default_factory=list)

    @property
    def n_folds(self) -> int:
        return len(self.folds)

    @property
    def traded_folds(self) -> int:
        return sum(1 for f in self.folds if f.result is not None)

    def parameter_stability(self) -> pd.DataFrame:
        """Which parameter values were selected in each fold.

        A strategy whose selected parameters jump around every fold is not
        adapting to the market; it is fitting whatever noise the last training
        window contained.  Stability is weak evidence *for* a result, but
        instability is strong evidence against it.
        """
        rows = [
            {"fold": f.fold, **f.selected_params}
            for f in self.folds
            if f.selected_params is not None
        ]
        return pd.DataFrame(rows).set_index("fold") if rows else pd.DataFrame()

    def parameter_churn(self) -> float:
        """Fraction of consecutive fold pairs whose selected parameters differ."""
        chosen = [f.selected_params for f in self.folds if f.selected_params is not None]
        if len(chosen) < 2:
            return float("nan")
        changes = sum(1 for a, b in zip(chosen, chosen[1:]) if a != b)
        return changes / (len(chosen) - 1)

    def fold_table(self) -> pd.DataFrame:
        rows = []
        for f in self.folds:
            m = f.selected_test_metrics
            rows.append(
                {
                    "fold": f.fold,
                    "train_start": f.train_start.date(),
                    "train_end": f.train_end.date(),
                    "test_start": f.test_start.date(),
                    "test_end": f.test_end.date(),
                    "params": ",".join(
                        f"{k}={v}" for k, v in sorted((f.selected_params or {}).items())
                    ),
                    "train_score": f.train_score,
                    "test_score": f.test_score,
                    "test_return": m.total_return if m else np.nan,
                    "test_trades": m.n_trades if m else 0,
                    "test_max_dd": m.max_drawdown if m else np.nan,
                    "note": f.note,
                }
            )
        return pd.DataFrame(rows)

    def walk_forward_efficiency(self) -> float:
        """Mean out-of-sample score divided by mean in-sample score.

        Below ~0.5 the selection process is mostly fitting noise.  Above 1.0 is
        not a triumph either — it usually means the test windows happened to be
        easier than the training windows, which is luck, not skill.

        Returns NaN when the mean in-sample score is not positive: a ratio whose
        denominator is near or below zero produces impressive-looking numbers
        that mean nothing, and reporting one would be worse than reporting
        nothing.  Use :meth:`score_summary` in that case.
        """
        train = [f.train_score for f in self.folds if np.isfinite(f.train_score)]
        test = [f.test_score for f in self.folds if np.isfinite(f.test_score)]
        if not train or not test:
            return float("nan")
        mt = float(np.mean(train))
        if mt <= 1e-9:
            return float("nan")
        return float(np.mean(test) / mt)

    def score_summary(self) -> Dict[str, float]:
        """Mean in-sample and out-of-sample selection scores, and the gap.

        Always interpretable, unlike the ratio: a positive in-sample mean with a
        negative out-of-sample mean is the signature of a search that found
        nothing real.
        """
        train = [f.train_score for f in self.folds if np.isfinite(f.train_score)]
        test = [f.test_score for f in self.folds if np.isfinite(f.test_score)]
        mt = float(np.mean(train)) if train else float("nan")
        mo = float(np.mean(test)) if test else float("nan")
        return {
            "mean_in_sample_score": mt,
            "mean_out_of_sample_score": mo,
            "degradation": float(mt - mo) if np.isfinite(mt) and np.isfinite(mo) else float("nan"),
        }


def _score(metrics: PerformanceMetrics, key: str) -> float:
    value = getattr(metrics, key, float("nan"))
    if not np.isfinite(value):
        return float("-inf")
    return float(value) if key in HIGHER_IS_BETTER else -float(value)


def run_walk_forward(
    df: pd.DataFrame,
    strategy_name: str,
    *,
    symbol: Optional[str] = None,
    spec: Optional[InstrumentSpec] = None,
    backtest_config: Optional[BacktestConfig] = None,
    wf_config: Optional[WalkForwardConfig] = None,
    param_grid: Optional[Sequence[Dict[str, Any]]] = None,
    long_only: bool = False,
    compound_across_folds: bool = True,
    progress: Optional[Callable[[str], None]] = None,
) -> WalkForwardResult:
    """Run a full walk-forward analysis for one strategy on one instrument."""
    sym = (symbol or df.attrs.get("symbol") or (spec.symbol if spec else "EURUSD")).upper()
    spec = spec or DEFAULT_UNIVERSE.get(sym)
    cfg = backtest_config or BacktestConfig()
    cfg.validate()
    wf = wf_config or WalkForwardConfig()
    wf.validate()
    grid = list(param_grid) if param_grid is not None else strategy_grid(strategy_name)
    if not grid:
        raise ValueError(f"empty parameter grid for {strategy_name}")

    # The warm-up prefix handed to each test window must cover the longest
    # indicator lookback in the grid, not just the config default.  Otherwise a
    # 250-bar momentum candidate is still inside its own warm-up on the first
    # test bar and silently trades nothing for the first months of every fold.
    grid_lookback = max(
        build_strategy(strategy_name, p, long_only=long_only).lookback for p in grid
    )
    warmup_needed = int(max(cfg.warmup_bars, grid_lookback + cfg.atr_period + 5))

    windows = walk_forward_windows(df.index, wf)
    assert_no_overlap(windows)
    warnings: List[str] = []
    if not windows:
        warnings.append(
            f"No walk-forward folds fit in {len(df)} bars with train={wf.train_bars} "
            f"test={wf.test_bars}; nothing was evaluated out-of-sample."
        )

    balance = float(cfg.initial_balance)
    folds: List[FoldResult] = []
    equity_parts: List[pd.DataFrame] = []
    trade_parts: List[pd.DataFrame] = []

    for w in windows:
        if progress:
            progress(
                f"{sym}/{strategy_name} fold {w.fold} "
                f"test {w.test_start.date()}..{w.test_end.date()}"
            )

        train_df = w.train_slice(df)
        test_df = w.test_slice(df, warmup_bars=warmup_needed)
        candidates: List[CandidateScore] = []

        for params in grid:
            strat = build_strategy(strategy_name, params, long_only=long_only)
            train_res = _run(train_df, strat, cfg, spec, initial_balance=cfg.initial_balance)
            train_m = metrics_from_result(train_res, cfg.bars_per_year, cfg.risk_free_rate)

            # Every candidate is also evaluated out-of-sample.  This never feeds
            # the selection; it is used only to measure whether in-sample
            # ranking predicts out-of-sample ranking at all.
            test_res = _run(
                test_df, strat, cfg, spec, initial_balance=cfg.initial_balance,
                trade_from=w.test_start,
            )
            test_m = metrics_from_result(test_res, cfg.bars_per_year, cfg.risk_free_rate)

            candidates.append(
                CandidateScore(
                    params=dict(params),
                    train_score=_score(train_m, wf.selection_metric),
                    train_trades=train_m.n_trades,
                    test_score=_score(test_m, wf.selection_metric),
                    test_trades=test_m.n_trades,
                    eligible=train_m.n_trades >= wf.min_trades_for_selection,
                )
            )

        eligible = [c for c in candidates if c.eligible and np.isfinite(c.train_score)]
        if not eligible:
            folds.append(
                FoldResult(
                    fold=w.fold, train_start=w.train_start, train_end=w.train_end,
                    test_start=w.test_start, test_end=w.test_end, selected_params=None,
                    train_score=float("nan"), test_score=float("nan"),
                    n_candidates=len(candidates), candidates=candidates, result=None,
                    note=(
                        f"no candidate reached {wf.min_trades_for_selection} training "
                        f"trades; fold left flat"
                    ),
                )
            )
            continue

        best = max(eligible, key=lambda c: c.train_score)
        strat = build_strategy(strategy_name, best.params, long_only=long_only)
        live_res = _run(
            test_df, strat, cfg, spec,
            initial_balance=balance if compound_across_folds else cfg.initial_balance,
            trade_from=w.test_start,
        )

        if compound_across_folds and not live_res.equity_curve.empty:
            balance = float(live_res.equity_curve["equity"].iloc[-1])

        if not live_res.equity_curve.empty:
            equity_parts.append(live_res.equity_curve)
        if not live_res.trades.empty:
            trade_parts.append(live_res.trades)

        folds.append(
            FoldResult(
                fold=w.fold, train_start=w.train_start, train_end=w.train_end,
                test_start=w.test_start, test_end=w.test_end,
                selected_params=dict(best.params), train_score=best.train_score,
                test_score=best.test_score, n_candidates=len(candidates),
                candidates=candidates, result=live_res,
            )
        )

    equity = (
        pd.concat(equity_parts).sort_index()
        if equity_parts
        else pd.DataFrame(columns=["equity", "balance", "position_units", "exposure", "price"])
    )
    equity = equity[~equity.index.duplicated(keep="last")]
    if not equity.empty:
        equity["drawdown"] = equity["equity"] / equity["equity"].cummax() - 1.0
        equity["returns"] = equity["equity"].pct_change().fillna(0.0)

    trades = (
        pd.concat(trade_parts).sort_values("exit_time").reset_index(drop=True)
        if trade_parts
        else pd.DataFrame()
    )

    metrics = compute_metrics(
        equity, trades, initial_balance=cfg.initial_balance,
        bars_per_year=cfg.bars_per_year, risk_free_rate=cfg.risk_free_rate,
        extra_warnings=warnings,
    )

    result = WalkForwardResult(
        symbol=sym, strategy=strategy_name, folds=folds, equity_curve=equity,
        trades=trades, metrics=metrics, initial_balance=float(cfg.initial_balance),
        selection_metric=wf.selection_metric, n_candidates=len(grid), warnings=list(warnings),
    )

    churn = result.parameter_churn()
    if np.isfinite(churn) and churn > 0.6:
        result.warnings.append(
            f"Selected parameters changed in {churn:.0%} of consecutive folds. The optimiser "
            f"is not converging on a stable configuration, which is what fitting noise looks "
            f"like."
        )
    wfe = result.walk_forward_efficiency()
    summary = result.score_summary()
    if np.isfinite(wfe) and wfe < 0.5:
        result.warnings.append(
            f"Walk-forward efficiency {wfe:.2f}: out-of-sample performance is less than half "
            f"of in-sample. The in-sample figures are not a guide to anything."
        )
    if (
        np.isfinite(summary["mean_in_sample_score"])
        and np.isfinite(summary["mean_out_of_sample_score"])
        and summary["mean_in_sample_score"] > 0 >= summary["mean_out_of_sample_score"]
    ):
        result.warnings.append(
            f"Mean in-sample {wf.selection_metric} was {summary['mean_in_sample_score']:+.2f} "
            f"but mean out-of-sample was {summary['mean_out_of_sample_score']:+.2f}. Selection "
            f"found configurations that worked in the training window and not afterwards — "
            f"the definition of fitting noise."
        )
    return result


def _run(
    df: pd.DataFrame,
    strategy: Strategy,
    cfg: BacktestConfig,
    spec: InstrumentSpec,
    *,
    initial_balance: float,
    trade_from: Optional[pd.Timestamp] = None,
) -> BacktestResult:
    run_cfg = dc_replace(cfg, initial_balance=float(max(initial_balance, 1e-9)))
    engine = BacktestEngine(run_cfg, spec)
    signals = strategy.generate_signals(df)
    return engine.run(
        df, signals, strategy_name=strategy.name, params=dict(strategy.params),
        trade_from=trade_from,
    )
