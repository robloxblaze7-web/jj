"""Performance metrics.

Every statistic here comes with the same caveat, so it is stated once at the top
rather than repeated on each function: **these are descriptions of one
historical sample, not estimates of future performance.**  A backtest produces a
single path; the metrics summarise that path.  How much they tell you about the
next path depends entirely on how many independent trades produced them and how
many variants were searched before this one was reported.

Two habits are built into the module to keep that visible:

* Sharpe ratios are reported with a standard error and a t-statistic.  With 40
  trades, a Sharpe of 1.0 is roughly one standard error from zero — which is to
  say, indistinguishable from luck.
* Nothing is annualised silently.  ``bars_per_year`` is an explicit argument,
  and annualising a sub-year sample is flagged.

On the ratios themselves: Sharpe assumes returns are roughly IID and symmetric.
Strategies with stops and targets produce skewed, autocorrelated returns, so
Sharpe understates the risk of "many small wins, rare huge loss" profiles.  That
is why the R-multiple distribution and the Monte Carlo drawdown analysis are
part of the standard report rather than optional extras.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

TRADING_DAYS = 252.0


# --------------------------------------------------------------------------- #
# small statistical helpers (no scipy dependency)
# --------------------------------------------------------------------------- #
def _norm_cdf(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def two_sided_p_value(t_stat: float) -> float:
    """Normal-approximation two-sided p-value.

    Deliberately the *normal* approximation rather than a t-distribution: the
    difference is negligible next to the fact that strategy returns are not
    normal at all, and three extra decimal places would be false precision.
    """
    if not np.isfinite(t_stat):
        return float("nan")
    return float(2.0 * (1.0 - _norm_cdf(abs(t_stat))))


def skewness(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 3:
        return float("nan")
    m, s = x.mean(), x.std(ddof=1)
    if s == 0:
        return 0.0
    return float(n / ((n - 1) * (n - 2)) * np.sum(((x - m) / s) ** 3))


def excess_kurtosis(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 4:
        return float("nan")
    m, s = x.mean(), x.std(ddof=1)
    if s == 0:
        return 0.0
    g2 = np.sum(((x - m) / s) ** 4) * n * (n + 1) / ((n - 1) * (n - 2) * (n - 3))
    return float(g2 - 3.0 * (n - 1) ** 2 / ((n - 2) * (n - 3)))


# --------------------------------------------------------------------------- #
# drawdown
# --------------------------------------------------------------------------- #
@dataclass
class DrawdownStats:
    max_drawdown: float                 # negative fraction, e.g. -0.23
    max_drawdown_cash: float
    peak_date: Optional[pd.Timestamp]
    trough_date: Optional[pd.Timestamp]
    recovery_date: Optional[pd.Timestamp]
    max_drawdown_bars: int
    longest_underwater_bars: int
    time_underwater_fraction: float


def drawdown_series(equity: pd.Series) -> pd.Series:
    return equity / equity.cummax() - 1.0


def drawdown_stats(equity: pd.Series) -> DrawdownStats:
    """Peak-to-trough statistics, including how long recovery took.

    Depth is only half the story: a 20% drawdown that recovers in a month and a
    20% drawdown that lasts three years are different businesses.  Time
    underwater is what actually ends most real trading programmes.
    """
    if equity.empty:
        return DrawdownStats(0.0, 0.0, None, None, None, 0, 0, 0.0)

    peaks = equity.cummax()
    dd = equity / peaks - 1.0
    trough_idx = dd.idxmin()
    max_dd = float(dd.min())

    before = equity.loc[:trough_idx]
    peak_idx = before.idxmax() if len(before) else equity.index[0]
    peak_val = float(equity.loc[peak_idx])
    trough_val = float(equity.loc[trough_idx])

    after = equity.loc[trough_idx:]
    recovered = after[after >= peak_val]
    recovery_idx = recovered.index[0] if len(recovered) else None

    positions = {ts: i for i, ts in enumerate(equity.index)}
    dd_bars = positions[trough_idx] - positions[peak_idx]

    underwater = (dd < -1e-12).to_numpy()
    longest = current = 0
    for flag in underwater:
        current = current + 1 if flag else 0
        longest = max(longest, current)

    return DrawdownStats(
        max_drawdown=max_dd,
        max_drawdown_cash=float(trough_val - peak_val),
        peak_date=peak_idx,
        trough_date=trough_idx,
        recovery_date=recovery_idx,
        max_drawdown_bars=int(dd_bars),
        longest_underwater_bars=int(longest),
        time_underwater_fraction=float(underwater.mean()),
    )


# --------------------------------------------------------------------------- #
# streaks
# --------------------------------------------------------------------------- #
def max_consecutive(flags: Sequence[bool]) -> int:
    best = current = 0
    for f in flags:
        current = current + 1 if f else 0
        best = max(best, current)
    return int(best)


def streak_summary(pnl: Sequence[float]) -> Dict[str, int]:
    return {
        "max_consecutive_wins": max_consecutive([p > 0 for p in pnl]),
        "max_consecutive_losses": max_consecutive([p < 0 for p in pnl]),
    }


# --------------------------------------------------------------------------- #
# R-multiples
# --------------------------------------------------------------------------- #
@dataclass
class RMultipleStats:
    """Distribution of trade outcomes in units of initial risk.

    R-multiples are the natural currency of a stop-based system: a trade that
    hits its stop is -1R, one that makes three times the risked amount is +3R.
    Expressed this way, results are comparable across instruments and account
    sizes, and expectancy in R answers the only question that matters long run:
    what does the average trade earn per unit risked?

    Realised R below -1 means the trade lost more than the amount risked: either
    a bar gapped through the stop, or round-turn costs pushed the net loss past
    the stop distance, or both.  A cluster at -1.2R on a system whose average
    winner is +1.5R is telling you that costs, not the signal, decide the
    outcome.
    """

    count: int
    mean: float
    median: float
    std: float
    skew: float
    excess_kurtosis: float
    min: float
    max: float
    percentiles: Dict[str, float] = field(default_factory=dict)
    histogram_counts: List[int] = field(default_factory=list)
    histogram_edges: List[float] = field(default_factory=list)
    fraction_beyond_full_stop: float = 0.0
    expectancy_r: float = 0.0


def r_multiple_stats(r_values: Sequence[float], bins: int = 25) -> RMultipleStats:
    r = np.asarray(list(r_values), dtype=float)
    r = r[np.isfinite(r)]
    if r.size == 0:
        return RMultipleStats(0, *([float("nan")] * 7), {}, [], [], 0.0, 0.0)

    edges = np.histogram_bin_edges(r, bins=bins)
    counts, _ = np.histogram(r, bins=edges)
    pct_levels = [1, 5, 10, 25, 50, 75, 90, 95, 99]
    return RMultipleStats(
        count=int(r.size),
        mean=float(r.mean()),
        median=float(np.median(r)),
        std=float(r.std(ddof=1)) if r.size > 1 else 0.0,
        skew=skewness(r),
        excess_kurtosis=excess_kurtosis(r),
        min=float(r.min()),
        max=float(r.max()),
        percentiles={f"p{p}": float(np.percentile(r, p)) for p in pct_levels},
        histogram_counts=[int(c) for c in counts],
        histogram_edges=[float(e) for e in edges],
        fraction_beyond_full_stop=float((r < -1.0 - 1e-9).mean()),
        expectancy_r=float(r.mean()),
    )


# --------------------------------------------------------------------------- #
# the main metric bundle
# --------------------------------------------------------------------------- #
@dataclass
class PerformanceMetrics:
    """Full metric set for one backtest."""

    total_return: float
    cagr: float
    final_equity: float
    initial_balance: float
    years: float

    annual_volatility: float
    sharpe_ratio: float
    sharpe_standard_error: float
    sharpe_t_stat: float
    sharpe_p_value: float
    sortino_ratio: float
    calmar_ratio: float
    max_drawdown: float
    max_drawdown_cash: float
    max_drawdown_bars: int
    longest_underwater_bars: int
    time_underwater_fraction: float
    recovery_factor: float

    n_trades: int
    win_rate: float
    average_win: float
    average_loss: float
    win_loss_ratio: float
    expectancy_cash: float
    expectancy_r: float
    profit_factor: float
    max_consecutive_wins: int
    max_consecutive_losses: int
    average_bars_held: float
    exposure_fraction: float
    best_trade: float
    worst_trade: float
    total_costs: float
    cost_drag_fraction: float
    gross_profit: float
    gross_loss: float

    return_skew: float
    return_excess_kurtosis: float
    r_multiples: RMultipleStats

    warnings: List[str] = field(default_factory=list)

    def to_dict(self, include_r_detail: bool = False) -> Dict[str, Any]:
        d = asdict(self)
        r = d.pop("r_multiples")
        if include_r_detail:
            d["r_multiples"] = r
        else:
            d["r_mean"] = r["mean"]
            d["r_std"] = r["std"]
            d["r_p05"] = r.get("percentiles", {}).get("p5", float("nan"))
            d["r_p95"] = r.get("percentiles", {}).get("p95", float("nan"))
        return d

    def headline(self) -> str:
        return (
            f"return {self.total_return:+.1%} | CAGR {self.cagr:+.1%} | "
            f"Sharpe {self.sharpe_ratio:.2f} (t={self.sharpe_t_stat:.1f}) | "
            f"maxDD {self.max_drawdown:.1%} | trades {self.n_trades} | "
            f"win {self.win_rate:.0%} | PF {self.profit_factor:.2f} | "
            f"expectancy {self.expectancy_r:+.3f}R"
        )


def _safe_div(a: float, b: float, default: float = float("nan")) -> float:
    return float(a / b) if b not in (0, 0.0) and np.isfinite(b) else default


def compute_metrics(
    equity_curve: pd.DataFrame,
    trades: pd.DataFrame,
    *,
    initial_balance: float,
    bars_per_year: float = TRADING_DAYS,
    risk_free_rate: float = 0.0,
    extra_warnings: Optional[List[str]] = None,
) -> PerformanceMetrics:
    """Compute the full metric set from an equity curve and a trade blotter."""
    warnings: List[str] = list(extra_warnings or [])

    if equity_curve.empty:
        warnings.append("Empty equity curve: no metrics can be computed.")
        return _empty_metrics(initial_balance, warnings)

    equity = equity_curve["equity"].astype(float)
    rets = equity.pct_change().dropna()
    final_equity = float(equity.iloc[-1])

    # Elapsed time from the calendar, not the bar count, so a 252-bar year of
    # daily FX bars and a 260-bar year both annualise correctly.
    span_days = (equity.index[-1] - equity.index[0]).days
    years = max(span_days / 365.25, 1e-9)
    if span_days < 365:
        warnings.append(
            f"Sample spans only {span_days} days; annualised figures (CAGR, Sharpe, "
            f"volatility) extrapolate a fraction of a year and should be read as scaling "
            f"conventions, not forecasts."
        )

    total_return = final_equity / initial_balance - 1.0
    if final_equity <= 0:
        cagr = -1.0
        warnings.append("Equity reached zero or below: the account was wiped out.")
    else:
        cagr = (final_equity / initial_balance) ** (1.0 / years) - 1.0

    n_ret = len(rets)
    vol_bar = float(rets.std(ddof=1)) if n_ret > 1 else 0.0
    ann_vol = vol_bar * math.sqrt(bars_per_year)
    rf_bar = risk_free_rate / bars_per_year
    excess = rets - rf_bar
    mean_excess = float(excess.mean()) if n_ret else 0.0

    sharpe = _safe_div(mean_excess, vol_bar, 0.0) * math.sqrt(bars_per_year) if vol_bar > 0 else 0.0
    # SE of an annualised Sharpe under IID normality: sqrt((1 + S^2/2) / N)
    if n_ret > 2:
        sr_bar = sharpe / math.sqrt(bars_per_year)
        sharpe_se = math.sqrt((1.0 + 0.5 * sr_bar**2) / n_ret) * math.sqrt(bars_per_year)
    else:
        sharpe_se = float("nan")
    sharpe_t = _safe_div(sharpe, sharpe_se, float("nan"))
    sharpe_p = two_sided_p_value(sharpe_t)

    downside = excess[excess < 0]
    downside_dev = float(np.sqrt((downside**2).mean())) if len(downside) else 0.0
    sortino = (
        _safe_div(mean_excess, downside_dev, float("inf")) * math.sqrt(bars_per_year)
        if downside_dev > 0
        else float("nan")
    )

    dd = drawdown_stats(equity)
    calmar = _safe_div(cagr, abs(dd.max_drawdown), float("nan"))
    recovery = _safe_div(final_equity - initial_balance, abs(dd.max_drawdown_cash), float("nan"))

    n_trades = int(len(trades))
    if n_trades:
        pnl = trades["net_pnl"].astype(float)
        wins, losses = pnl[pnl > 0], pnl[pnl < 0]
        win_rate = float(len(wins) / n_trades)
        avg_win = float(wins.mean()) if len(wins) else 0.0
        avg_loss = float(losses.mean()) if len(losses) else 0.0
        gross_profit = float(wins.sum())
        gross_loss = float(-losses.sum())
        profit_factor = _safe_div(
            gross_profit, gross_loss, float("inf") if gross_profit > 0 else float("nan")
        )
        expectancy_cash = float(pnl.mean())
        streaks = streak_summary(pnl.tolist())
        r_stats = r_multiple_stats(trades["r_multiple"].tolist())
        avg_bars = float(trades["bars_held"].mean())
        best, worst = float(pnl.max()), float(pnl.min())
        total_costs = float(trades["total_costs"].sum()) if "total_costs" in trades else 0.0
        win_loss_ratio = _safe_div(
            avg_win, abs(avg_loss), float("inf") if avg_win > 0 else float("nan")
        )
    else:
        win_rate = avg_win = avg_loss = gross_profit = gross_loss = 0.0
        profit_factor = float("nan")
        expectancy_cash = 0.0
        streaks = {"max_consecutive_wins": 0, "max_consecutive_losses": 0}
        r_stats = r_multiple_stats([])
        avg_bars = best = worst = total_costs = 0.0
        win_loss_ratio = float("nan")

    exposure = (
        float((equity_curve["position_units"].abs() > 0).mean())
        if "position_units" in equity_curve
        else float("nan")
    )

    # --- honesty checks ---------------------------------------------------- #
    if n_trades and n_trades < 30:
        warnings.append(
            f"{n_trades} trades is too few for the ratios above to be distinguishable from "
            f"noise; treat them as descriptive only."
        )
    if np.isfinite(sharpe_p) and sharpe_p > 0.05 and sharpe > 0:
        warnings.append(
            f"Sharpe {sharpe:.2f} has t={sharpe_t:.2f} (p={sharpe_p:.2f}): not statistically "
            f"distinguishable from zero at the 5% level, before any correction for the number "
            f"of variants tested."
        )
    if total_costs > 0 and abs(total_costs) > abs(final_equity - initial_balance):
        warnings.append(
            f"Total costs ({total_costs:,.0f}) exceed the absolute P&L "
            f"({final_equity - initial_balance:,.0f}): the result is dominated by execution "
            f"assumptions, not by the signal."
        )
    if r_stats.count and r_stats.fraction_beyond_full_stop > 0.05:
        warnings.append(
            f"{r_stats.fraction_beyond_full_stop:.0%} of trades lost more than the planned 1R. "
            f"Realised risk per trade exceeds what the sizing model assumed, because the R "
            f"denominator is the pre-cost stop distance while the numerator is net of spread, "
            f"slippage, commission and financing (and of any gap through the stop). If the "
            f"strategy is sized to risk x% per trade, the true figure is higher."
        )

    return PerformanceMetrics(
        total_return=float(total_return), cagr=float(cagr), final_equity=final_equity,
        initial_balance=float(initial_balance), years=float(years),
        annual_volatility=float(ann_vol), sharpe_ratio=float(sharpe),
        sharpe_standard_error=float(sharpe_se), sharpe_t_stat=float(sharpe_t),
        sharpe_p_value=float(sharpe_p), sortino_ratio=float(sortino),
        calmar_ratio=float(calmar), max_drawdown=float(dd.max_drawdown),
        max_drawdown_cash=float(dd.max_drawdown_cash),
        max_drawdown_bars=int(dd.max_drawdown_bars),
        longest_underwater_bars=int(dd.longest_underwater_bars),
        time_underwater_fraction=float(dd.time_underwater_fraction),
        recovery_factor=float(recovery), n_trades=n_trades, win_rate=float(win_rate),
        average_win=float(avg_win), average_loss=float(avg_loss),
        win_loss_ratio=float(win_loss_ratio), expectancy_cash=float(expectancy_cash),
        expectancy_r=float(r_stats.expectancy_r), profit_factor=float(profit_factor),
        max_consecutive_wins=int(streaks["max_consecutive_wins"]),
        max_consecutive_losses=int(streaks["max_consecutive_losses"]),
        average_bars_held=float(avg_bars), exposure_fraction=float(exposure),
        best_trade=float(best), worst_trade=float(worst), total_costs=float(total_costs),
        cost_drag_fraction=float(total_costs / initial_balance) if initial_balance else float("nan"),
        gross_profit=float(gross_profit), gross_loss=float(gross_loss),
        return_skew=skewness(rets.to_numpy()),
        return_excess_kurtosis=excess_kurtosis(rets.to_numpy()),
        r_multiples=r_stats, warnings=warnings,
    )


def _empty_metrics(initial_balance: float, warnings: List[str]) -> PerformanceMetrics:
    nan = float("nan")
    return PerformanceMetrics(
        total_return=0.0, cagr=0.0, final_equity=initial_balance,
        initial_balance=initial_balance, years=0.0, annual_volatility=0.0,
        sharpe_ratio=0.0, sharpe_standard_error=nan, sharpe_t_stat=nan, sharpe_p_value=nan,
        sortino_ratio=nan, calmar_ratio=nan, max_drawdown=0.0, max_drawdown_cash=0.0,
        max_drawdown_bars=0, longest_underwater_bars=0, time_underwater_fraction=0.0,
        recovery_factor=nan, n_trades=0, win_rate=0.0, average_win=0.0, average_loss=0.0,
        win_loss_ratio=nan, expectancy_cash=0.0, expectancy_r=0.0, profit_factor=nan,
        max_consecutive_wins=0, max_consecutive_losses=0, average_bars_held=0.0,
        exposure_fraction=0.0, best_trade=0.0, worst_trade=0.0, total_costs=0.0,
        cost_drag_fraction=0.0, gross_profit=0.0, gross_loss=0.0, return_skew=nan,
        return_excess_kurtosis=nan, r_multiples=r_multiple_stats([]), warnings=warnings,
    )


def metrics_from_result(result, bars_per_year: float = TRADING_DAYS, risk_free_rate: float = 0.0):
    """Compute metrics directly from a :class:`~quantlab.backtest.BacktestResult`."""
    return compute_metrics(
        result.equity_curve, result.trades, initial_balance=result.initial_balance,
        bars_per_year=bars_per_year, risk_free_rate=risk_free_rate,
        extra_warnings=list(result.warnings),
    )


def metrics_table(rows: Dict[str, PerformanceMetrics]) -> pd.DataFrame:
    """One row per labelled result, for side-by-side comparison."""
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame({label: m.to_dict() for label, m in rows.items()}).T
    df.index.name = "run"
    return df.drop(columns=[c for c in ("warnings",) if c in df.columns])


def monthly_returns(equity: pd.Series) -> pd.DataFrame:
    """Month-by-year table of simple returns, for the heatmap."""
    if equity.empty:
        return pd.DataFrame()
    monthly = equity.resample("ME").last().pct_change().dropna()
    if monthly.empty:
        return pd.DataFrame()
    frame = pd.DataFrame(
        {"year": monthly.index.year, "month": monthly.index.month, "ret": monthly.to_numpy()}
    )
    return frame.pivot(index="year", columns="month", values="ret").sort_index()


def rolling_sharpe(
    returns: pd.Series, window: int = 252, bars_per_year: float = TRADING_DAYS
) -> pd.Series:
    """Trailing annualised Sharpe.

    Its purpose in the report is not to find a good period but to show how
    unstable the statistic is: a strategy whose rolling Sharpe swings between -1
    and +3 does not have "a Sharpe of 1", it has a number that happened to
    average 1 over this sample.
    """
    if returns.empty:
        return pd.Series(dtype="float64")
    mean = returns.rolling(window, min_periods=max(window // 2, 20)).mean()
    std = returns.rolling(window, min_periods=max(window // 2, 20)).std(ddof=1)
    return (mean / std.replace(0.0, np.nan)) * math.sqrt(bars_per_year)
