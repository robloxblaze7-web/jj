"""Overfitting and data-snooping diagnostics.

This module exists because of one asymmetry: it is easy to find a strategy that
performed well historically and hard to find one that will perform well next
year, and a backtest cannot tell the two apart on its own.  Every function here
answers a version of the question *how much of this result is explained by the
number of things I tried?*

Four independent diagnostics, because no single one is sufficient:

1. **Expected maximum Sharpe under the null.**  If you test N strategies that
   all have zero true edge, the best of them will still show a positive Sharpe.
   :func:`expected_max_sharpe_null` says how positive.  A result that does not
   clear that bar is not evidence of anything.

2. **Deflated Sharpe ratio** (Bailey & López de Prado).  Converts an observed
   Sharpe into a probability that the true Sharpe is above zero, adjusting for
   the number of trials, the sample length, and the skew and kurtosis of the
   returns — non-normal returns make a given Sharpe less impressive than the
   textbook formula suggests.

3. **Probability of backtest overfitting (PBO).**  Across walk-forward folds,
   how often does the configuration that ranked best in-sample land in the
   *bottom half* out-of-sample?  If that happens about half the time, the
   selection procedure has no predictive content, whatever the stitched equity
   curve shows.  This is the walk-forward analogue of the combinatorially
   symmetric cross-validation estimator; it uses the sequential folds rather
   than all C(S, S/2) recombinations, so it is cheaper and somewhat noisier, and
   it is labelled as such in the report.

4. **In-sample / out-of-sample rank correlation.**  Directly measures whether
   in-sample ranking carries any information about out-of-sample ranking.  A
   correlation near zero means the optimiser is choosing at random.

None of these can prove a strategy works.  They can only establish that a result
is *not* explained by the search — which is a much weaker claim, and the
strongest one a backtest is able to support.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import numpy as np

EULER_MASCHERONI = 0.5772156649015329


# --------------------------------------------------------------------------- #
# normal distribution helpers (no scipy)
# --------------------------------------------------------------------------- #
def norm_cdf(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def norm_ppf(p: float) -> float:
    """Inverse standard normal CDF (Acklam's rational approximation).

    Accurate to about 1.15e-9 in absolute value, which is far beyond the
    precision any of these diagnostics deserve.  Implemented here so the package
    keeps a numpy/pandas/matplotlib dependency footprint.
    """
    if not 0.0 < p < 1.0:
        if p == 0.0:
            return float("-inf")
        if p == 1.0:
            return float("inf")
        return float("nan")

    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]

    p_low, p_high = 0.02425, 1 - 0.02425
    if p < p_low:
        q = math.sqrt(-2 * math.log(p))
        x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / (
            (((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1
        )
    elif p <= p_high:
        q = p - 0.5
        r = q * q
        x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (
            ((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1
        )
    else:
        q = math.sqrt(-2 * math.log(1 - p))
        x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / (
            (((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1
        )
    return float(x)


# --------------------------------------------------------------------------- #
# multiple testing
# --------------------------------------------------------------------------- #
def bonferroni_p(p_value: float, n_trials: int) -> float:
    """Bonferroni-adjusted p-value: conservative, assumes independent trials."""
    if not np.isfinite(p_value) or n_trials < 1:
        return float("nan")
    return float(min(1.0, p_value * n_trials))


def sidak_p(p_value: float, n_trials: int) -> float:
    """Šidák-adjusted p-value: slightly less conservative than Bonferroni."""
    if not np.isfinite(p_value) or n_trials < 1:
        return float("nan")
    return float(1.0 - (1.0 - p_value) ** n_trials)


def expected_max_sharpe_null(n_trials: int, n_obs: int, bars_per_year: float = 252.0) -> float:
    """Expected maximum *annualised* Sharpe when every trial has zero true edge.

    Uses the extreme-value approximation from Bailey & López de Prado: for N
    independent trials with per-observation Sharpe standard error 1/sqrt(T),

        E[max SR] ≈ (1/sqrt(T)) * [ (1-γ)·Φ⁻¹(1 - 1/N) + γ·Φ⁻¹(1 - 1/(N·e)) ]

    This is the number a reported Sharpe has to beat before it is worth
    discussing.  Searching 24 parameter sets over four years of daily data buys
    you a respectable-looking Sharpe for free.
    """
    if n_trials < 1 or n_obs < 2:
        return float("nan")
    if n_trials == 1:
        return 0.0
    z1 = norm_ppf(1.0 - 1.0 / n_trials)
    z2 = norm_ppf(1.0 - 1.0 / (n_trials * math.e))
    expected_max_per_obs = ((1 - EULER_MASCHERONI) * z1 + EULER_MASCHERONI * z2) / math.sqrt(n_obs)
    return float(expected_max_per_obs * math.sqrt(bars_per_year))


def deflated_sharpe_ratio(
    observed_sharpe: float,
    n_obs: int,
    n_trials: int,
    skew: float = 0.0,
    excess_kurtosis: float = 0.0,
    bars_per_year: float = 252.0,
) -> float:
    """Probability that the true Sharpe exceeds zero, given the search.

    Compares the observed annualised Sharpe against the expected maximum under
    the null, standardised by a variance that accounts for non-normal returns.
    Negative skew and fat tails both *increase* the standard error, so the same
    Sharpe is less convincing for a strategy that makes many small gains and
    occasional large losses — which describes most short-option-like and
    mean-reverting systems.

    Returns a probability in [0, 1].  Below ~0.95, the result is not
    distinguishable from the best of N random trials.
    """
    if not np.isfinite(observed_sharpe) or n_obs < 3 or n_trials < 1:
        return float("nan")

    sr = observed_sharpe / math.sqrt(bars_per_year)          # per-observation
    sr_null = expected_max_sharpe_null(n_trials, n_obs, bars_per_year) / math.sqrt(bars_per_year)

    gamma3 = skew if np.isfinite(skew) else 0.0
    gamma4 = (excess_kurtosis if np.isfinite(excess_kurtosis) else 0.0) + 3.0
    variance = 1.0 - gamma3 * sr + ((gamma4 - 1.0) / 4.0) * sr**2
    if variance <= 0:
        return float("nan")

    denom = math.sqrt(variance) / math.sqrt(n_obs - 1)
    return float(norm_cdf((sr - sr_null) / denom))


def haircut_sharpe(
    observed_sharpe: float, n_trials: int, n_obs: int, bars_per_year: float = 252.0
) -> float:
    """Observed Sharpe minus the expected best-of-N Sharpe under the null.

    A blunt but readable version of the same idea: what is left of the headline
    number once the search is paid for.  Negative means the result is worse than
    what pure noise would have handed you.
    """
    return float(observed_sharpe - expected_max_sharpe_null(n_trials, n_obs, bars_per_year))


# --------------------------------------------------------------------------- #
# rank statistics
# --------------------------------------------------------------------------- #
def _rankdata(values: Sequence[float]) -> np.ndarray:
    """Average ranks, ties shared (1 = smallest)."""
    arr = np.asarray(values, dtype=float)
    order = np.argsort(arr, kind="mergesort")
    ranks = np.empty(len(arr), dtype=float)
    ranks[order] = np.arange(1, len(arr) + 1, dtype=float)
    # average ties
    unique_vals, inverse = np.unique(arr, return_inverse=True)
    for i in range(len(unique_vals)):
        mask = inverse == i
        if mask.sum() > 1:
            ranks[mask] = ranks[mask].mean()
    return ranks


def spearman_correlation(x: Sequence[float], y: Sequence[float]) -> float:
    """Spearman rank correlation, implemented without scipy."""
    xa, ya = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    mask = np.isfinite(xa) & np.isfinite(ya)
    xa, ya = xa[mask], ya[mask]
    if len(xa) < 3:
        return float("nan")
    rx, ry = _rankdata(xa), _rankdata(ya)
    rx = rx - rx.mean()
    ry = ry - ry.mean()
    denom = math.sqrt(float((rx**2).sum()) * float((ry**2).sum()))
    if denom == 0:
        return float("nan")
    return float(float((rx * ry).sum()) / denom)


# --------------------------------------------------------------------------- #
# probability of backtest overfitting
# --------------------------------------------------------------------------- #
@dataclass
class PBOResult:
    """Probability of backtest overfitting, estimated across walk-forward folds."""

    pbo: float
    n_folds_used: int
    logits: List[float] = field(default_factory=list)
    relative_ranks: List[float] = field(default_factory=list)
    rank_correlation: float = float("nan")
    median_oos_of_is_best: float = float("nan")
    note: str = ""

    def interpretation(self) -> str:
        if not np.isfinite(self.pbo):
            return "PBO could not be estimated (too few folds or candidates)."
        if self.pbo >= 0.5:
            return (
                f"PBO {self.pbo:.0%}: the in-sample winner lands in the bottom half "
                f"out-of-sample at least as often as not. The selection procedure has no "
                f"demonstrated predictive content on this data."
            )
        if self.pbo >= 0.25:
            return (
                f"PBO {self.pbo:.0%}: selection is better than a coin flip but unreliable. "
                f"Treat any positive out-of-sample result as provisional."
            )
        return (
            f"PBO {self.pbo:.0%}: the in-sample winner usually stays in the top half "
            f"out-of-sample. This is a necessary condition for the search to be meaningful, "
            f"not a sufficient one for the strategy to be profitable."
        )


def probability_of_backtest_overfitting(folds: Sequence[Any]) -> PBOResult:
    """Estimate PBO from walk-forward folds.

    Each fold must expose ``candidates``, a sequence of objects with
    ``train_score`` and ``test_score``.  For every fold the candidate that ranked
    best in-sample is located in the out-of-sample ranking; its *relative rank*
    ``r/(N+1)`` (1 = best OOS) is converted to a logit, and PBO is the fraction
    of folds whose logit is negative — that is, folds where the in-sample winner
    finished in the bottom half out-of-sample.

    This is the sequential walk-forward variant of the CSCV estimator of Bailey,
    Borwein, López de Prado and Zhu (2015), not the full combinatorial version.
    It uses far fewer splits, so it is noisier; with fewer than about eight folds
    the estimate should be read as directional only.
    """
    logits: List[float] = []
    rel_ranks: List[float] = []
    all_is: List[float] = []
    all_oos: List[float] = []
    oos_of_winner: List[float] = []

    for fold in folds:
        candidates = [
            c
            for c in getattr(fold, "candidates", [])
            if np.isfinite(getattr(c, "train_score", np.nan))
            and np.isfinite(getattr(c, "test_score", np.nan))
        ]
        n = len(candidates)
        if n < 2:
            continue

        train_scores = [c.train_score for c in candidates]
        test_scores = [c.test_score for c in candidates]
        all_is.extend(train_scores)
        all_oos.extend(test_scores)

        best_idx = int(np.argmax(train_scores))
        oos_ranks = _rankdata(test_scores)          # 1 = worst OOS, n = best OOS
        r = float(oos_ranks[best_idx])
        omega = r / (n + 1.0)                        # in (0, 1); >0.5 means top half
        omega = min(max(omega, 1e-6), 1 - 1e-6)
        logits.append(float(math.log(omega / (1.0 - omega))))
        rel_ranks.append(omega)
        oos_of_winner.append(float(test_scores[best_idx]))

    if not logits:
        return PBOResult(
            pbo=float("nan"), n_folds_used=0,
            note="No fold had at least two candidates with finite in- and out-of-sample scores.",
        )

    pbo = float(np.mean([lg < 0 for lg in logits]))
    note = ""
    if len(logits) < 8:
        note = (
            f"Estimated from only {len(logits)} folds; the sampling error on this figure is "
            f"large. Read it as directional."
        )
    return PBOResult(
        pbo=pbo,
        n_folds_used=len(logits),
        logits=logits,
        relative_ranks=rel_ranks,
        rank_correlation=spearman_correlation(all_is, all_oos),
        median_oos_of_is_best=float(np.median(oos_of_winner)),
        note=note,
    )


# --------------------------------------------------------------------------- #
# assembled report
# --------------------------------------------------------------------------- #
@dataclass
class OverfittingReport:
    """All diagnostics for one strategy/instrument, plus plain-language flags."""

    label: str
    observed_sharpe: float
    n_obs: int
    n_trials: int
    expected_max_null_sharpe: float
    haircut_sharpe: float
    deflated_sharpe: float
    raw_p_value: float
    bonferroni_p_value: float
    sidak_p_value: float
    pbo: Optional[PBOResult] = None
    parameter_churn: float = float("nan")
    in_sample_sharpe: float = float("nan")
    out_of_sample_sharpe: float = float("nan")
    flags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "label": self.label,
            "observed_sharpe": self.observed_sharpe,
            "n_obs": self.n_obs,
            "n_trials": self.n_trials,
            "expected_max_null_sharpe": self.expected_max_null_sharpe,
            "haircut_sharpe": self.haircut_sharpe,
            "deflated_sharpe": self.deflated_sharpe,
            "raw_p_value": self.raw_p_value,
            "bonferroni_p_value": self.bonferroni_p_value,
            "sidak_p_value": self.sidak_p_value,
            "pbo": self.pbo.pbo if self.pbo else float("nan"),
            "is_oos_rank_correlation": self.pbo.rank_correlation if self.pbo else float("nan"),
            "parameter_churn": self.parameter_churn,
            "in_sample_sharpe": self.in_sample_sharpe,
            "out_of_sample_sharpe": self.out_of_sample_sharpe,
            "n_flags": len(self.flags),
        }


def build_overfitting_report(
    *,
    label: str,
    observed_sharpe: float,
    raw_p_value: float,
    n_obs: int,
    n_trials: int,
    skew: float = 0.0,
    excess_kurtosis: float = 0.0,
    bars_per_year: float = 252.0,
    folds: Optional[Sequence[Any]] = None,
    parameter_churn: float = float("nan"),
    in_sample_sharpe: float = float("nan"),
    out_of_sample_sharpe: float = float("nan"),
) -> OverfittingReport:
    """Assemble every diagnostic and translate them into explicit warnings."""
    exp_max = expected_max_sharpe_null(n_trials, n_obs, bars_per_year)
    haircut = haircut_sharpe(observed_sharpe, n_trials, n_obs, bars_per_year)
    dsr = deflated_sharpe_ratio(
        observed_sharpe, n_obs, n_trials, skew, excess_kurtosis, bars_per_year
    )
    pbo = probability_of_backtest_overfitting(folds) if folds else None

    flags: List[str] = []

    if np.isfinite(observed_sharpe) and observed_sharpe <= 0:
        flags.append(
            f"Out-of-sample Sharpe is {observed_sharpe:.2f}. There is no positive result to "
            f"explain, overfitted or otherwise."
        )
    else:
        if np.isfinite(exp_max) and observed_sharpe < exp_max:
            flags.append(
                f"Observed Sharpe {observed_sharpe:.2f} is below the {exp_max:.2f} that the "
                f"best of {n_trials} zero-edge trials would be expected to produce on "
                f"{n_obs} observations. The result is consistent with pure search luck."
            )
        if np.isfinite(dsr) and dsr < 0.95:
            flags.append(
                f"Deflated Sharpe ratio {dsr:.2f}: after adjusting for {n_trials} trials, "
                f"sample length and the shape of the return distribution, the probability "
                f"that the true Sharpe is positive does not reach the 95% threshold."
            )
        adj_p = sidak_p(raw_p_value, n_trials)
        if np.isfinite(adj_p) and adj_p > 0.05:
            flags.append(
                f"Multiple-testing adjusted p-value {adj_p:.2f} (raw {raw_p_value:.3f}, "
                f"{n_trials} trials): not significant at the 5% level once the search is "
                f"accounted for."
            )

    if pbo is not None and np.isfinite(pbo.pbo) and pbo.pbo >= 0.5:
        flags.append(pbo.interpretation())
    if pbo is not None and np.isfinite(pbo.rank_correlation) and abs(pbo.rank_correlation) < 0.1:
        flags.append(
            f"In-sample and out-of-sample candidate rankings are essentially uncorrelated "
            f"(Spearman {pbo.rank_correlation:+.2f}). Choosing parameters on in-sample "
            f"performance is close to choosing at random."
        )
    if np.isfinite(parameter_churn) and parameter_churn > 0.6:
        flags.append(
            f"Selected parameters changed in {parameter_churn:.0%} of consecutive folds: no "
            f"stable configuration was found."
        )
    if (
        np.isfinite(in_sample_sharpe)
        and np.isfinite(out_of_sample_sharpe)
        and in_sample_sharpe > 0
        and out_of_sample_sharpe < in_sample_sharpe * 0.5
    ):
        flags.append(
            f"Out-of-sample Sharpe ({out_of_sample_sharpe:.2f}) is less than half the "
            f"in-sample figure ({in_sample_sharpe:.2f}) — the classic degradation signature "
            f"of a fitted result."
        )

    return OverfittingReport(
        label=label,
        observed_sharpe=float(observed_sharpe),
        n_obs=int(n_obs),
        n_trials=int(n_trials),
        expected_max_null_sharpe=float(exp_max),
        haircut_sharpe=float(haircut),
        deflated_sharpe=float(dsr),
        raw_p_value=float(raw_p_value),
        bonferroni_p_value=float(bonferroni_p(raw_p_value, n_trials)),
        sidak_p_value=float(sidak_p(raw_p_value, n_trials)),
        pbo=pbo,
        parameter_churn=float(parameter_churn),
        in_sample_sharpe=float(in_sample_sharpe),
        out_of_sample_sharpe=float(out_of_sample_sharpe),
        flags=flags,
    )
